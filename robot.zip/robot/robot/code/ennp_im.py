# -*- coding: utf-8 -*-
import csv
import csv
import math
import math
import math
import os
import re
import sys
import sys
import sys
import threading
import threading
import time
import time
import time
import time

import keyboard
import numpy as np
import numpy as np
import numpy as np
import pythoncom
import xlrd

import AriaPy
from AriaPy import *
from AriaPy import *
from pep import *
sys.path.append(r'C:\robot\ARIA\python3')


# 高斯隶属度函数
def gaussmf(x, mean, sigma):
    """计算高斯隶属度函数值"""
    return np.exp(-((x - mean) ** 2.) / (2 * sigma ** 2.))

def process_file(input_file, output_file, distance_value):
    """处理文件中的高斯函数表达式，将distance表达式替换为具体数值"""
    try:
        # 读取输入文件
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()

        # 查找所有包含distance的表达式
       #pattern = r'gauss_mf\(\((\w+)\)\(distance\s*([+-]\s*\d+)?\)\((\d+)\)\)'
        pattern = r'gauss_mf\(\((\w+)\)\(distance\s*([+-]\s*\d+)?\)\(([^)]+)\)\)'

        def replace_func(match):
            var_name = match.group(1)
            offset_str = match.group(2)
            width = match.group(3)

            # 计算中心点
            if offset_str is None or offset_str.strip() == '':
                center = distance_value
            else:
                if '+' in offset_str:
                    center = distance_value + int(offset_str.replace('+', '').strip())
                else:
                    center = distance_value - int(offset_str.replace('-', '').strip())

            # 返回替换后的表达式，保留gauss_mf函数调用
            return f"gauss_mf(({var_name})({center})({width}))"

        # 替换所有匹配项
        updated_content = re.sub(pattern, replace_func, content)

        # 写入输出文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(updated_content)

        print(f"处理完成！结果已保存到 {output_file}")

    except Exception as e:
        print(f"处理文件时出错: {e}")


##############################################################################################################
##############################################################################################################
distance=300
def generate_replacements():
    """
    生成替换规则字典
    """
    speed=350

    replacements = {}

    # 定义八种模式的参数
    patterns = [
        'layer4_leftspeed_slow',
        'layer4_leftspeed_normal',
        'layer4_leftspeed_quick',
        'layer4_leftspeed_fast',
        'layer4_rightspeed_slow',
        'layer4_rightspeed_normal',
        'layer4_rightspeed_quick',
        'layer4_rightspeed_fast'
    ]
    # 高斯函数参数 - 可以根据需要调整
    gaussian_params = {
        'layer4_leftspeed_slow': {'mu': speed-290, 'sigma': 75},
        'layer4_leftspeed_normal': {'mu': speed, 'sigma': 80},
        'layer4_leftspeed_quick': {'mu': speed+200, 'sigma': 75},
        'layer4_leftspeed_fast': {'mu': speed+350, 'sigma': 40},
        'layer4_rightspeed_slow': {'mu':speed-290, 'sigma': 75},
        'layer4_rightspeed_normal': {'mu': speed, 'sigma': 80},
        'layer4_rightspeed_quick': {'mu':  speed+200, 'sigma': 75},
        'layer4_rightspeed_fast': {'mu': speed-290, 'sigma': 40}
    }

    # 生成替换规则
    start_value = -100
    step = 3

    print("生成替换规则...")
    for pattern in patterns:
        print(f"处理模式: {pattern}")
        params = gaussian_params[pattern]

        for i in range(1, 301):  # 从1到300
            x_value = start_value + (i - 1) * step
            gauss_value = round(gaussmf(x_value, params['mu'], params['sigma']), 3)

            # 创建替换规则
            old_string = f"{pattern}{i}_gauss"
            new_string = f"{gauss_value}"

            replacements[old_string] = new_string

            # 显示进度
            if i % 50 == 0:
                print(f"  已处理 {i}/300 个值")

    print(f"替换规则生成完成，共 {len(replacements)} 条规则")
    return replacements


def replace_in_file(input_file, output_file, replacements):
    """
    在文件中应用替换规则
    """
    try:
        print(f"读取文件: {input_file}")
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        file_size = len(content) / 1024
        print(f"文件大小: {file_size:.2f} KB")

        # 计算需要替换的模式数量
        patterns_to_replace = set()
        for key in replacements.keys():
            match = re.match(r'(layer4_[a-z_]+)\d+_gauss', key)
            if match:
                patterns_to_replace.add(match.group(1))

        print(f"需要替换的模式: {len(patterns_to_replace)}")
        print(f"开始替换...")

        start_time = time.time()
        replaced_count = 0

        # 对每个模式进行替换
        for pattern in patterns_to_replace:
            pattern_start_time = time.time()
            pattern_replaced = 0

            print(f"替换模式: {pattern}")
            for i in range(1, 301):
                old_string = f"{pattern}{i}_gauss"
                if old_string in replacements:
                    new_string = replacements[old_string]

                    # 检查是否存在于文件中
                    if old_string in content:
                        content = content.replace(old_string, new_string)
                        pattern_replaced += 1
                        replaced_count += 1

            pattern_elapsed = time.time() - pattern_start_time
            print(f"  模式 {pattern} 替换了 {pattern_replaced} 处 (用时: {pattern_elapsed:.2f}秒)")

        # 写入输出文件
        print(f"写入输出文件: {output_file}")
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)

        total_elapsed = time.time() - start_time
        print(f"替换完成！共替换了 {replaced_count} 处")
        print(f"总用时: {total_elapsed:.2f}秒")

        return replaced_count

    except Exception as e:
        print(f"处理文件时出错: {e}")
        return 0
input_file = "ennp_im_1.pep"  # 默认使用上传的文件
output_file="ennp_im_1_processed.pep"

# 生成输出文件路径
process_file(input_file, output_file, 300)

file_name, file_ext = os.path.splitext(output_file)

output_file = f"{file_name}{file_ext}"

# 生成替换规则
replacements = generate_replacements()
# 应用替换规则
replace_in_file(output_file, "ennp_im_1_processed.pep", replacements)

try:
    import AriaPy
    print("成功导入 AriaPy 模块")
except ImportError:
    print("错误：无法导入 AriaPy 模块")
    sys.exit(1)
# 创建机器人对象
print("创建机器人对象...")
robot = AriaPy.ArRobot()

# 用于决定程序是否继续运行
# 1 继续运行, 0 停止
# 按键 "q" 可以停止程序并收集数据
flag = 1

def key_press_handler(e):
    """处理键盘按键事件"""
    global flag
    print(f"按下了键: {e.name}")
    if e.name.lower() == "q":
        print("检测到Q键，准备停止程序...")
        flag = 0
        return False  # 停止监听

def setup_keyboard_listener():
    """设置键盘监听器"""
    keyboard.on_press(key_press_handler)

# 创建线程监听键盘事件
def start_keyboard_listener():
    """启动键盘监听线程"""
    t = threading.Thread(target=setup_keyboard_listener)
    t.daemon = True
    t.start()
    return t
keyboard_thread = start_keyboard_listener()

print("按 'Q' 键可停止程序")


start_time=time.time()
# 创建 TCP 连接 (MobileSim 默认使用 TCP)
print("创建 TCP 连接...")
conn = AriaPy.ArTcpConnection()
conn.setPort("localhost", 8101)  # MobileSim 默认端口

# 设置机器人连接
print("设置机器人连接...")
robot.setDeviceConnection(conn)
if not robot.blockingConnect():
    print("错误：无法连接到仿真机器人")
robot.runAsync(True)
# 添加声纳设备
print("添加声纳设备...")
sonar = ArSonarDevice()
robot.addRangeDevice(sonar)
# 等待机器人准备就绪
print("等待机器人准备就绪...")
#time.sleep(1)
# 启用电机
print("启用电机...")
robot.enableMotors()
print("机器人初始化完成")
# 数据收集变量
one_sheet = []
sheet = []
last_speed=0
flag=1
last_angle_speed=0

system,getindex= readInputFile('ennp_im_1_processed.pep')
while flag:
    ac_start_time = time.perf_counter()
    # 获取声纳读数
    numSonar = robot.getNumSonar()
    sonarReading = []
    # 收集一组数据
    for i in range(0, numSonar):
        reading = round(robot.getSonarReading(i).getRange())
        reading=reading-100
        if reading > 1000:
            reading = 1000
        sonarReading.append(reading)
        one_sheet.append(reading)
    print(sonarReading)
    #设置系统变量
    for p_object in system.variables:
        if p_object.name == 'layer1_S4':
            system.variables[system.variables.index(p_object)].value = sonarReading[4]
        elif p_object.name == 'layer1_S5':
            system.variables[system.variables.index(p_object)].value = sonarReading[5]
        elif p_object.name == 'layer1_S6':
            system.variables[system.variables.index(p_object)].value = sonarReading[6]
        elif p_object.name == 'layer1_S7':
            system.variables[system.variables.index(p_object)].value = sonarReading[7]

        # 设置酶值
    for p_object in system.enzymes:
        # if p_object.name == 'e_S7' or p_object.name == 'e_S6' or p_object.name == 'e_S5' or p_object.name == 'e_S4':
        #     print(p_object.name,p_object.value)
        for p_object2 in system.variables:
            if p_object2.name == p_object.name:
                p_object.value = p_object2.value

                #print (p_object.name,p_object.value)
    # for p_object in system.variables:
    #     if p_object.name == 'layer1_S7_normal_to_layer2':
    #       print(p_object.value)
    time_1 = time.perf_counter()
    # 模拟系统
    #system.simulate(stepByStepConfirm=False, printEachSystemState= False,maxSteps=1,maxTime=1000)
    system.runSimulationStep()
    # for p_object in system.enzymes:
    #     print(p_object.name,p_object.value)
    #     p_object.value = 1
    for p_object in system.variables:
        if p_object.name == 'layer1_S7_close_to_layer2' or p_object.name =='layer1_S7_near_to_layer2' or p_object.name =='layer1_S7_normal_to_layer2' or p_object.name =='layer1_S7_far_to_layer2' or p_object.name =='layer1_S7_remote_to_layer2' \
           or p_object.name == 'layer1_S6_close_to_layer2' or p_object.name == 'layer1_S6_near_to_layer2' or p_object.name == 'layer1_S6_normal_to_layer2' or p_object.name == 'layer1_S6_far_to_layer2' or p_object.name == 'layer1_S6_remote_to_layer2' \
           or p_object.name == 'layer1_S5_close_to_layer2' or p_object.name == 'layer1_S5_near_to_layer2' or p_object.name == 'layer1_S5_normal_to_layer2' or p_object.name == 'layer1_S5_far_to_layer2' or p_object.name == 'layer1_S5_remote_to_layer2' \
           or p_object.name == 'layer1_S4_close_to_layer2' or p_object.name == 'layer1_S4_near_to_layer2' or p_object.name == 'layer1_S4_normal_to_layer2' or p_object.name == 'layer1_S4_far_to_layer2' or p_object.name == 'layer1_S4_remote_to_layer2' :
              print(p_object.name, p_object.value)
    #     # 设置酶值
    # for p_object in system.enzymes:
    #     print(p_object.name, p_object.value)
    #获取计算结果
    leftSpeed = 0
    rightSpeed = 0

    for p_object in system.variables:
        if p_object.name == 'calculate_leftspeed':
            leftSpeed = p_object.value
            system.variables[system.variables.index(p_object)].value = 0
        elif p_object.name == 'calculate_rightspeed':
            rightSpeed = p_object.value
            system.variables[system.variables.index(p_object)].value = 0
    time_2=time.perf_counter()
    #print("1111",time_2-time_1)
    #print(leftSpeed,rightSpeed)
    robot.lock()
    robot.setVel2(leftSpeed, rightSpeed)
    robot.unlock()
    #time.sleep(0.00001)
    robot.lock()

    robot_leftSpeed = robot.getLeftVel()
    robot_rightSpeed = robot.getRightVel()
    robot_trans_speed = robot.getVel()
    robot_rot_speed = robot.getRotVel()
    robot.unlock()
    ac_end_time = time.perf_counter()


    #flag = 0

    robot_transaccel = (robot_trans_speed - last_speed) / (ac_end_time - ac_start_time)
    robot_angle_transaccel =(robot_rot_speed-last_angle_speed)/(ac_end_time - ac_start_time)
    last_angle_speed=robot_rot_speed
    last_speed = robot_trans_speed
    # 记录数据
    #one_sheet.append(robot_query_time)  # 执行时间
    one_sheet.append(leftSpeed)  # 计算左轮速度
    one_sheet.append(rightSpeed)  # 计算右轮速度
    one_sheet.append(robot_leftSpeed)  # 实际左轮速度
    one_sheet.append(robot_rightSpeed)  # 实际右轮速度
    one_sheet.append(robot_trans_speed)  # 实际速度
    one_sheet.append(robot_rot_speed)  # 实际角速度
    one_sheet.append(robot_transaccel)  # 实际加速度
    one_sheet.append(robot_angle_transaccel)  # 实际角加速度
    # print(one_sheet)
    sheet.append(one_sheet)
    one_sheet = []

# writeFileObj = open('11ennp_fc_ACFI_300_350.csv', 'w')
# csv_writer = csv.writer(writeFileObj)
# writer = csv_writer
# for row in sheet:
#     writer.writerow(row)
# writeFileObj.close()









