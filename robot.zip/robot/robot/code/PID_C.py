# -*- coding: utf-8 -*-
import numpy as np
#!/usr/bin/env python

"""
ARIA Python 绑定最简测试案例：MobileSim 仿真机器人控制
不使用显式初始化，直接创建机器人对象
"""
import AriaPy
from AriaPy import *  # 恢复完整导入以确保所有AriaPy函数可用
from pep import *
import sys
import xlrd
import keyboard  # 替换pythoncom和pyHook，更适合Python 3
import threading
import csv
import numpy as np
import time
import math
import sys
import time
from AriaPy import *
import sys
import pythoncom
import threading
import csv
import numpy as np
import time
import math
from pyit2fls import IT2Mamdani, IT2FS_Gaussian_UncertStd, IT2FS_plot, \
                     min_t_norm, max_s_norm, crisp,product_t_norm,T1FS
from pyit2fls import (IT2FS, tri_mf, const_mf, rtri_mf, ltri_mf,
                      trapezoid_mf, gaussian_mf, IT2FS_Gaussian_UncertMean,
                      IT2FS_Gaussian_UncertStd, R_IT2FS_Gaussian_UncertStd,
                      L_IT2FS_Gaussian_UncertStd, IT2FS_plot, )
from numpy import linspace, meshgrid, zeros
from mpl_toolkits import mplot3d
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
# 添加 ARIA Python 绑定路径
sys.path.append(r'C:\robot\ARIA\python3')
try:
    import AriaPy
    print("成功导入 AriaPy 模块")
except ImportError:
    print("错误：无法导入 AriaPy 模块")
    sys.exit(1)
# 创建机器人对象
print("创建机器人对象...")
robot = AriaPy.ArRobot()

# 用于决定程序是否继续运行
# 1 继续运行, 0 停止
# 按键 "q" 可以停止程序并收集数据
flag = 1

def key_press_handler(e):
    """处理键盘按键事件"""
    global flag
    print(f"按下了键: {e.name}")
    if e.name.lower() == "q":
        print("检测到Q键，准备停止程序...")
        flag = 0
        return False  # 停止监听

def setup_keyboard_listener():
    """设置键盘监听器"""
    keyboard.on_press(key_press_handler)

# 创建线程监听键盘事件
def start_keyboard_listener():
    """启动键盘监听线程"""
    t = threading.Thread(target=setup_keyboard_listener)
    t.daemon = True
    t.start()
    return t
# 启动键盘监听
keyboard_thread = start_keyboard_listener()
print("按 'Q' 键可停止程序")



class WallFollowingPIDController:
    def __init__(self, set_distance=200):
        """
        初始化PID控制器

        参数:
        set_distance: 机器人与墙壁之间的目标距离(mm)
        is_left_wall: 是否跟随左侧墙壁，False表示跟随右侧墙壁
        """

        # 墙壁-机器人平行PID参数
        self.kp_parallel = 1.5
        self.ki_parallel = 0.0025
        self.kd_parallel = 0.7

        # 累积误差和上一次误差初始化
        self.parallel_error_sum = 0
        # 基础PWM值（论文中的nominal PWM）

        self.last_parallel_error = 0
    def reset(self):
        """重置PID控制器状态"""

        self.parallel_error_sum = 0

        self.last_parallel_error = 0

    def compute_control(self, sonar_readings):
        """
        计算PID控制输出

        参数:
        sonar_readings: 超声波传感器读数列表，长度为8

        返回:
        left_pwm: 左轮PWM值
        right_pwm: 右轮PWM值
        """

        side_sensor = sonar_readings[0]  # 侧面传感器
        # 计算平行误差 (根据论文中的公式3)
        # 计算机器人是否平行于墙壁的误差
        parallel_error = side_sensor-200
        #print(parallel_error)
        # 计算距离误差 (根据论文中的公式4)



        # 计算平行PID控制器输出
        p_term_parallel = self.kp_parallel * parallel_error
        self.parallel_error_sum += parallel_error
        i_term_parallel = self.ki_parallel * self.parallel_error_sum*0.04
        d_term_parallel = self.kd_parallel * (parallel_error - self.last_parallel_error)
        parallel_pid_output = p_term_parallel + i_term_parallel + d_term_parallel

        self.last_parallel_error = parallel_error

        # 计算最终PWM输出 (根据论文中的公式5和6)
        v2 = parallel_pid_output

        return v2


start_time=time.time()
# 创建 TCP 连接 (MobileSim 默认使用 TCP)
print("创建 TCP 连接...")
conn = AriaPy.ArTcpConnection()
conn.setPort("localhost", 8101)  # MobileSim 默认端口

# 设置机器人连接
print("设置机器人连接...")
robot.setDeviceConnection(conn)
if not robot.blockingConnect():
    print("错误：无法连接到仿真机器人")
robot.runAsync(True)
# 添加声纳设备
print("添加声纳设备...")
sonar = ArSonarDevice()
robot.addRangeDevice(sonar)
# 等待机器人准备就绪
print("等待机器人准备就绪...")
#time.sleep(1)
# 启用电机
print("启用电机...")
robot.enableMotors()
print("机器人初始化完成")


domain1 = linspace(200, 700, 500)
domain2 = linspace(-100, 100, 200)


NE=IT2FS(domain1, tri_mf, [0, 200, 450, 1], tri_mf, [0, 200, 450, 0.7], check_set=True)
ZE=IT2FS(domain1, tri_mf, [200, 450, 700, 1], tri_mf, [200, 450, 700, 0.7], check_set=True)
PE=IT2FS(domain1, tri_mf, [450, 700, 1000, 1], tri_mf, [450, 700, 1000, 0.7], check_set=True)
B = IT2FS(domain2, tri_mf, [-200, -100, 0, 1],tri_mf, [-200, -100, 0, 1], check_set=True)
Z = IT2FS(domain2, tri_mf, [-100, 0, 100,1],tri_mf, [-100, 0, 100,1], check_set=True)
F = IT2FS(domain2, tri_mf, [0, 100,200 ,1],tri_mf, [0, 100,200 ,1], check_set=True)
myIT2FLS = IT2Mamdani(product_t_norm, max_s_norm)

myIT2FLS.add_input_variable("e1")
myIT2FLS.add_input_variable("e2")

myIT2FLS.add_output_variable("vl")
myIT2FLS.add_output_variable("vr")

myIT2FLS.add_rule([("e1", NE),  ("e2", NE)],  [("vl", F),  ("vr", B)])
myIT2FLS.add_rule([("e1", NE),  ("e2", ZE)],  [("vl", F),  ("vr", Z)])
myIT2FLS.add_rule([("e1", NE),  ("e2", PE)],  [("vl", F),  ("vr", Z)])
myIT2FLS.add_rule([("e1", ZE),  ("e2", NE)],  [("vl", F),  ("vr", B)])
myIT2FLS.add_rule([("e1", ZE),  ("e2", ZE)],  [("vl", F),  ("vr", F)])
myIT2FLS.add_rule([("e1", ZE),  ("e2", PE)],  [("vl", Z),  ("vr", F)])
myIT2FLS.add_rule([("e1", PE),  ("e2", NE)],  [("vl", F),  ("vr", Z)])
myIT2FLS.add_rule([("e1", PE),  ("e2", ZE)],  [("vl", Z),  ("vr", F)])
myIT2FLS.add_rule([("e1", PE),  ("e2", PE)],  [("vl", Z),  ("vr", F)])


# 数据收集变量
one_sheet = []
sheet = []

# 创建PID控制器实例

last_speed=0
last_angle_speed=0
pid_controller = WallFollowingPIDController(set_distance=200)

last_x = robot.getX()
last_y = robot.getY()
total_distance = 0

starttime=time.perf_counter()
while flag:

    ac_start_time= time.perf_counter()
    numSonar = robot.getNumSonar()
    sonarReading = []
    # 收集一组数据
    for i in range(0, numSonar):
        reading = round(robot.getSonarReading(i).getRange())
        reading=reading-100
        if reading > 1000:
            reading = 1000
        sonarReading.append(reading)
        one_sheet.append(reading)
    # # 计算控制输出
    #left_pwm, right_pwm = pid_controller.compute_control(sonarReading)
    # print(f"左轮PWM: {left_pwm}, 右轮PWM: {right_pwm}")

    # 切换到右侧墙壁跟随
    time_1=time.perf_counter()
    e1=sonarReading[1]
    e2=min(sonarReading[2],sonarReading[3])

    print(sonarReading[0],sonarReading[1],sonarReading[2],sonarReading[3])


    if min(sonarReading[1],sonarReading[2],sonarReading[3])<=280:
        print(1111111111111111)
        output = myIT2FLS.evaluate({"e1": e1, "e2": e2})
        fuzzy_sets, crisp_values = output
        # 从数值区间中提取值（取中点）
        vl_interval = crisp_values["vl"]
        vr_interval = crisp_values["vr"]

        # 取区间中点作为最终输出
        leftSpeed = (vl_interval[0] + vl_interval[1]) / 2+20
        rightSpeed = (vr_interval[0] + vr_interval[1]) / 2+20
    else:
        print(2222222222222222222)
        v2 = pid_controller.compute_control(sonarReading)
        leftSpeed = (130 - v2) / 2
        rightSpeed = (130 + v2) / 2

    print(f"leftSpeed: {leftSpeed}, rightSpeed: {rightSpeed}")
    #v2 = pid_controller.compute_control(sonarReading)
    #print(v2)
    time_2=time.perf_counter()
    robot_query_time = time_2 - time_1
    #leftSpeed = (65-v2)/2
    #rightSpeed = (65+v2)/2
    robot.lock()
    robot.setVel2(leftSpeed, rightSpeed)
    robot.unlock()
    time.sleep(0.05)
    robot.lock()

    ################用于计算总的移动路径################

    robot.lock()
    current_x = robot.getX()
    current_y = robot.getY()
    # robot.moveTo(ArPose(1, 1, 0))
    robot.unlock()
    print(current_x, current_y)
    # 计算两点间距离
    delta_distance = math.sqrt((current_x - last_x) ** 2 + (current_y - last_y) ** 2)
    total_distance += delta_distance

    # 更新上一次位置
    last_x = current_x
    last_y = current_y

    print(f"当前总路径长度: {total_distance:.2f} mm")
    ################用于计算总的移动路径################

    robot_leftSpeed = robot.getLeftVel()
    robot_rightSpeed = robot.getRightVel()
    robot_trans_speed = robot.getVel()
    robot_rot_speed = robot.getRotVel()
    robot.unlock()
    endtime = time.perf_counter()
    ac_end_time = time.perf_counter()
    robot_transaccel = (robot_trans_speed-last_speed)/(ac_end_time-ac_start_time)
    robot_angle_transaccel = (robot_rot_speed - last_angle_speed) / (ac_end_time - ac_start_time)
    last_angle_speed = robot_rot_speed
    last_speed=robot_trans_speed
    # 记录数据
    #one_sheet.append(robot_query_time)  # 执行时间
    one_sheet.append(leftSpeed)  #计算左轮速度
    one_sheet.append(rightSpeed) #计算右轮速度
    one_sheet.append(robot_leftSpeed) #实际左轮速度
    one_sheet.append(robot_rightSpeed) #实际右轮速度
    one_sheet.append(robot_trans_speed) #实际速度
    one_sheet.append(robot_rot_speed)   #实际角速度
    one_sheet.append(robot_transaccel)  #实际加速度
    one_sheet.append(robot_angle_transaccel)  # 实际角加速度
    one_sheet.append(endtime - starttime)
    sheet.append(one_sheet)
    one_sheet = []


writeFileObj = open('A_T2FPDC.csv', 'w')
csv_writer = csv.writer(writeFileObj)
writer = csv_writer
for row in sheet:
    writer.writerow(row)
writeFileObj.close()