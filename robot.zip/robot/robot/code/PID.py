# -*- coding: utf-8 -*-
import numpy as np
#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
ARIA Python 绑定最简测试案例：MobileSim 仿真机器人控制
不使用显式初始化，直接创建机器人对象
"""
# -*- coding: utf-8 -*-
import AriaPy
from AriaPy import *  # 恢复完整导入以确保所有AriaPy函数可用
from pep import *
import sys
import xlrd
import keyboard  # 替换pythoncom和pyHook，更适合Python 3

import threading
import csv
import numpy as np
import time
import math
import sys
import time
from AriaPy import *
import sys
import pythoncom
import threading
import csv
import numpy as np
import time
import math
# 添加 ARIA Python 绑定路径
sys.path.append(r'C:\robot\ARIA\python3')
try:
    import AriaPy
    print("成功导入 AriaPy 模块")
except ImportError:
    print("错误：无法导入 AriaPy 模块")
    sys.exit(1)
# 创建机器人对象
print("创建机器人对象...")
robot = AriaPy.ArRobot()

# 用于决定程序是否继续运行
# 1 继续运行, 0 停止
# 按键 "q" 可以停止程序并收集数据
flag = 1

def key_press_handler(e):
    """处理键盘按键事件"""
    global flag
    print(f"按下了键: {e.name}")
    if e.name.lower() == "q":
        print("检测到Q键，准备停止程序...")
        flag = 0
        return False  # 停止监听

def setup_keyboard_listener():
    """设置键盘监听器"""
    keyboard.on_press(key_press_handler)

# 创建线程监听键盘事件
def start_keyboard_listener():
    """启动键盘监听线程"""
    t = threading.Thread(target=setup_keyboard_listener)
    t.daemon = True
    t.start()
    return t
# 启动键盘监听
keyboard_thread = start_keyboard_listener()
print("按 'Q' 键可停止程序")


filename='Pid1.csv'
class WallFollowingPIDController:
    def __init__(self, set_distance=300):
        """
        初始化PID控制器

        参数:
        set_distance: 机器人与墙壁之间的目标距离(mm)
        is_left_wall: 是否跟随左侧墙壁，False表示跟随右侧墙壁
        """
        self.set_distance = set_distance
        global filename

        # 根据论文中的PID参数设置
        # 墙壁-机器人距离PID参数
        self.kp_distance = 0.95
        self.ki_distance = 0.001
        self.kd_distance = 0.05

        # 墙壁-机器人平行PID参数
        self.kp_parallel = 0.95
        self.ki_parallel = 0.001
        self.kd_parallel = 0.1
        # # 墙壁-机器人距离PID参数
        # self.kp_distance = 0.8   #0.8
        # self.ki_distance = 0.010 #0.01
        # self.kd_distance = 0.05   #0.05
        #
        # # 墙壁-机器人平行PID参数
        # self.kp_parallel = 1.5    #0.95
        # self.ki_parallel = 0.015   #0.01
        # self.kd_parallel = 0.1   #0.1
        filename = 'pid1.csv'
        # 累积误差和上一次误差初始化
        self.distance_error_sum = 0
        self.parallel_error_sum = 0
        self.last_distance_error = 0
        self.last_parallel_error = 0

        # 机器人轮子半径和轮距（根据Pioneer P3-DX规格）
        self.wheel_radius = 0.0975  # 单位: m
        self.wheel_distance = 0.381  # 单位: m

        # 基础PWM值（论文中的nominal PWM）
        self.base_pwm = 300

    def reset(self):
        """重置PID控制器状态"""
        self.distance_error_sum = 0
        self.parallel_error_sum = 0
        self.last_distance_error = 0
        self.last_parallel_error = 0

    def compute_control(self, sonar_readings):
        """
        计算PID控制输出

        参数:
        sonar_readings: 超声波传感器读数列表，长度为8

        返回:
        left_pwm: 左轮PWM值
        right_pwm: 右轮PWM值
        """

            # 右侧墙壁跟随使用传感器 0, 1, 2
        head_sensor = sonar_readings[3]
        front_sensor = sonar_readings[1]  # 前方传感器
        side_sensor = sonar_readings[0]  # 侧面传感器


        # 计算平行误差 (根据论文中的公式3)
        # 传感器之间的角度（根据Pioneer P3-DX传感器布局）
        theta = np.radians(41.4)  # 相邻传感器之间的角度约为20度

        # 计算机器人是否平行于墙壁的误差
        #parallel_error = front_sensor - side_sensor / np.cos(theta) + head_sensor- side_sensor/ np.cos(np.radians(64.4))
        #lin=math.sqrt(front_sensor*front_sensor+side_sensor*side_sensor-2*front_sensor*side_sensor*np.cos(theta))
        #parallel_error=front_sensor*np.sin(theta)/lin-np.sin(np.radians(85))

        parallel_error = front_sensor - side_sensor / np.cos(theta)
        #print(parallel_error)
        # 计算距离误差 (根据论文中的公式4)
        distance_error = (side_sensor -2*self.set_distance+head_sensor*np.cos(np.radians(80)))

        #print("distance_error",distance_error)
        # 计算距离PID控制器输出
        p_term_distance = self.kp_distance * distance_error
        self.distance_error_sum += distance_error
        i_term_distance = self.ki_distance * self.distance_error_sum
        d_term_distance = self.kd_distance * (distance_error - self.last_distance_error)
        distance_pid_output = p_term_distance + i_term_distance + d_term_distance

        # 计算平行PID控制器输出
        p_term_parallel = self.kp_parallel * parallel_error
        self.parallel_error_sum += parallel_error
        i_term_parallel = self.ki_parallel * self.parallel_error_sum
        d_term_parallel = self.kd_parallel * (parallel_error - self.last_parallel_error)
        parallel_pid_output = p_term_parallel + i_term_parallel + d_term_parallel

        # 更新上一次误差
        self.last_distance_error = distance_error
        self.last_parallel_error = parallel_error

        # 计算最终PWM输出 (根据论文中的公式5和6)

        left_pwm = self.base_pwm + distance_pid_output +0.5*parallel_pid_output    #0.5
        right_pwm = self.base_pwm - distance_pid_output -0.5*parallel_pid_output   #0.5

        return left_pwm, right_pwm


start_time=time.time()
# 创建 TCP 连接 (MobileSim 默认使用 TCP)
print("创建 TCP 连接...")
conn = AriaPy.ArTcpConnection()
conn.setPort("localhost", 8101)  # MobileSim 默认端口

# 设置机器人连接
print("设置机器人连接...")
robot.setDeviceConnection(conn)
if not robot.blockingConnect():
    print("错误：无法连接到仿真机器人")
robot.runAsync(True)
# 添加声纳设备
print("添加声纳设备...")
sonar = ArSonarDevice()
robot.addRangeDevice(sonar)
# 等待机器人准备就绪
print("等待机器人准备就绪...")
#time.sleep(1)
# 启用电机
print("启用电机...")
robot.enableMotors()
print("机器人初始化完成")



# 数据收集变量
one_sheet = []
sheet = []

# 创建PID控制器实例
#pid_controller = WallFollowingPIDController(set_distance=600, is_left_wall=True)
last_speed=0
last_angle_speed=0
pid_controller = WallFollowingPIDController(set_distance=300)
starttime=time.perf_counter()
while flag:


    numSonar = robot.getNumSonar()
    sonarReading = []
    ac_start_time = time.perf_counter() #收集数据起始时间
    # 收集一组数据
    for i in range(0, numSonar):
        reading = round(robot.getSonarReading(i).getRange())
        reading=reading-100
        if reading > 1000:
            reading = 1000
        sonarReading.append(reading)
        one_sheet.append(reading)
    print(sonarReading[3],sonarReading[2],sonarReading[1],sonarReading[0])
    # # 计算控制输出
    #left_pwm, right_pwm = pid_controller.compute_control(sonarReading)
    # print(f"左轮PWM: {left_pwm}, 右轮PWM: {right_pwm}")

    # 切换到右侧墙壁跟随
    time_1=time.perf_counter()
    left_pwm, right_pwm = pid_controller.compute_control(sonarReading)
    ac_start_time = time.perf_counter() #收集数据起始时间
    time_2=time.perf_counter()
    robot_query_time = time_2 - time_1
    print(f"右侧墙壁跟随 - 左轮PWM: {left_pwm}, 右轮PWM: {right_pwm}")
    leftSpeed = left_pwm
    rightSpeed = right_pwm
    robot.lock()
    robot.setVel2( rightSpeed,leftSpeed)
    robot.unlock()
    time.sleep(0.05)
    robot.lock()
    end_time=time.time()
    robot_leftSpeed = robot.getLeftVel()
    robot_rightSpeed = robot.getRightVel()
    robot_trans_speed = robot.getVel()
    robot_rot_speed = robot.getRotVel()
    robot.unlock()
    ac_end_time = time.perf_counter()
    endtime = time.perf_counter()


    # print(end_time-start_time)
    # flag = 0

    robot_transaccel = (robot_trans_speed-last_speed)/(ac_end_time-ac_start_time)
    robot_angle_transaccel = (robot_rot_speed - last_angle_speed) / (ac_end_time - ac_start_time)
    last_angle_speed = robot_rot_speed
    last_speed=robot_trans_speed
    # 记录数据
    #one_sheet.append(robot_query_time)  # 执行时间
    one_sheet.append(leftSpeed)  #计算左轮速度
    one_sheet.append(rightSpeed) #计算右轮速度
    one_sheet.append(robot_leftSpeed) #实际左轮速度
    one_sheet.append(robot_rightSpeed) #实际右轮速度
    one_sheet.append(robot_trans_speed) #实际速度
    one_sheet.append(robot_rot_speed)   #实际角速度
    one_sheet.append(robot_transaccel)  #实际加速度
    one_sheet.append(robot_angle_transaccel)  # 实际角加速度
    one_sheet.append(ac_end_time - ac_start_time)  # 计算时间
    one_sheet.append(robot.getX())  # 计算时间
    one_sheet.append(robot.getY())  # 计算时间
    one_sheet.append(endtime - starttime)  # 调整时间
    sheet.append(one_sheet)
    one_sheet = []


writeFileObj = open(filename, 'w')
csv_writer = csv.writer(writeFileObj)
writer = csv_writer
for row in sheet:
    writer.writerow(row)
writeFileObj.close()