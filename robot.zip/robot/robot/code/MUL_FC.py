# -*- coding: utf-8 -*- #
from AriaPy import *
import sys
import pythoncom

import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import threading
import xlrd
import csv

import math
import gc

import numpy as np
#!/usr/bin/env python

"""
ARIA Python 绑定最简测试案例：MobileSim 仿真机器人控制
不使用显式初始化，直接创建机器人对象
"""
import AriaPy
from AriaPy import *  # 恢复完整导入以确保所有AriaPy函数可用
from pep import *
import sys
import xlrd
import keyboard  # 替换pythoncom和pyHook，更适合Python 3
import threading
import csv
import numpy as np
import time
import math
import sys
import time
from AriaPy import *
import sys
import pythoncom
import threading
import csv
import numpy as np
import time
import math
# 添加 ARIA Python 绑定路径
sys.path.append(r'C:\robot\ARIA\python3')
try:
    import AriaPy
    print("成功导入 AriaPy 模块")
except ImportError:
    print("错误：无法导入 AriaPy 模块")
    sys.exit(1)
# 创建机器人对象
print("创建机器人对象...")
robot = AriaPy.ArRobot()

# 用于决定程序是否继续运行
# 1 继续运行, 0 停止
# 按键 "q" 可以停止程序并收集数据
flag = 1

def key_press_handler(e):
    """处理键盘按键事件"""
    global flag
    print(f"按下了键: {e.name}")
    if e.name.lower() == "q":
        print("检测到Q键，准备停止程序...")
        flag = 0
        return False  # 停止监听

def setup_keyboard_listener():
    """设置键盘监听器"""
    keyboard.on_press(key_press_handler)

# 创建线程监听键盘事件
def start_keyboard_listener():
    """启动键盘监听线程"""
    t = threading.Thread(target=setup_keyboard_listener)
    t.daemon = True
    t.start()
    return t
# 启动键盘监听
keyboard_thread = start_keyboard_listener()
print("按 'Q' 键可停止程序")

def gaussmf(x, mean, sigma):
    """
    Gaussian fuzzy membership function.
    Parameters
    ----------
    x : 1d array or iterable
        Independent variable.
    mean : float
        Gaussian parameter for center (mean) value.
    sigma : float
        Gaussian parameter for standard deviation.
    Returns
    -------
    y : 1d array
        Gaussian membership function for x.
    """
    return np.exp(-((x - mean)**2.) / (2 * sigma**2.))





start_time=time.time()
# 创建 TCP 连接 (MobileSim 默认使用 TCP)
print("创建 TCP 连接...")
conn = AriaPy.ArTcpConnection()
conn.setPort("localhost", 8101)  # MobileSim 默认端口

# 设置机器人连接
print("设置机器人连接...")
robot.setDeviceConnection(conn)
if not robot.blockingConnect():
    print("错误：无法连接到仿真机器人")
robot.runAsync(True)
# 添加声纳设备
print("添加声纳设备...")
sonar = ArSonarDevice()
robot.addRangeDevice(sonar)
# 等待机器人准备就绪
print("等待机器人准备就绪...")
#time.sleep(1)
# 启用电机
print("启用电机...")
robot.enableMotors()
print("机器人初始化完成")

#距离传感器S4-S7的取值范围设定
S4_array = np.arange(0, 1001, 1) #S4的取值范围0-1000MM
S5_array = np.arange(0, 1001, 1)#S5的取值范围0-1000MM
S6_array = np.arange(0, 1001, 1) #S6的取值范围0-1000MM
S7_array = np.arange(0, 1001, 1) #S7的取值范围0-1000MM

leftspeed_array = np.arange(-100, 801, 3)  # leftspeed的取值范围-100-900MM/S
rightspeed_array = np.arange(-100, 801, 3)  # rightspeed的取值范围-100-900MM/S
#workbook = xlrd.open_workbook(r'C:/Users/13979/Desktop/ensnp/zzm/data/best.xls')
#sheet1 = workbook.sheet_by_index(0)  # 假设数据在第一个工作表中
# init_population = []
# for row_index in range(sheet1.nrows):
#     row_init_population = []
#     for col_index in range(sheet1.ncols):
#         cell_value = sheet1.cell_value(row_index, col_index)
#         row_init_population.append(cell_value)
#     init_population.append(row_init_population)
# Superorganism = init_population
# individual_index = 0

speed=350
leftspeed_slow = gaussmf(leftspeed_array, speed-290,75)  #10 75
leftspeed_normal = gaussmf(leftspeed_array, speed, 75)# 430 80
leftspeed_quick = gaussmf(leftspeed_array, speed+200, 75)# 510 75
leftspeed_fast = gaussmf(leftspeed_array, speed+350, 40)# 650 40

rightspeed_slow = gaussmf(rightspeed_array, speed-290, 75)# 10  75
rightspeed_normal = gaussmf(rightspeed_array, speed, 75)# 430 80
rightspeed_quick = gaussmf(rightspeed_array, speed+200, 75)# 510 75
rightspeed_fast = gaussmf(rightspeed_array, speed+350, 40) # 650 40


#
# # 模糊控制器规则
# rule1 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['normal'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule2 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule3 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule4 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule5 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['close'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule6 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule7 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['normal'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule8 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule9 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['far'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule10 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['remote'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule11 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['far'], consequent=[leftspeed['fast'],rightspeed['normal']])  #
# rule12 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['slow']])  #
# rule13 = ctrl.Rule(S4['remote'] & S5['far'] & S6['normal'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule14 = ctrl.Rule(S4['remote'] & S5['far'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule15 = ctrl.Rule(S4['remote'] & S5['far'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule16 = ctrl.Rule(S4['remote'] & S5['far'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule17 = ctrl.Rule(S4['remote'] & S5['far'] & S6['close'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule18 = ctrl.Rule(S4['remote'] & S5['far'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule19 = ctrl.Rule(S4['remote'] & S5['far'] & S6['normal'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule20 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule21 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['far'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule22 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['remote'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule23 = ctrl.Rule(S4['remote'] & S5['far'] & S6['remote'] & S7['far'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule24 = ctrl.Rule(S4['remote'] & S5['far'] & S6['remote'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule25 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule26 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule27 = ctrl.Rule(S4['remote'] & S5['far'] & S6['remote'] & S7['close'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule28 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule29 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule30 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule31 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])  #
# rule32 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule33 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule34 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule35 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule36 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule37 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule38 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule39= ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule40 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule41 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule42 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule43= ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule44 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule45 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule46 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule47 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule48 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule49 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['close'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule50 = ctrl.Rule(S4['normal'] & S5['near'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule51 = ctrl.Rule(S4['normal'] & S5['near'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule52 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule53 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule54 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule55 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule56 = ctrl.Rule(S4['far'] & S5['remote'] & S6['close'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['slow']])  ###
# rule57 = ctrl.Rule(S4['far'] & S5['remote'] & S6['normal'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule58 = ctrl.Rule(S4['far'] & S5['remote'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule59 = ctrl.Rule(S4['far'] & S5['remote'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule60 = ctrl.Rule(S4['far'] & S5['remote'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule61 = ctrl.Rule(S4['far'] & S5['remote'] & S6['close'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule62 = ctrl.Rule(S4['far'] & S5['remote'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule63 = ctrl.Rule(S4['far'] & S5['remote'] & S6['normal'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule64 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule65 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule66 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule67 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['far'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule68 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule69 = ctrl.Rule(S4['near'] & S5['near'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule70 = ctrl.Rule(S4['near'] & S5['near'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule71 = ctrl.Rule(S4['near'] & S5['near'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule72 = ctrl.Rule(S4['near'] & S5['near'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule73 = ctrl.Rule(S4['near'] & S5['near'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['slow']])
# rule74 = ctrl.Rule(S4['near'] & S5['near'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule75 = ctrl.Rule(S4['near'] & S5['near'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule76 = ctrl.Rule(S4['near'] & S5['near'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule77 = ctrl.Rule(S4['near'] & S5['normal'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule78 = ctrl.Rule(S4['near'] & S5['normal'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule79 = ctrl.Rule(S4['near'] & S5['normal'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule80 = ctrl.Rule(S4['near'] & S5['normal'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule81 = ctrl.Rule(S4['near'] & S5['normal'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule82 = ctrl.Rule(S4['near'] & S5['normal'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule83 = ctrl.Rule(S4['near'] & S5['normal'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule84 = ctrl.Rule(S4['near'] & S5['normal'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule85 = ctrl.Rule(S4['close'] & S5['close'] , consequent=[leftspeed['slow'],rightspeed['fast']])


# rule1 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule2 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule3 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule4 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['close'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule5 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule6 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['normal'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule7 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule8 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['far'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule9 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['remote'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule10 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['far'], consequent=[leftspeed['fast'],rightspeed['slow']])
# rule11 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule12 = ctrl.Rule(S4['remote'] & S5['far'] & S6['normal'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule13 = ctrl.Rule(S4['remote'] & S5['far'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule14 = ctrl.Rule(S4['remote'] & S5['far'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule15 = ctrl.Rule(S4['remote'] & S5['far'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule16 = ctrl.Rule(S4['remote'] & S5['far'] & S6['close'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule17 = ctrl.Rule(S4['remote'] & S5['far'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule18 = ctrl.Rule(S4['remote'] & S5['far'] & S6['normal'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule19 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule20 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['far'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule21 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['remote'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule22 = ctrl.Rule(S4['remote'] & S5['far'] & S6['remote'] & S7['far'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule23 = ctrl.Rule(S4['remote'] & S5['far'] & S6['remote'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule24 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule25 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule26 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule27 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule28 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule29 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule30 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule31 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule32 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule33 = ctrl.Rule(S4['normal'] & S5['normal'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule34 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule35 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule36 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule37 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule38 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule39 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule40 = ctrl.Rule(S4['normal'] & S5['near'] & S6['normal'] & S7['close'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule41 = ctrl.Rule(S4['normal'] & S5['near'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule42 = ctrl.Rule(S4['normal'] & S5['near'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule43 = ctrl.Rule(S4['normal'] & S5['near'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule44 = ctrl.Rule(S4['near'] & S5['normal'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule45 = ctrl.Rule(S4['near'] & S5['normal'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule46 = ctrl.Rule(S4['near'] & S5['normal'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule47 = ctrl.Rule(S4['near'] & S5['normal'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule48 = ctrl.Rule(S4['near'] & S5['normal'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule49 = ctrl.Rule(S4['near'] & S5['normal'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule50 = ctrl.Rule(S4['near'] & S5['normal'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule51 = ctrl.Rule(S4['near'] & S5['normal'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule52 = ctrl.Rule(S4['close'] & S5['close'] , consequent=[leftspeed['slow'],rightspeed['fast']])
# rule53 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule54 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule55 = ctrl.Rule(S4['remote'] & S5['far'] & S6['remote'] & S7['close'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule56 = ctrl.Rule(S4['remote'] & S5['far'] & S6['far'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule57 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule58 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule59 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule60 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['quick'],rightspeed['slow']])
# rule61 = ctrl.Rule(S4['far'] & S5['remote'] & S6['normal'] & S7['normal'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule62 = ctrl.Rule(S4['far'] & S5['remote'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule63 = ctrl.Rule(S4['far'] & S5['remote'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule64 = ctrl.Rule(S4['far'] & S5['remote'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule65 = ctrl.Rule(S4['far'] & S5['remote'] & S6['close'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule66 = ctrl.Rule(S4['far'] & S5['remote'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule67 = ctrl.Rule(S4['far'] & S5['remote'] & S6['normal'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule68 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule69 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule70 = ctrl.Rule(S4['far'] & S5['remote'] & S6['far'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule71 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['far'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule72 = ctrl.Rule(S4['far'] & S5['remote'] & S6['remote'] & S7['remote'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule73 = ctrl.Rule(S4['near'] & S5['near'] & S6['normal'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule74 = ctrl.Rule(S4['near'] & S5['near'] & S6['normal'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule75 = ctrl.Rule(S4['near'] & S5['near'] & S6['near'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule76 = ctrl.Rule(S4['near'] & S5['near'] & S6['near'] & S7['normal'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule77 = ctrl.Rule(S4['near'] & S5['near'] & S6['normal'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['slow']])
# rule78 = ctrl.Rule(S4['near'] & S5['near'] & S6['far'] & S7['far'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule79 = ctrl.Rule(S4['near'] & S5['near'] & S6['close'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['fast']])
# rule80 = ctrl.Rule(S4['near'] & S5['near'] & S6['near'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['quick']])
# rule81 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['near'], consequent=[leftspeed['normal'],rightspeed['slow']])
# rule82 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule83 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['far'] & S7['near'], consequent=[leftspeed['slow'],rightspeed['normal']])
# rule84 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['near'], consequent=[leftspeed['normal'],rightspeed['normal']])
# rule85 = ctrl.Rule(S4['remote'] & S5['remote'] & S6['remote'] & S7['close'], consequent=[leftspeed['slow'],rightspeed['normal']])
# #初始化模糊控制器并开始模拟

step = 0
sheet = []

last_speed=0
last_angle_speed=0
sdt=0
while flag:
    leftspeed_slow_array = []
    leftspeed_normal_array = []
    leftspeed_quick_array = []
    leftspeed_fast_array = []
    rightspeed_slow_array = []
    rightspeed_normal_array = []
    rightspeed_quick_array = []
    rightspeed_fast_array = []
    leftspeed_array_1 = []
    rightspeed_array_1 = []
    ac_start_time = time.perf_counter()
    step = step+1
    numSonar = robot.getNumSonar()
    sonarReading = []
    # collect one group data
    one_sheet = []
    for i in range(0, numSonar):
        reading = round(robot.getSonarReading(i).getRange())
        if reading > 1000:
            reading = 1000
        one_sheet.append(reading)
        reading=-1*reading+1000
        sonarReading.append(reading)

    S4 = sonarReading[3]
    S5 = sonarReading[2]
    S6 = sonarReading[1]
    S7 = sonarReading[0]
    distance=300
    S4_close = gaussmf(S4, distance-150, 75)
    S4_near = gaussmf(S4, distance, 125)
    S4_normal = gaussmf(S4, distance+150, 150)
    S4_far = gaussmf(S4, distance+350, 75)
    S4_remote = gaussmf(S4, distance+600, 50)

    S5_close = gaussmf(S5, distance-200, 50)
    S5_near = gaussmf(S5, distance, 125)
    S5_normal = gaussmf(S5, distance+200, 100)
    S5_far = gaussmf(S5, distance+400, 100)
    S5_remote = gaussmf(S5, distance+600, 50)

    S6_close = gaussmf(S6, distance-250, 50)
    S6_near = gaussmf(S6, distance-50, 100)
    S6_normal = gaussmf(S6, distance+100, 75)
    S6_far = gaussmf(S6, distance+300, 100)
    S6_remote = gaussmf(S6, distance+550, 55)

    S7_close = gaussmf(S7, distance-250, 50)
    S7_near = gaussmf(S7, distance-100, 100)
    S7_normal = gaussmf(S7, distance, 75)
    S7_far = gaussmf(S7, distance+200, 125)
    S7_remote = gaussmf(S7, distance+550, 55)



    # 模糊控制器规则转化
    #rule1
    leftspeed_normal_array.append(S4_remote*S5_remote*S6_normal*S7_normal)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_normal*S7_normal)
    #rule2
    leftspeed_slow_array.append(S4_remote*S5_remote*S6_near*S7_normal)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_near*S7_normal)
    #rule3
    leftspeed_slow_array.append(S4_remote*S5_remote*S6_near*S7_near)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_near*S7_near)
    #rule4
    leftspeed_slow_array.append(S4_remote*S5_remote*S6_near*S7_close)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_near*S7_close)
    #rule5
    leftspeed_slow_array.append(S4_remote*S5_remote* S6_close* S7_near)
    rightspeed_fast_array.append(S4_remote*S5_remote* S6_close* S7_near)
    # rule6
    leftspeed_slow_array.append(S4_remote* S5_remote*S6_close*S7_close)
    rightspeed_fast_array.append(S4_remote* S5_remote*S6_close*S7_close)
    # rule7
    leftspeed_slow_array.append(S4_remote* S5_remote*S6_normal*S7_far)
    rightspeed_normal_array.append(S4_remote* S5_remote*S6_normal*S7_far)
    # rule8
    leftspeed_normal_array.append(S4_remote* S5_remote*S6_far*S7_normal)
    rightspeed_slow_array.append(S4_remote* S5_remote*S6_far*S7_normal)
    # rule9
    leftspeed_normal_array.append(S4_remote*S5_remote*S6_far*S7_far)
    rightspeed_slow_array.append(S4_remote*S5_remote*S6_far*S7_far)
    # rule10
    leftspeed_slow_array.append(S4_remote*S5_remote*S6_far*S7_remote)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_far*S7_remote)
    # rule11
    leftspeed_fast_array.append(S4_remote*S5_remote* S6_remote*S7_far)
    rightspeed_normal_array.append(S4_remote*S5_remote* S6_remote*S7_far)
    # rule12
    leftspeed_normal_array.append(S4_remote*S5_remote*S6_remote*S7_remote)
    rightspeed_slow_array.append(S4_remote*S5_remote*S6_remote*S7_remote)
    # rule13
    leftspeed_normal_array.append(S4_remote*S5_far*S6_normal*S7_normal)
    rightspeed_normal_array.append(S4_remote*S5_far*S6_normal*S7_normal)
    # rule14
    leftspeed_slow_array.append(S4_remote*S5_far* S6_near* S7_normal)
    rightspeed_normal_array.append(S4_remote*S5_far* S6_near* S7_normal)
    # rule15
    leftspeed_slow_array.append(S4_remote*S5_far*S6_near*S7_near)
    rightspeed_normal_array.append(S4_remote*S5_far*S6_near*S7_near)
    # rule16
    leftspeed_slow_array.append(S4_remote*S5_far* S6_near*S7_close)
    rightspeed_normal_array.append(S4_remote*S5_far* S6_near*S7_close)
    # rule17
    leftspeed_slow_array.append(S4_remote*S5_far* S6_close*S7_near)
    rightspeed_fast_array.append(S4_remote*S5_far* S6_close*S7_near)
    # rule18
    leftspeed_slow_array.append(S4_remote*S5_far* S6_close*S7_close)
    rightspeed_fast_array.append(S4_remote*S5_far* S6_close*S7_close)
    # rule19
    leftspeed_slow_array.append(S4_remote*S5_far*S6_normal*S7_far)
    rightspeed_normal_array.append(S4_remote*S5_far*S6_normal*S7_far)
    # rule20
    leftspeed_normal_array.append(S4_remote* S5_far*S6_far*S7_normal)
    rightspeed_slow_array.append(S4_remote* S5_far*S6_far*S7_normal)
    # rule21
    leftspeed_normal_array.append(S4_remote*S5_far* S6_far* S7_far)
    rightspeed_normal_array.append(S4_remote*S5_far* S6_far* S7_far)
    # rule22
    leftspeed_slow_array.append(S4_remote* S5_far* S6_far* S7_remote)
    rightspeed_normal_array.append(S4_remote* S5_far* S6_far* S7_remote)
    # rule23
    leftspeed_quick_array.append(S4_remote*S5_far* S6_remote* S7_far)
    rightspeed_slow_array.append(S4_remote*S5_far* S6_remote* S7_far)
    # rule24
    leftspeed_normal_array.append(S4_remote* S5_far* S6_remote* S7_remote)
    rightspeed_slow_array.append(S4_remote* S5_far* S6_remote* S7_remote)
    # rule25
    leftspeed_quick_array.append(S4_remote*S5_remote*S6_far*S7_near)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_far*S7_near)
    # rule26
    leftspeed_slow_array.append(S4_remote* S5_remote*S6_remote* S7_close)
    rightspeed_normal_array.append(S4_remote* S5_remote*S6_remote* S7_close)
    # rule27
    leftspeed_quick_array.append(S4_remote*S5_far* S6_remote*S7_close)
    rightspeed_normal_array.append(S4_remote*S5_far* S6_remote*S7_close)
    # rule28
    leftspeed_quick_array.append(S4_remote* S5_far*S6_far* S7_near)
    rightspeed_slow_array.append(S4_remote* S5_far*S6_far* S7_near)
    # rule29
    leftspeed_slow_array.append(S4_remote* S5_remote* S6_far*S7_close)
    rightspeed_normal_array.append(S4_remote* S5_remote* S6_far*S7_close)
    # rule30
    leftspeed_slow_array.append(S4_remote* S5_remote*S6_far* S7_near)
    rightspeed_normal_array.append(S4_remote* S5_remote*S6_far* S7_near)
    # rule31
    leftspeed_normal_array.append(S4_remote*S5_remote*S6_remote* S7_near)
    rightspeed_normal_array.append(S4_remote*S5_remote*S6_remote* S7_near)
    # rule32
    leftspeed_quick_array.append(S4_remote*S5_remote*S6_remote* S7_near)
    rightspeed_slow_array.append(S4_remote*S5_remote*S6_remote* S7_near)
    # rule33
    leftspeed_slow_array.append(S4_normal*S5_normal* S6_normal*S7_normal)
    rightspeed_normal_array.append(S4_normal*S5_normal* S6_normal*S7_normal)
    # rule34
    leftspeed_slow_array.append(S4_normal* S5_normal*S6_normal* S7_near)
    rightspeed_fast_array.append(S4_normal* S5_normal*S6_normal* S7_near)
    # rule35
    leftspeed_slow_array.append(S4_normal*S5_normal*S6_normal* S7_close)
    rightspeed_fast_array.append(S4_normal*S5_normal*S6_normal* S7_close)
    # rule36
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_near* S7_near)
    rightspeed_quick_array.append(S4_normal* S5_normal* S6_near* S7_near)
    # rule37
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_near* S7_normal)
    rightspeed_quick_array.append(S4_normal* S5_normal* S6_near* S7_normal)
    # rule38
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_near* S7_close)
    rightspeed_quick_array.append(S4_normal* S5_normal* S6_near* S7_close)
    # rule39
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_normal* S7_close)
    rightspeed_normal_array.append(S4_normal* S5_normal* S6_normal* S7_close)
    # rule40
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_far* S7_far)
    rightspeed_quick_array.append(S4_normal* S5_normal* S6_far* S7_far)
    # rule41
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_close* S7_close)
    rightspeed_quick_array.append(S4_normal* S5_normal* S6_close* S7_close)
    # rule42
    leftspeed_slow_array.append(S4_normal* S5_normal* S6_near* S7_close)
    rightspeed_normal_array.append(S4_normal* S5_normal* S6_near* S7_close)
    # rule43
    leftspeed_slow_array.append(S4_normal* S5_near* S6_normal* S7_normal)
    rightspeed_normal_array.append(S4_normal* S5_near* S6_normal* S7_normal)
    # rule44
    leftspeed_slow_array.append(S4_normal* S5_near*S6_normal* S7_near)
    rightspeed_quick_array.append(S4_normal* S5_near*S6_normal* S7_near)
    # rule45
    leftspeed_slow_array.append(S4_normal* S5_near* S6_normal* S7_close)
    rightspeed_quick_array.append(S4_normal* S5_near* S6_normal* S7_close)
    # rule46
    leftspeed_slow_array.append(S4_normal* S5_near* S6_near*S7_near)
    rightspeed_normal_array.append(S4_normal* S5_near* S6_near*S7_near)
    # rule47
    leftspeed_slow_array.append(S4_normal* S5_near* S6_near* S7_normal)
    rightspeed_quick_array.append(S4_normal* S5_near* S6_near* S7_normal)
    # rule48
    leftspeed_slow_array.append(S4_normal* S5_near* S6_near* S7_close)
    rightspeed_fast_array.append(S4_normal* S5_near* S6_near* S7_close)
    # rule49
    leftspeed_normal_array.append(S4_normal* S5_near* S6_normal* S7_close)
    rightspeed_normal_array.append(S4_normal* S5_near* S6_normal* S7_close)
    # rule50
    leftspeed_slow_array.append(S4_normal* S5_near* S6_far* S7_far)
    rightspeed_fast_array.append(S4_normal* S5_near* S6_far* S7_far)
    # rule51
    leftspeed_slow_array.append(S4_normal* S5_near* S6_close* S7_close)
    rightspeed_fast_array.append(S4_normal* S5_near* S6_close* S7_close)
    # rule52
    leftspeed_slow_array.append(S4_normal* S5_near* S6_near* S7_close)
    rightspeed_normal_array.append(S4_normal* S5_near* S6_near* S7_close)
    # rule53
    leftspeed_slow_array.append(S4_far* S5_remote* S6_far*S7_near)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_far*S7_near)
    # rule54
    leftspeed_slow_array.append(S4_far* S5_remote* S6_remote* S7_close)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_remote* S7_close)
    # rule55
    leftspeed_quick_array.append(S4_far* S5_remote* S6_far* S7_near)
    rightspeed_slow_array.append(S4_far* S5_remote* S6_far* S7_near)
    # rule56
    leftspeed_normal_array.append(S4_far* S5_remote* S6_close* S7_normal)
    rightspeed_slow_array.append(S4_far* S5_remote* S6_close* S7_normal)
    # rule57
    leftspeed_normal_array.append(S4_far* S5_remote* S6_normal* S7_normal)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_normal* S7_normal)
    # rule58
    leftspeed_slow_array.append(S4_far* S5_remote* S6_near* S7_normal)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_near* S7_normal)
    # rule59
    leftspeed_slow_array.append(S4_far* S5_remote* S6_near* S7_near)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_near* S7_near)
    # rule60
    leftspeed_slow_array.append(S4_far* S5_remote* S6_near* S7_close)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_near* S7_close)
    # rule61
    leftspeed_slow_array.append(S4_far* S5_remote* S6_close* S7_near)
    rightspeed_fast_array.append(S4_far* S5_remote* S6_close* S7_near)
    # rule62
    leftspeed_slow_array.append(S4_far* S5_remote* S6_close* S7_close)
    rightspeed_fast_array.append(S4_far* S5_remote* S6_close* S7_close)
    # rule63
    leftspeed_slow_array.append(S4_far* S5_remote* S6_normal* S7_far)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_normal* S7_far)
    # rule64
    leftspeed_slow_array.append(S4_far* S5_remote* S6_far* S7_normal)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_far* S7_normal)
    # rule65
    leftspeed_slow_array.append(S4_far* S5_remote* S6_far* S7_far)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_far* S7_far)
    # rule66
    leftspeed_normal_array.append(S4_far* S5_remote* S6_far* S7_remote)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_far* S7_remote)
    # rule67
    leftspeed_normal_array.append(S4_far* S5_remote* S6_remote* S7_far)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_remote* S7_far)
    # rule68
    leftspeed_normal_array.append(S4_far* S5_remote* S6_remote* S7_remote)
    rightspeed_normal_array.append(S4_far* S5_remote* S6_remote* S7_remote)
    # rule69
    leftspeed_slow_array.append(S4_near* S5_near* S6_normal* S7_normal)
    rightspeed_quick_array.append(S4_near* S5_near* S6_normal* S7_normal)
    # rule70
    leftspeed_slow_array.append(S4_near* S5_near* S6_normal* S7_near)
    rightspeed_quick_array.append(S4_near* S5_near* S6_normal* S7_near)
    # rule71
    leftspeed_slow_array.append(S4_near* S5_near* S6_near* S7_near)
    rightspeed_quick_array.append(S4_near* S5_near* S6_near* S7_near)
    # rule72
    leftspeed_slow_array.append(S4_near* S5_near* S6_near* S7_normal)
    rightspeed_fast_array.append(S4_near* S5_near* S6_near* S7_normal)
    # rule73
    leftspeed_normal_array.append(S4_near* S5_near* S6_normal* S7_close)
    rightspeed_slow_array.append(S4_near* S5_near* S6_normal* S7_close)
    # rule74
    leftspeed_slow_array.append(S4_near*S5_near* S6_far* S7_far)
    rightspeed_quick_array.append(S4_near*S5_near* S6_far* S7_far)
    # rule75
    leftspeed_slow_array.append(S4_near* S5_near* S6_close* S7_close)
    rightspeed_fast_array.append(S4_near* S5_near* S6_close* S7_close)
    # rule76
    leftspeed_slow_array.append(S4_near*S5_near*S6_near*S7_close)
    rightspeed_quick_array.append(S4_near*S5_near*S6_near*S7_close)
    # rule77
    leftspeed_slow_array.append(S4_near* S5_normal*S6_normal* S7_normal)
    rightspeed_normal_array.append(S4_near* S5_normal*S6_normal* S7_normal)
    # rule78
    leftspeed_slow_array.append(S4_near* S5_normal* S6_normal* S7_near)
    rightspeed_quick_array.append(S4_near* S5_normal* S6_normal* S7_near)
    # rule79
    leftspeed_slow_array.append(S4_near* S5_normal* S6_near* S7_near)
    rightspeed_normal_array.append(S4_near* S5_normal* S6_near* S7_near)
    # rule80
    leftspeed_slow_array.append(S4_near* S5_normal* S6_near* S7_normal)
    rightspeed_quick_array.append(S4_near* S5_normal* S6_near* S7_normal)
    # rule81
    leftspeed_slow_array.append(S4_near* S5_normal* S6_normal*S7_close)
    rightspeed_quick_array.append(S4_near* S5_normal* S6_normal*S7_close)
    # rule82
    leftspeed_slow_array.append(S4_near* S5_normal*S6_far* S7_far)
    rightspeed_quick_array.append(S4_near* S5_normal*S6_far* S7_far)
    # rule83
    leftspeed_slow_array.append(S4_near* S5_normal* S6_close* S7_close)
    rightspeed_fast_array.append(S4_near* S5_normal* S6_close* S7_close)
    # rule84
    leftspeed_slow_array.append(S4_near* S5_normal* S6_near* S7_close)
    rightspeed_quick_array.append(S4_near* S5_normal* S6_near* S7_close)
    # rule85
    leftspeed_slow_array.append(S6_close* S7_close)
    rightspeed_fast_array.append(S6_close* S7_close)



    for i in range(len(leftspeed_slow_array)):
        leftspeed_slow_array[i] = leftspeed_slow_array[i] ** (2/4)
    for i in range(len(leftspeed_normal_array)):
        leftspeed_normal_array[i] = leftspeed_normal_array[i] ** (2/4)
    for i in range(len(leftspeed_quick_array)):
        leftspeed_quick_array[i] = leftspeed_quick_array[i] ** (2/4)
    for i in range(len(leftspeed_fast_array)):
        leftspeed_fast_array[i] = leftspeed_fast_array[i] ** (2/4)
    for i in range(len(rightspeed_slow_array)):
        rightspeed_slow_array[i] = rightspeed_slow_array[i] ** (2/4)
    for i in range(len(rightspeed_normal_array)):
        rightspeed_normal_array[i] = rightspeed_normal_array[i] ** (2/4)
    for i in range(len(rightspeed_quick_array)):
        rightspeed_quick_array[i] = rightspeed_quick_array[i] ** (2/4)
    for i in range(len(rightspeed_fast_array)):
        rightspeed_fast_array[i] = rightspeed_fast_array[i] ** (2/4)



    leftspeed_slow_array_max = max(leftspeed_slow_array)
    leftspeed_normal_array_max = max(leftspeed_normal_array)
    leftspeed_quick_array_max = max(leftspeed_quick_array)
    leftspeed_fast_array_max = max(leftspeed_fast_array)
    rightspeed_slow_array_max = max(rightspeed_slow_array)
    rightspeed_normal_array_max = max(rightspeed_normal_array)
    rightspeed_quick_array_max = max(rightspeed_quick_array)
    rightspeed_fast_array_max = max(rightspeed_fast_array)

    #print(leftspeed_normal_array_max, rightspeed_normal_array_max)

    leftspeed_array_1=[]
    rightspeed_array_1=[]
    for i in range(0, 300):
        leftspeed_array_1.append(max(leftspeed_slow_array_max*leftspeed_slow[i],leftspeed_normal_array_max*leftspeed_normal[i],leftspeed_quick_array_max*leftspeed_quick[i],leftspeed_fast_array_max*leftspeed_fast[i]))
        rightspeed_array_1.append(max(rightspeed_slow_array_max*rightspeed_slow[i], rightspeed_normal_array_max*rightspeed_normal[i],rightspeed_quick_array_max*rightspeed_quick[i], rightspeed_fast_array_max*rightspeed_fast[i]))


    leftspeed = 0
    rightspeed = 0
    for i in range(0, 300):
        leftspeed = leftspeed_array_1[i]*leftspeed_array[i] + leftspeed
        rightspeed = rightspeed_array_1[i]*rightspeed_array[i] + rightspeed

    leftSpeed1 = leftspeed/sum(leftspeed_array_1)
    rightSpeed1= rightspeed/sum(rightspeed_array_1)

    # # 计算控制输出
    # left_pwm, right_pwm = pid_controller.compute_control(sonarReading)
    # print(f"左轮PWM: {left_pwm}, 右轮PWM: {right_pwm}")
    #CruiseSpeedLef = 700
    gama = 0.75
    alfa = 1.25
    rd = 700
    sd = sonarReading[0]
    kh = -0.5
    kd = -0.2
    sa = sonarReading[3]
    sf = sonarReading[2]
    sw = sonarReading[13]
    ss = sonarReading[11]
    kd=-0.1*pow(1.1,math.log2(1+abs(abs(rd-sd))))
    # if  (sd-sdt)>500:
    #     kd=0.1+(abs(sf+sa-1600)/1000)
    #CruiseSpeedLef=2.5*(10-0.01*(1000-sa))**2-0.025*(1000-sa)+45
    print("sa",sa)
    CruiseSpeedLef=300
    CruiseSpeedLef=500*pow(0.9,math.log(1+abs((rd - sd))+abs(sa)))
    print("abs(kd * (rd - sd))",abs((rd - sd)))
    print("kd",kd)
    print("CruiseSpeedLef",CruiseSpeedLef)
    #print("abs(kd * (rd - sd))+abs(kh * (gama * (sa - 1000) + (sf - 1000) - alfa*(sw - 1000)))",abs(kd * (rd - sd))+abs(kh * (gama * (sa - 1000) + (sf - 1000) - alfa*(sw - 1000))))
    #print("sf+sa:",sf+sa,"sd:",sd,"kd",kd)
    leftSpeed2 = CruiseSpeedLef + kd * (rd - sd) - kh * (gama * sa + sf- alfa*sw)
    rightSpeed2 = CruiseSpeedLef - kd * (rd - sd) + kh * (gama * sa  + sf- alfa*sw)

    leftSpeed=0.6*rightSpeed1+0.4*leftSpeed2
    rightSpeed=0.6*leftSpeed1+0.4*rightSpeed2


    # add leftSpeed and rightSpeed
    one_sheet.append('%f' % leftspeed)
    one_sheet.append('%f' % rightspeed)
 
    robot.lock()
    robot.setVel2(leftSpeed2, rightSpeed2)
    robot.unlock()
    time.sleep(0.05)
    robot.lock()
    end_time = time.time()
    robot_leftSpeed = robot.getLeftVel()
    robot_rightSpeed = robot.getRightVel()
    robot_trans_speed = robot.getVel()
    robot_rot_speed = robot.getRotVel()
    robot.unlock()

    ac_end_time = time.perf_counter()

    # print(end_time-start_time)
    # flag = 0

    robot_transaccel = (robot_trans_speed - last_speed) / (ac_end_time - ac_start_time)
    robot_angle_transaccel = (robot_rot_speed - last_angle_speed) / (ac_end_time - ac_start_time)
    last_angle_speed = robot_rot_speed
    last_speed = robot_trans_speed
    # 记录数据
    # one_sheet.append(robot_query_time)  # 执行时间
    one_sheet.append(leftSpeed)  # 计算左轮速度
    one_sheet.append(rightSpeed)  # 计算右轮速度q
    one_sheet.append(robot_leftSpeed)  # 实际左轮速度
    one_sheet.append(robot_rightSpeed)  # 实际右轮速度
    one_sheet.append(robot_trans_speed)  # 实际速度
    one_sheet.append(robot_rot_speed)  # 实际角速度
    one_sheet.append(robot_transaccel)  # 实际加速度
    one_sheet.append(robot_angle_transaccel)  # 实际角加速度
    # print(one_sheet)
    sheet.append(one_sheet)
    one_sheet = []

# writeFileObj = open('mul_fc.csv', 'w')
# csv_writer = csv.writer(writeFileObj)
# writer = csv_writer
# for row in sheet:
#     writer.writerow(row)
# writeFileObj.close()

