import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from pathlib import Path
# ============================================================
# 0. 全局绘图设置
# ============================================================
# ============================================================
# 0. Global plot settings
# ============================================================
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.weight"] = "bold"
plt.rcParams["font.size"] = 10
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["axes.facecolor"] = "#FFFFFF"

# 公式及数学符号字体：Times New Roman
plt.rcParams["mathtext.fontset"] = "custom"
plt.rcParams["mathtext.rm"] = "Times New Roman"
plt.rcParams["mathtext.it"] = "Times New Roman:italic"
plt.rcParams["mathtext.bf"] = "Times New Roman:bold"
plt.rcParams["mathtext.cal"] = "Times New Roman"
plt.rcParams["mathtext.fallback"] = "stix"
# ============================================================
# 1. 数据
# ============================================================
# 单位均为 m；NaN 表示该参数没有该序号的实验数据
data_mae = np.array([
    [0.063609, 0.104458, 0.086508, 0.064394, 0.082212],
    [0.061538, 0.089820, 0.083353, 0.083353, 0.080449],
    [0.079725, 0.082498, 0.081684, 0.086307, 0.073343],
    [0.099069, 0.079398, 0.080602, 0.104572, 0.073534],
    [0.130990, np.nan, 0.080834, 0.129364, 0.086467],
    [np.nan,   np.nan, 0.081807, np.nan,   np.nan],
])

data_rmse = np.array([
    [0.275270, 0.282944, 0.283983, 0.176299, 0.282604],
    [0.261038, 0.293876, 0.292460, 0.292460, 0.271348],
    [0.281350, 0.292395, 0.294858, 0.323220, 0.233517],
    [0.297732, 0.282624, 0.301216, 0.366822, 0.233814],
    [0.332149, np.nan, 0.299362, 0.382969, 0.251023],
    [np.nan,   np.nan, 0.315414, np.nan,   np.nan],
])

parameter_names = [
    r"$d_{0}^{\mathrm{ref}}$",
    r"$\epsilon$",
    r"$\beta$",
    r"$w^{\mathrm{ref}}$",
    r"$N$",
]
# 5个模型独立配色
parameter_colors = ["#292E7F", "#4784C5", "#A2CD61", "#F27120", "#7E1416"]

# ============================================================
# 2. 通用统计函数：均值 + 95% CI
# ============================================================
def compute_stats(data, n_boot=10000, alpha=0.05):
    means, ci_lows, ci_highs = [], [], []
    rng = np.random.default_rng(42)

    for i in range(data.shape[1]):
        # 删除补齐用的 NaN，仅保留该参数实际实验数据
        x = data[:, i]
        x = x[np.isfinite(x)]

        n = len(x)
        if n == 0:
            raise ValueError(f"第 {i + 1} 组参数没有有效数据。")

        mean = np.mean(x)

        # Bootstrap 95% CI
        boot_samples = rng.choice(x, size=(n_boot, n), replace=True)
        boot_means = np.mean(boot_samples, axis=1)

        lower = np.percentile(boot_means, 100 * alpha / 2)
        upper = np.percentile(boot_means, 100 * (1 - alpha / 2))

        means.append(mean)
        ci_lows.append(lower)
        ci_highs.append(upper)

    means = np.array(means)
    ci_lows = np.array(ci_lows)
    ci_highs = np.array(ci_highs)

    errors = np.array([
        means - ci_lows,
        ci_highs - means
    ])

    return means, ci_lows, ci_highs, errors

means_mae, lo_mae, hi_mae, err_mae = compute_stats(data_mae)
means_rmse, lo_rmse, hi_rmse, err_rmse = compute_stats(data_rmse)

# ============================================================
# 3. 绘图：X轴两个类别：MAE、RMSE；每个类别内部并排5根柱子（5模型）
# ============================================================
bar_width = 0.15
# X轴两个大位置：0 代表MAE，1代表RMSE
x_tick_pos = np.array([0, 1])
# 5个模型在每个大位置内的偏移量
offsets = np.array([-2*bar_width, -bar_width, 0, bar_width, 2*bar_width])

fig, ax = plt.subplots(figsize=(10,7), dpi=150)

# 循环绘制5个模型，分别在MAE(x=0) 和 RMSE(x=1)位置
for i in range(5):
    x_pos = x_tick_pos + offsets[i]
    vals = [means_mae[i], means_rmse[i]]
    errs = np.array([[err_mae[0,i], err_rmse[0,i]], [err_mae[1,i], err_rmse[1,i]]])
    ax.bar(
        x_pos, vals, width=bar_width, yerr=errs, capsize=4,
        color=parameter_colors[i], alpha=0.85, edgecolor="#333333", linewidth=0.7,
        error_kw=dict(elinewidth=3, ecolor="#333333"),
        label=parameter_names[i]
    )

ax.set_xticks(x_tick_pos)
ax.set_xticklabels(["MAE", "RMSE"], fontsize=24 ,weight="bold")
ax.tick_params(axis='y', labelsize=24)

ax.set_ylim(bottom=0)
# 图例放右上角，5个模型
ax.legend(loc="upper left", ncol=1, frameon=False, fontsize=16)

# 在当前 Python 文件同级目录创建 picture 文件夹
OUTPUT_FOLDER = Path(__file__).resolve().parent / "picture"
OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)

plt.tight_layout()

# 保存论文图片和高清 PNG 图片
plt.savefig(
    OUTPUT_FOLDER / "sensitivity_analysis.pdf",
    dpi=300,
    bbox_inches="tight"
)

plt.savefig(
    OUTPUT_FOLDER / "sensitivity_analysis.png",
    dpi=300,
    bbox_inches="tight"
)

print(f"图片已保存至：{OUTPUT_FOLDER}")

plt.show()

# ============================================================
# 4. 控制台输出两份 CI 信息
# ============================================================
def print_stats(title, names, means, lo, hi):
    print(f"\n===== {title} =====")
    print(f"{'模型':12s} {'均值':>10s} {'95% CI 下限':>12s} {'95% CI 上限':>12s}")
    print("-" * 52)
    for name, m, l, h in zip(names, means, lo, hi):
        print(f"{name:12s} {m:10.4f} {l:12.4f} {h:12.4f}")

# 重新获取lo、hi用于打印
def compute_stats_full(data, n_boot=10000, alpha=0.05):
    means, ci_lows, ci_highs = [], [], []
    np.random.seed(42)
    for i in range(data.shape[1]):
        x = data[:, i]
        n = len(x)
        mean = np.mean(x)
        boot_means = []
        for _ in range(n_boot):
            sample = np.random.choice(x, size=n, replace=True)
            boot_means.append(np.mean(sample))
        lower = np.percentile(boot_means, 100 * alpha / 2)
        upper = np.percentile(boot_means, 100 * alpha / 2)
        upper = np.percentile(boot_means, 100 * (1 - alpha / 2))
        means.append(mean)
        ci_lows.append(lower)
        ci_highs.append(upper)
    return np.array(means), np.array(ci_lows), np.array(ci_highs)

means_mae_full, lo_mae, hi_mae = compute_stats_full(data_mae)
means_rmse_full, lo_rmse, hi_rmse = compute_stats_full(data_rmse)

print_stats("MAE", parameter_names, means_mae, lo_mae, hi_mae)
print_stats("RMSE", parameter_names, means_rmse, lo_rmse, hi_rmse)
