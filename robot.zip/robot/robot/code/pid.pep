num_ennp_fc = 
{
	
    H = {WallFollow,Speed,parallel_P,parallel_I,parallel_D,distance_P,distance_I,distance_D,parallel,distance};
					
    structure = [Speed[WallFollow 
				[parallel_P ]parallel_P [parallel_I ]parallel_I [parallel_D] parallel_D [distance_P] distance_P [distance_I]distance_I [distance_D]distance_D [distance]distance [parallel]parallel
				]WallFollow ]Speed;
		
    Speed={
		var = {f0,cruisespeedleft,cruisespeedright,paralle_out,distance_out,leftspeed,rightspeed}; 
		E={e1};
		pr= {f0+cruisespeedleft+distance_out+0.25*paralle_out [e1->]1|leftspeed};
		pr= {f0+cruisespeedright-distance_out-0.25*paralle_out [e1->]1|rightspeed};
		var0 = (0,0,0,0,0,0,0);
		E0={0};
	};
	
	WallFollow = {
	    var = {f0,s5,s6,s7}; 
        E={e2};
		pr = {f0+s6-s7/0.7513  [e2->]  1|parallel_error};
		pr= {f0+s7-300+(s5-1000)*0.9848 [e2->] 1|distance_error};
		var0 = (0,0,0,0);
		E0={0};
	};
	parallel={
		var = {f0,parallel_p1,parallel_i1,parallel_d1}; 
		E={e7};
		pr = {f0+parallel_p1  [e7->]  1|parallel_p};
		pr = {f0+parallel_i1  [e7->]  1|parallel_i};
		pr = {f0+parallel_d1  [e7->]  1|parallel_d};
		E0={0};
		var0 = (0,0,0,0);
		
	};
	
    distance={   
	    var = {f0,distance_p1,distance_i1,distance_d1}; 
		E={e8};
		pr = {f0+distance_p1  [e8->]  1|distance_p};
		pr = {f0+distance_i1  [e8->]  1|distance_i};
		pr = {f0+distance_d1  [e8->]  1|distance_d};
		E0={0};
		var0 = (0,0,0,0);
		
	};
	
	parallel_P = {
	    var = {parallel_p,parallel_error}; 
        pr = {parallel_error*parallel_p  ->  1|paralle_out};
		var0 = (0,0);
		
	};

	parallel_I = {
	    var = {f0,parallel_error,parallel_sumerror,parallel_i}; 
		E={e3};
        pr = {f0+parallel_error  [e3->]  1|parallel_sumerror};
		pr= {f0+parallel_sumerror*parallel_i [e3->] 1|paralle_out};
		E0={0};
		var0 = (0,0,0,0);
		
	};
	parallel_D = {
	    var = {f0,parallel_error,parallel_lasterror,parallel_d}; 
		E={e4};
        pr = {f0+(parallel_error-parallel_lasterror)*parallel_d  [e4->]  1|paralle_out};
		pr={f0+parallel_error [e4->]1|parallel_lasterror};
		var0 = (0,0,0,0);
		E0={0};
	};
	
	
	distance_P = {
		var = {distance_p,distance_error}; 
        pr = {distance_error*distance_p  ->  1|distance_out};
		var0={0,0};
	};
	distance_I = {
	    var = {f0,distance_error,distance_sumerror,distance_i};
		E={e5};		
        pr = {f0+distance_error  [e5->]  1|distance_sumerror};
		pr= {f0+distance_sumerror*distance_i [e5->] 1|distance_out};
		var0 = (0,0,0,0};
		E0={0};
	};
	distance_D = {
	    var = {f0,distance_error,distance_lasterror,distance_d}; 
		E={e6};
        pr = {f0+(distance_error-distance_lasterror)*distance_d  [e6->]  1|distance_out};
		pr=  {f0+distance_error [e6->] 1|distance_lasterror};
		var0 = (0,0,0,0);
		E0={0};
	};
}