"""Non-ENSNP adaptive Mamdani fuzzy controller for a fair ENSNPFM baseline.

This controller deliberately contains no membrane-system objects, enzymes, or
PyTorch tensors.  It keeps the same high-level control policy as ENSNPFM:
three sonar inputs, adaptive Gaussian membership functions, seven Mamdani
rules, two wheel-speed outputs, and centre-of-gravity defuzzification.

The implementation is intended as a baseline named NOENNPS.  It is compatible
with the ``real_time_inference(sensor_data)`` call used by NOENNPS_test.py.
All distances and speeds are in millimetres and millimetres per second.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import math
import time
from typing import Deque, Iterable


@dataclass(frozen=True)
class ControllerConfiguration:
    """Fixed experiment configuration for the comparable 3-input controller."""

    n_inputs: int = 3
    n_outputs: int = 2
    n_input_mfs: int = 3
    n_output_mfs: int = 3
    n_rules: int = 7
    # N is the temporal-history window H, not a serial-pipeline length.
    history_length: int = 200
    epsilon: float = 100.0
    beta: float = 0.075
    cruising_speed: float = 100.0
    output_min: float = -200.0
    output_max: float = 200.0
    n_points: int = 401


class NOENNPSController:
    """Ordinary adaptive fuzzy controller with no ENSNP implementation layer."""

    _SENSOR_KEYS = ("s4", "s5", "s7")
    _MF_OFFSETS = (-3.0, 0.0, 3.0)

    # 0, 1, and 2 respectively denote near/slow, normal, and far/fast.
    _RULE_ANTECEDENTS = (
        (0, 0, 1),
        (1, 2, 2),
        (1, 1, 1),
        (2, 2, 2),
        (0, 0, 0),
        (1, 0, 0),
        (2, 0, 0),
    )
    _RULE_CONSEQUENTS = (
        (0, 2),
        (1, 0),
        (1, 1),
        (1, 0),
        (0, 2),
        (0, 2),
        (0, 2),
    )

    def __init__(
        self,
        n_inputs: int = 3,
        n_outputs: int = 2,
        n_input_mfs: int = 3,
        n_output_mfs: int = 3,
        n_rules: int = 7,
        use_gpu: bool = False,
        R: float = 200.0,
        rf: float = 250.0,
        Ts: float | None = None,
        *,
        history_length: int = 200,
        epsilon: float = 100.0,
        beta: float = 0.075,
        cruising_speed: float = 100.0,
        output_min: float = -200.0,
        output_max: float = 200.0,
        n_points: int = 401,
    ) -> None:
        """Create the controller.

        ``use_gpu`` and ``Ts`` remain only for call compatibility with the
        previous script.  NOENNPS is intentionally CPU-only; use ``epsilon``
        for the minimum input-membership width.  ``R`` is the body offset and
        ``rf`` is the nominal wall-following distance.
        """
        del use_gpu, Ts

        self.config = ControllerConfiguration(
            n_inputs=n_inputs,
            n_outputs=n_outputs,
            n_input_mfs=n_input_mfs,
            n_output_mfs=n_output_mfs,
            n_rules=n_rules,
            history_length=history_length,
            epsilon=float(epsilon),
            beta=float(beta),
            cruising_speed=float(cruising_speed),
            output_min=float(output_min),
            output_max=float(output_max),
            n_points=n_points,
        )
        self._validate_configuration()

        self.body_offset = float(R)
        self.nominal_wall_distance = float(rf)
        # These factors preserve the geometry convention used by the existing
        # implementation: the sensors are offset by 80, 60 and 0 degrees.
        angle_factors = (
            math.cos(math.radians(80.0)),
            math.cos(math.radians(60.0)),
            1.0,
        )
        self.reference_distances = tuple(
            (self.body_offset + self.nominal_wall_distance) / factor
            for factor in angle_factors
        )
        self.center_bases = tuple(
            reference - self.body_offset
            for reference in self.reference_distances
        )

        self.sensor_history: dict[str, Deque[float]] = {
            key: deque(maxlen=self.config.history_length)
            for key in self._SENSOR_KEYS
        }
        self.x_points = tuple(
            self.config.output_min
            + idx
            * (self.config.output_max - self.config.output_min)
            / (self.config.n_points - 1)
            for idx in range(self.config.n_points)
        )
        self.dx = (self.config.output_max - self.config.output_min) / (
            self.config.n_points - 1
        )
        self.previous_output = [0.0, 0.0]

    def _validate_configuration(self) -> None:
        cfg = self.config
        expected = (3, 2, 3, 3, 7)
        received = (
            cfg.n_inputs,
            cfg.n_outputs,
            cfg.n_input_mfs,
            cfg.n_output_mfs,
            cfg.n_rules,
        )
        if received != expected:
            raise ValueError(
                "The embedded rule base requires n_inputs=3, n_outputs=2, "
                "n_input_mfs=3, n_output_mfs=3, and n_rules=7."
            )
        if cfg.history_length < 2:
            raise ValueError("history_length must be at least 2.")
        if cfg.epsilon <= 0 or cfg.beta <= 0:
            raise ValueError("epsilon and beta must be positive.")
        if cfg.n_points < 3 or cfg.output_min >= cfg.output_max:
            raise ValueError("The output grid must have at least 3 ordered points.")

    @staticmethod
    def _sample_std(values: Iterable[float]) -> float:
        values = tuple(values)
        mean = sum(values) / len(values)
        variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
        return math.sqrt(max(0.0, variance))

    @staticmethod
    def _gaussian(value: float, center: float, sigma: float) -> float:
        return math.exp(-0.5 * ((value - center) / sigma) ** 2)

    def _update_history(self, values: tuple[float, float, float]) -> None:
        for key, value in zip(self._SENSOR_KEYS, values):
            self.sensor_history[key].append(value)

    def _history_with_first_value_padding(self, key: str) -> tuple[float, ...]:
        values = tuple(self.sensor_history[key])
        if not values:
            raise RuntimeError("History is empty after an input update.")
        return (values[0],) * (self.config.history_length - len(values)) + values

    def _adaptive_input_parameters(
        self, values: tuple[float, float, float]
    ) -> tuple[list[list[float]], list[float]]:
        centers: list[list[float]] = []
        sigmas: list[float] = []

        for index, key in enumerate(self._SENSOR_KEYS):
            local_std = self._sample_std(self._history_with_first_value_padding(key))
            baseline_sigma = max(self.config.epsilon, local_std)
            deviation = abs(values[index] - self.reference_distances[index])
            sigma = baseline_sigma if deviation < 6.0 * baseline_sigma else deviation / 3.0
            centers.append(
                [self.center_bases[index] + offset * sigma for offset in self._MF_OFFSETS]
            )
            sigmas.append(sigma)
        return centers, sigmas

    def _input_memberships(
        self, values: tuple[float, float, float], centers: list[list[float]], sigmas: list[float]
    ) -> list[list[float]]:
        return [
            [self._gaussian(values[index], center, sigmas[index]) for center in centers[index]]
            for index in range(self.config.n_inputs)
        ]

    def _output_parameters(self, input_sigmas: list[float]) -> tuple[list[list[float]], float]:
        output_sigma = self.config.beta * (sum(input_sigmas) / len(input_sigmas))
        centers = [
            [self.config.cruising_speed + offset * output_sigma for offset in self._MF_OFFSETS]
            for _ in range(self.config.n_outputs)
        ]
        return centers, output_sigma

    def _rule_strengths(self, memberships: list[list[float]]) -> list[float]:
        return [
            min(memberships[sensor][mf] for sensor, mf in enumerate(antecedents))
            for antecedents in self._RULE_ANTECEDENTS
        ]

    def _defuzzify(
        self, output_index: int, rule_strengths: list[float], output_centers: list[list[float]], output_sigma: float
    ) -> float:
        numerator = 0.0
        denominator = 0.0
        for x_value in self.x_points:
            membership = 0.0
            for rule_index, strength in enumerate(rule_strengths):
                mf_index = self._RULE_CONSEQUENTS[rule_index][output_index]
                gaussian = self._gaussian(x_value, output_centers[output_index][mf_index], output_sigma)
                membership = max(membership, min(strength, gaussian))
            numerator += x_value * membership * self.dx
            denominator += membership * self.dx

        if denominator <= 1e-12:
            return self.previous_output[output_index]
        return numerator / denominator

    def real_time_inference(self, sensor_data: Iterable[float]) -> dict[str, object]:
        """Return left/right wheel commands for the current three sensor values."""
        values = tuple(float(value) for value in sensor_data)
        if len(values) != self.config.n_inputs:
            raise ValueError("sensor_data must contain exactly three values: [s4, s5, s7].")
        if not all(math.isfinite(value) for value in values):
            raise ValueError("sensor_data contains a non-finite value.")

        self._update_history(values)
        input_centers, input_sigmas = self._adaptive_input_parameters(values)
        input_memberships = self._input_memberships(values, input_centers, input_sigmas)
        output_centers, output_sigma = self._output_parameters(input_sigmas)
        rule_strengths = self._rule_strengths(input_memberships)
        outputs = [
            self._defuzzify(index, rule_strengths, output_centers, output_sigma)
            for index in range(self.config.n_outputs)
        ]
        self.previous_output = outputs

        return {
            "left_speed": outputs[0],
            "right_speed": outputs[1],
            "timestamp": time.time(),
            "dynamic_params": {
                "input_centers": input_centers,
                "input_sigmas": input_sigmas,
                "output_centers": output_centers,
                "output_sigmas": [[output_sigma] * 3 for _ in range(2)],
                "avg_input_sigma": sum(input_sigmas) / len(input_sigmas),
                "rule_strengths": rule_strengths,
            },
        }

    def resource_summary(self) -> dict[str, int]:
        """Return reproducible structural counts for the resource-analysis table."""
        cfg = self.config
        return {
            "input_sensors": cfg.n_inputs,
            "history_states": cfg.n_inputs * cfg.history_length,
            "input_membership_functions": cfg.n_inputs * cfg.n_input_mfs,
            "fuzzy_rules": cfg.n_rules,
            "antecedent_connections": cfg.n_rules * cfg.n_inputs,
            "consequent_connections": cfg.n_rules * cfg.n_outputs,
            "output_membership_functions": cfg.n_outputs * cfg.n_output_mfs,
            "defuzzification_grid_points": cfg.n_outputs * cfg.n_points,
            "rule_grid_values_per_cycle": cfg.n_outputs * cfg.n_points * cfg.n_rules,
        }


# Compatibility alias for the original immediate-inference implementation.
ennp_RealTimeFuzzySystem = NOENNPSController

