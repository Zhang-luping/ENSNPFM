# -*- coding: utf-8 -*-
"""
ARIA Python 绑定最简测试案例：MobileSim 仿真机器人控制
不使用显式初始化，直接创建机器人对象
"""
# -*- coding: utf-8 -*-

import AriaPy
from AriaPy import *  # 恢复完整导入以确保所有AriaPy函数可用
from pep import *
import sys
import xlrd
import keyboard  # 替换pythoncom和pyHook，更适合Python 3
import threading
import csv
import numpy as np
import time
import math
import sys
import time
from AriaPy import *
import sys
import pythoncom
import threading
import csv
import numpy as np
import time
import math
import matplotlib.pyplot as plt
# 添加 ARIA Python 绑定路径
sys.path.append(r'C:\robot\ARIA\python3')
try:
    import AriaPy

    print("成功导入 AriaPy 模块")
except ImportError:
    print("错误：无法导入 AriaPy 模块")
    sys.exit(1)
# 创建机器人对象
print("创建机器人对象...")
robot = AriaPy.ArRobot()

# 用于决定程序是否继续运行
# 1 继续运行, 0 停止
# 按键 "q" 可以停止程序并收集数据
flag = 1


def key_press_handler(e):
    """处理键盘按键事件"""
    global flag
    print(f"按下了键: {e.name}")
    if e.name.lower() == "q":
        print("检测到Q键，准备停止程序...")
        flag = 0
        return False  # 停止监听


def setup_keyboard_listener():
    """设置键盘监听器"""
    keyboard.on_press(key_press_handler)


# 创建线程监听键盘事件
def start_keyboard_listener():
    """启动键盘监听线程"""
    t = threading.Thread(target=setup_keyboard_listener)
    t.daemon = True
    t.start()
    return t


# 启动键盘监听
keyboard_thread = start_keyboard_listener()
print("按 'Q' 键可停止程序")




start_time = time.time()
# 创建 TCP 连接 (MobileSim 默认使用 TCP)
print("创建 TCP 连接...")
conn = AriaPy.ArTcpConnection()
conn.setPort("localhost", 8101)  # MobileSim 默认端口

# 设置机器人连接
print("设置机器人连接...")
robot.setDeviceConnection(conn)
if not robot.blockingConnect():
    print("错误：无法连接到仿真机器人")
robot.runAsync(True)
# 添加声纳设备
print("添加声纳设备...")
sonar = ArSonarDevice()
robot.addRangeDevice(sonar)
# 等待机器人准备就绪
print("等待机器人准备就绪...")
# time.sleep(1)
# 启用电机
print("启用电机...")
robot.enableMotors()
print("机器人初始化完成")

filename='26.4.9.FLC.csv'
def N(x):
    if 0 <= x <= 150:
        y = 1
    elif 150 < x <= 300:
        y = -(x - 300) / 150
    else:
        y = 0
    return y

def QN(x):
    if 100 <= x <= 300:
        y = (x - 100) / 200
    elif 300 < x <= 650:
        y = -(x - 650) / 350
    else:
        y = 0
    return y

#
def F(x):
    if 650 < x <= 1000:
        y = 1
    elif 300 <= x <= 650:
        y = (x - 300) / 350
    else:
        y = 0
    return y

# def N(x):
#     if 0<=x<=250:
#         y=1
#     elif 250<x<=450:
#         y=-(x-450)/200
#     else:
#         y=0
#     return y
# def QN(x):
#     if 250<=x<=450:
#         y=(x-250)/200
#     elif 450<x<=700:
#         y=-(x-700)/250
#     else:
#         y=0
#     return y
# def F(x):
#     if 700<x<=1000:
#         y=1
#     elif 450<=x<=700:
#         y=(x-450)/250
#     else:
#         y=0
#     return y
# def BF(x):
#     # Big Negative
#     if -100 < x <= -50:
#         return (-x - 50) / 50
#     else:
#         return 0.0
# def B(x):
#     # Negative
#     if -100 < x <= -50:
#         return (x + 100) / 50
#     elif -50 < x <= 0:
#         return (-x) / 50
#     else:
#         return 0.0
# def Z(x):
#     # Zero
#     if -50 < x <= 0:
#         return (x + 50) / 50
#     elif 0 < x <= 50:
#         return (50 - x) / 50
#     else:
#        return 0.0
# def F1(x):
#     # Positive
#     if 0 < x <= 50:
#         return (x) / 50
#     elif 50 < x <= 100:
#         return (100 - x) / 50
#     else:
#         return 0.0
# def FF(x):
#     # Big Positive
#     if 50 < x <= 100:
#         return (x - 50) / 50
#     else :
#         return 0

#
def BF(x):
    # Big Negative
    if -100 < x <= 0:
        return (-x) / 100
    else:
        return 0.0
def B(x):
    # Negative
    if -100 < x <= 0:
        return (x + 100) / 100
    elif 0 < x <= 150:
        return (-x+150) / 150
    else:
        return 0.0
def Z(x):
    # Zero
    if 0 < x <= 150:
        return (x) / 150
    elif 150 < x <= 300:
        return (300 - x) / 150
    else:
       return 0.0
def F1(x):
    # Positive
    if 150 < x <= 300:
        return (x-150) / 150
    elif 300 < x <= 400:
        return (400 - x) / 100
    else:
        return 0.0
def FF(x):
    # Big Positive
    if 300 < x <= 400:
        return (x - 300) / 100
    else :
        return 0

# 距离传感器S4-S7的取值范围设定
S4_array = np.arange(0, 1001, 1)  # S4的取值范围0-1000MM
S5_array = np.arange(0, 1001, 1)  # S5的取值范围0-1000MM
S6_array = np.arange(0, 1001, 1)  # S6的取值范围0-1000MM
S7_array = np.arange(0, 1001, 1)  # S7的取值范围0-1000MM

leftspeed_array = np.arange(-100, 401, 1)  # leftspeed的取值范围-100-900MM/S
rightspeed_array = np.arange(-100, 401, 1)  # rightspeed的取值范围-100-900MM/S
# workbook = xlrd.open_workbook(r'C:/Users/13979/Desktop/ensnp/zzm/data/best.xls')
# sheet1 = workbook.sheet_by_index(0)  # 假设数据在第一个工作表中
# init_population = []
# for row_index in range(sheet1.nrows):
#     row_init_population = []
#     for col_index in range(sheet1.ncols):
#         cell_value = sheet1.cell_value(row_index, col_index)
#         row_init_population.append(cell_value)
#     init_population.append(row_init_population)
# Superorganism = init_population
# individual_index = 0
leftspeed_BF=[]
leftspeed_B=[]
leftspeed_Z=[]
leftspeed_F=[]
leftspeed_FF=[]
rightspeed_BF=[]
rightspeed_B=[]
rightspeed_Z=[]
rightspeed_F=[]
rightspeed_FF=[]
for i in range(500):
    leftspeed_BF.append(BF(leftspeed_array[i]))
    leftspeed_B.append(B(leftspeed_array[i]) )
    leftspeed_Z.append(Z(leftspeed_array[i]))
    leftspeed_F.append(F1(leftspeed_array[i]))
    leftspeed_FF.append(FF(leftspeed_array[i]))

    rightspeed_BF.append(BF(rightspeed_array[i]))
    rightspeed_B.append(B(rightspeed_array[i]))
    rightspeed_Z.append(Z(rightspeed_array[i]))
    rightspeed_F.append(F1(rightspeed_array[i]))
    rightspeed_FF.append(FF(rightspeed_array[i]))
print(leftspeed_BF)
plt.plot(leftspeed_BF)
step = 0
sheet = []

last_speed = 0
last_angle_speed = 0
sdt = 0
starttime=time.perf_counter()
while flag:
    leftspeed_BF_array = []
    leftspeed_B_array = []
    leftspeed_Z_array = []
    leftspeed_F_array = []
    leftspeed_FF_array = []

    rightspeed_BF_array = []
    rightspeed_B_array = []
    rightspeed_Z_array = []
    rightspeed_F_array = []
    rightspeed_FF_array = []

    leftspeed_array_1 = []
    rightspeed_array_1 = []
    ac_start_time = time.perf_counter()

    numSonar = robot.getNumSonar()
    sonarReading = []
    # collect one group data
    one_sheet = []
    for i in range(0, numSonar):
        reading = round(robot.getSonarReading(i).getRange())-100
        if reading > 1000:
            reading = 1000
        one_sheet.append(reading)
        #reading = -1 * reading + 1000
        sonarReading.append(reading)
    print(sonarReading)
    # DL = min(sonarReading[0],sonarReading[1],sonarReading[2])
    # DF = min(sonarReading[3],sonarReading[4])
    # DR = min(sonarReading[5],sonarReading[6],sonarReading[7])
    DL = min(sonarReading[0], sonarReading[1], sonarReading[2])
    DF = min(sonarReading[3],sonarReading[4])
    DR = min(sonarReading[5],sonarReading[6],sonarReading[7])

    DL_N = N(DL)
    DL_QN = QN(DL)
    DL_F = F(DL)

    DF_N = N(DF)
    DF_QN = QN(DF)
    DF_F = F(DF)

    DR_N = N(DR)
    DR_QN = QN(DR)
    DR_F = F(DR)
    print(DL_N,DL_QN,DL_F,DF_N,DF_QN,DF_F,DR_N,DR_QN,DR_F)

    # 模糊控制器规则转化
    # rule1
    leftspeed_BF_array.append(DL_N * DF_N *  DR_N)
    rightspeed_BF_array.append(DL_N * DF_N *  DR_N)
    # rule2
    leftspeed_FF_array.append(DL_N * DF_N * DR_QN)
    rightspeed_BF_array.append(DL_N * DF_N * DR_QN)
    # rule3
    leftspeed_FF_array.append(DL_N * DF_N * DR_F)
    rightspeed_BF_array.append(DL_N * DF_N * DR_F)
    # rule4
    leftspeed_F_array.append(DL_N * DF_QN * DR_N)
    rightspeed_F_array.append(DL_N * DF_QN * DR_N)
    # rule5
    leftspeed_FF_array.append(DL_N * DF_QN * DR_QN)
    rightspeed_Z_array.append(DL_N * DF_QN * DR_QN)
    # rule6
    leftspeed_FF_array.append(DL_N * DF_QN * DR_F)
    rightspeed_BF_array.append(DL_N * DF_QN * DR_F)
    # rule7
    leftspeed_F_array.append(DL_N * DF_F * DR_N)
    rightspeed_F_array.append(DL_N * DF_F * DR_N)
    # rule8
    leftspeed_F_array.append(DL_N * DF_F * DR_QN)
    rightspeed_B_array.append(DL_N * DF_F * DR_QN)
    # rule9
    leftspeed_FF_array.append(DL_N * DF_F * DR_F)
    rightspeed_BF_array.append(DL_N * DF_F * DR_F)
    # rule10
    leftspeed_BF_array.append(DL_QN * DF_N * DR_N)
    rightspeed_FF_array.append(DL_QN * DF_N * DR_N)
    # rule11
    leftspeed_FF_array.append(DL_QN * DF_N * DR_QN)
    rightspeed_BF_array.append(DL_QN * DF_N * DR_QN)
    # rule12
    leftspeed_FF_array.append(DL_QN * DF_N * DR_F)
    rightspeed_BF_array.append(DL_QN * DF_N * DR_F)
    # rule13
    leftspeed_B_array.append(DL_QN * DF_QN * DR_N)
    rightspeed_FF_array.append(DL_QN * DF_QN * DR_N)
    # rule14
    leftspeed_Z_array.append(DL_QN * DF_QN * DR_QN)
    rightspeed_FF_array.append(DL_QN * DF_QN * DR_QN)
    # rule15
    leftspeed_FF_array.append(DL_QN * DF_QN * DR_F)
    rightspeed_B_array.append(DL_QN * DF_QN * DR_F)
    # rule16
    leftspeed_B_array.append(DL_QN * DF_F * DR_N)
    rightspeed_F_array.append(DL_QN * DF_F * DR_N)
    # rule17
    leftspeed_Z_array.append(DL_QN * DF_F * DR_QN)
    rightspeed_FF_array.append(DL_QN * DF_F * DR_QN)
    # rule18
    leftspeed_FF_array.append(DL_QN * DF_F * DR_F)
    rightspeed_FF_array.append(DL_QN * DF_F * DR_F) #####z-FF
    # rule19
    leftspeed_BF_array.append(DL_F * DF_N * DR_N)
    rightspeed_FF_array.append(DL_F* DF_N * DR_N)
    # rule20
    leftspeed_BF_array.append(DL_F * DF_N * DR_QN)
    rightspeed_FF_array.append(DL_F * DF_N * DR_QN)
    # rule21
    leftspeed_FF_array.append(DL_F * DF_N * DR_F)
    rightspeed_BF_array.append(DL_F * DF_N * DR_F)
     # rule22
    leftspeed_BF_array.append(DL_F * DF_F * DR_F)
    rightspeed_FF_array.append(DL_F * DF_F * DR_F)
    # # rule23
    # leftspeed_Z_array.append(DL_F * DF_QN * DR_QN)
    # rightspeed_F_array.append(DL_F * DF_QN * DR_QN)
    # # rule24
    # leftspeed_FF_array.append(DL_F * DF_QN * DR_F)
    # rightspeed_Z_array.append(DL_F * DF_QN * DR_F)
    # # rule25
    # leftspeed_B_array.append(DL_F * DF_F * DR_N)
    # rightspeed_F_array.append(DL_F * DF_F * DR_N)
    # # rule26
    # leftspeed_Z_array.append(DL_F * DF_F * DR_QN)
    # rightspeed_F_array.append(DL_F * DF_F * DR_QN)
    # # rule27
    # leftspeed_FF_array.append(DL_F * DF_F * DR_F)
    # rightspeed_FF_array.append(DL_F * DF_F * DR_F)





    # for i in range(len(leftspeed_slow_array)):
    #     leftspeed_slow_array[i] = leftspeed_slow_array[i] ** (2 / 4)
    # for i in range(len(leftspeed_normal_array)):
    #     leftspeed_normal_array[i] = leftspeed_normal_array[i] ** (2 / 4)
    # for i in range(len(leftspeed_quick_array)):
    #     leftspeed_quick_array[i] = leftspeed_quick_array[i] ** (2 / 4)
    # for i in range(len(leftspeed_fast_array)):
    #     leftspeed_fast_array[i] = leftspeed_fast_array[i] ** (2 / 4)
    # for i in range(len(rightspeed_slow_array)):
    #     rightspeed_slow_array[i] = rightspeed_slow_array[i] ** (2 / 4)
    # for i in range(len(rightspeed_normal_array)):
    #     rightspeed_normal_array[i] = rightspeed_normal_array[i] ** (2 / 4)
    # for i in range(len(rightspeed_quick_array)):
    #     rightspeed_quick_array[i] = rightspeed_quick_array[i] ** (2 / 4)
    # for i in range(len(rightspeed_fast_array)):
    #     rightspeed_fast_array[i] = rightspeed_fast_array[i] ** (2 / 4)

    leftspeed_BF_array_max = max(leftspeed_BF_array)
    leftspeed_B_array_max = max(leftspeed_B_array)
    leftspeed_Z_array_max = max(leftspeed_Z_array)
    leftspeed_F_array_max = max(leftspeed_F_array)
    leftspeed_FF_array_max = max(leftspeed_FF_array)

    rightspeed_BF_array_max = max(rightspeed_BF_array)
    rightspeed_B_array_max = max(rightspeed_B_array)
    rightspeed_Z_array_max = max(rightspeed_Z_array)
    rightspeed_F_array_max = max(rightspeed_F_array)
    rightspeed_FF_array_max = max(rightspeed_FF_array)

    # print(leftspeed_normal_array_max, rightspeed_normal_array_max)

    leftspeed_array_1 = []
    rightspeed_array_1 = []
    for i in range(0, 500):
        leftspeed_array_1.append(
            max(leftspeed_BF_array_max * leftspeed_BF[i], leftspeed_B_array_max * leftspeed_B[i],
                leftspeed_Z_array_max * leftspeed_Z[i], leftspeed_F_array_max * leftspeed_F[i], leftspeed_FF_array_max * leftspeed_FF[i]))
        rightspeed_array_1.append(
            max(rightspeed_BF_array_max * rightspeed_BF[i], rightspeed_B_array_max * rightspeed_B[i],
                rightspeed_Z_array_max * rightspeed_Z[i], rightspeed_F_array_max * rightspeed_F[i], rightspeed_FF_array_max * rightspeed_FF[i]))

    leftspeed=0
    rightspeed=0
    for i in range(0, 500):
        leftspeed += leftspeed_array_1[i] * leftspeed_array[i]
        rightspeed += rightspeed_array_1[i] * rightspeed_array[i]

    leftSpeed = (leftspeed / (sum(leftspeed_array_1)+0.0000001))
    rightSpeed = (rightspeed / (sum(rightspeed_array_1)+0.000001))
    print(leftSpeed,leftSpeed)
    robot.lock()
    robot.setVel2(leftSpeed, rightSpeed)
    robot.unlock()
    time.sleep(0.04)
    robot.lock()

    robot_leftSpeed = robot.getLeftVel()
    robot_rightSpeed = robot.getRightVel()
    robot_trans_speed = robot.getVel()
    robot_rot_speed = robot.getRotVel()
    endtime = time.perf_counter()
    robot.unlock()

    ac_end_time = time.perf_counter()

    # print(end_time-start_time)
    # flag = 0

    robot_transaccel = (robot_trans_speed - last_speed) / (ac_end_time - ac_start_time)
    robot_angle_transaccel = (robot_rot_speed - last_angle_speed) / (ac_end_time - ac_start_time)
    last_angle_speed = robot_rot_speed
    last_speed = robot_trans_speed
    # 记录数据
    # one_sheet.append(robot_query_time)  # 执行时间
    one_sheet.append(leftSpeed)  # 计算左轮速度
    one_sheet.append(rightSpeed)  # 计算右轮速度
    one_sheet.append(robot_leftSpeed)  # 实际左轮速度
    one_sheet.append(robot_rightSpeed)  # 实际右轮速度
    one_sheet.append(robot_trans_speed)  # 实际速度
    one_sheet.append(robot_rot_speed)  # 实际角速度
    one_sheet.append(robot_transaccel)  # 实际加速度
    one_sheet.append(robot_angle_transaccel)  # 实际角加速度
    one_sheet.append(endtime - starttime)
    one_sheet.append(robot.getX())  # 计算时间
    one_sheet.append(robot.getY())  # 计算时间
    sheet.append(one_sheet)
    one_sheet = []

writeFileObj = open(filename, 'w')
csv_writer = csv.writer(writeFileObj)
writer = csv_writer
for row in sheet:
    writer.writerow(row)
writeFileObj.close()

