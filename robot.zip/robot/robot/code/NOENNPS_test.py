# -*- coding: utf-8 -*-
"""EOENNPS MobileSim experiment with reproducible Gaussian sonar noise.

Only change NOISE_LEVEL_PERCENT and EXPERIMENT_REPEAT for each run.
"""

import csv
import random
import sys
import threading
import time
# ARIA Python binding location.
ARIA_PYTHON_PATH = r"C:\robot\ARIA\python3"
if ARIA_PYTHON_PATH not in sys.path:
    sys.path.append(ARIA_PYTHON_PATH)

try:
    import AriaPy
    from AriaPy import ArSonarDevice
except ImportError as exc:
    raise SystemExit(f"错误：无法导入 AriaPy 模块：{exc}") from exc

try:
    import keyboard
except ImportError as exc:
    raise SystemExit("错误：请先安装 keyboard 模块（pip install keyboard）。") from exc

try:
    from NOENNPS import NOENNPSController
except ImportError as exc:
    raise SystemExit(
        "错误：无法导入 NOENNPSController，请确认 NOENNPS.py 位于当前目录或 Python 路径中。"
    ) from exc


# ===================== 实验设置：每次只修改这两项 =====================
# 可选值：0.0、1.0、2.0、3.0、4.0、5.0，单位为百分比。
NOISE_LEVEL_PERCENT = 0.0

# 当前噪声水平下的第几次独立重复实验：1、2、3、4 或 5。
EXPERIMENT_REPEAT = 5

# N is the temporal history window H used by the adaptive membership functions.
# The controller still performs one fuzzy inference and one wheel command per loop.
TEMPORAL_WINDOW_N = 200
# ======================================================================

# 每个“噪声水平 × 重复次数”组合都有唯一、可复现的种子。
NOISE_SEEDS = {
    0.0: (10001, 10002, 10003, 10004, 10005),
    1.0: (10001, 10002, 10003, 10004, 10005),
    2.0: (10001, 10002, 10003, 10004, 10005),
    3.0: (10001, 10002, 10003, 10004, 10005),
    4.0: (10001, 10002, 10003, 10004, 10005),
    5.0: (10001, 10002, 10003, 10004, 10005)
}

if NOISE_LEVEL_PERCENT not in NOISE_SEEDS:
    raise ValueError(f"不支持的噪声水平：{NOISE_LEVEL_PERCENT}%")
if not 1 <= EXPERIMENT_REPEAT <= 5:
    raise ValueError("EXPERIMENT_REPEAT 必须为 1 至 5。")

RANDOM_SEED = NOISE_SEEDS[NOISE_LEVEL_PERCENT][EXPERIMENT_REPEAT - 1]
NOISE_PERCENT = NOISE_LEVEL_PERCENT / 100.0
# 只在程序开始时创建一次；不要放进采样循环，否则实验不可复现。
RNG = random.Random(RANDOM_SEED)

running = True


def key_press_handler(event):
    """Press Q to stop one run and save its CSV file."""
    global running
    if event.name and event.name.lower() == "q":
        print("检测到 Q 键，准备停止程序…")
        running = False


def start_keyboard_listener():
    thread = threading.Thread(
        target=lambda: keyboard.on_press(key_press_handler), daemon=True
    )
    thread.start()
    return thread


def read_noisy_sonars(robot):
    """Apply multiplicative Gaussian noise before the original offset and cap."""
    readings = []
    for index in range(robot.getNumSonar()):
        raw_reading = round(robot.getSonarReading(index).getRange())
        noise = RNG.gauss(0.0, NOISE_PERCENT)
        noisy_reading = round(raw_reading * (1.0 + noise))

        # 保持原 EOENNPS 的数据预处理顺序。
        reading = noisy_reading - 100
        if reading > 1000:
            reading = 1000
        readings.append(reading)
    return readings


def main():
    print(
        f"噪声配置：{NOISE_LEVEL_PERCENT:.1f}% | "
        f"第 {EXPERIMENT_REPEAT} 次 | 随机种子：{RANDOM_SEED}"
    )
    start_keyboard_listener()
    print("按 Q 键可停止程序并保存数据")

    robot = AriaPy.ArRobot()
    connection = AriaPy.ArTcpConnection()
    connection.setPort("localhost", 8101)
    robot.setDeviceConnection(connection)

    print("设置机器人连接…")
    if not robot.blockingConnect():
        raise RuntimeError("错误：无法连接到 MobileSim 仿真机器人。")
    robot.runAsync(True)

    # 保持此引用直到实验结束，避免 ARIA 的底层设备指针失效。
    sonar = ArSonarDevice()
    robot.addRangeDevice(sonar)
    robot.enableMotors()
    print("机器人初始化完成")

    fuzzy_system = NOENNPSController(
        n_inputs=3,  # 固定为三路传感器
        n_outputs=2,
        n_input_mfs=3,
        n_output_mfs=3,
        n_rules=7,
        R=200,
        rf=250,
        epsilon=100.0,
        beta=0.075,
        history_length=TEMPORAL_WINDOW_N,
    )

    samples = []
    last_speed = 0.0
    last_angle_speed = 0.0
    start_time = time.perf_counter()

    try:
        while running:
            cycle_start = time.perf_counter()
            sonar_readings = read_noisy_sonars(robot)
            if len(sonar_readings) < 4:
                raise RuntimeError("EOENNPS 至少需要 4 个超声波传感器读数。")

            # 保持原模型的传感器输入顺序：[s4, s5, s7]。
            sensor_data = [sonar_readings[3], sonar_readings[2], sonar_readings[0]]
            result = fuzzy_system.real_time_inference(sensor_data)
            left_speed = result["left_speed"]
            right_speed = result["right_speed"]
            inference_end = time.perf_counter()
            print(left_speed, right_speed)

            # 保持你原来的左右轮命令顺序。
            robot.lock()
            try:
                robot.setVel2(right_speed, left_speed)
            finally:
                robot.unlock()

            time.sleep(0.001)
            robot.lock()
            try:
                robot_left_speed = robot.getLeftVel()
                robot_right_speed = robot.getRightVel()
                robot_trans_speed = robot.getVel()
                robot_rot_speed = robot.getRotVel()
                x_position = robot.getX()
                y_position = robot.getY()
                pose = robot.getPose()
            finally:
                robot.unlock()

            cycle_end = time.perf_counter()
            elapsed = cycle_end - cycle_start
            if elapsed > 0:
                trans_accel = (robot_trans_speed - last_speed) / elapsed
                angle_accel = (robot_rot_speed - last_angle_speed) / elapsed
            else:
                trans_accel = 0.0
                angle_accel = 0.0
            last_speed = robot_trans_speed
            last_angle_speed = robot_rot_speed

            # CSV 中的声纳列是已经加噪、偏移并限幅后的读数。
            samples.append(
                sonar_readings
                + [
                    left_speed,
                    right_speed,
                    robot_left_speed,
                    robot_right_speed,
                    robot_trans_speed,
                    robot_rot_speed,
                    trans_accel,
                    angle_accel,
                    cycle_end - start_time,
                    inference_end - cycle_start,
                    x_position,
                    y_position,
                    pose,
                ]
            )
    finally:
        robot.lock()
        try:
            robot.setVel2(0, 0)
            robot.disableMotors()
        finally:
            robot.unlock()
        robot.stopRunning()
        robot.disconnect()

        noise_name = f"{NOISE_LEVEL_PERCENT:.1f}".replace(".", "_")
        file_name = (
            f"NOENNPS_高斯噪声_{noise_name}pct_seed_{RANDOM_SEED}_"
            f"第{EXPERIMENT_REPEAT}次.csv"
        )
        with open(file_name, "w", newline="", encoding="utf-8-sig") as csv_file:
            csv.writer(csv_file).writerows(samples)
        print(f"实验数据已保存：{file_name}")


if __name__ == "__main__":
    main()
