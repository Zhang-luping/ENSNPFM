# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
from typing import Tuple, List, Optional
import queue
import threading
import time
from collections import deque
import math

out_put_sigma_value=[]
class ennp_RealTimeFuzzySystem_im:
    def __init__(self, n_inputs=3, n_outputs=2, n_input_mfs=3, n_output_mfs=3, n_rules=7,
                 use_gpu=True, R=200, rf=250, Ts=1):
        self.n_inputs = n_inputs  # 改为3个输入：s4, s5, s7
        self.n_outputs = n_outputs
        self.n_input_mfs = n_input_mfs  # 每个输入3个模糊集
        self.n_output_mfs = n_output_mfs
        self.n_rules = n_rules  # 改为7条规则
        # 动态参数
        self.R = R
        self.rf = rf
        self.Ts = Ts
        self.cos_80 = math.cos(math.radians(80))
        self.cos_60 = math.cos(math .radians(60))
        self.history_len = 200
        # 设备选择
        if use_gpu and torch.cuda.is_available():
            self.device = torch.device('cuda')
            print(f"使用GPU: {torch.cuda.get_device_name()}")
        else:
            self.device = torch.device('cpu')
            print("使用CPU")
        # 历史数据存储
        self.sensor_history = {
            's4': deque(maxlen=self.history_len),
            's5': deque(maxlen=self.history_len),
            's7': deque(maxlen=self.history_len)
        }
        #输出动态参数的基准值
        self.output_base_centers = torch.tensor([300.0, 300.0], dtype=torch.float32, device=self.device)  # 基准中心值
        # 初始化参数
        self._init_static_output_membership_functions()  # 静态初始化，后续动态更新
        self._init_fuzzy_rules()
        # 预计算动态参数相关的常量张量
        self._precompute_dynamic_constants()
        # 预计算所有固定张量
        self._precompute_fixed_tensors()
        # 流水线队列系统
        self.stage_queues = {
            'fuzzification': deque(maxlen=10),
            'rule_evaluation': deque(maxlen=10),
            'clipping': deque(maxlen=10),
            'aggregation': deque(maxlen=10),
            'defuzzification': deque(maxlen=10),
            'output': deque(maxlen=10)
        }
        # 流水线控制
        self.pipeline_running = False
        self.pipeline_threads = []

    def _precompute_dynamic_constants(self):
        # 角度因子张量
        self.angle_factors_tensor = torch.tensor([self.cos_80, self.cos_60, 1.0],
                                                 dtype=torch.float32, device=self.device)
        # 参考基准值张量
        self.ref_base_tensor = (self.R + self.rf) / self.angle_factors_tensor
        # 中心值基准张量
        self.center_bases_tensor = self.ref_base_tensor - self.R
        # 中心值偏移张量
        self.centers_offset_tensor = torch.tensor([-3, 0, 3], dtype=torch.float32, device=self.device)
        # 阈值张量
        self.Ts_tensor = torch.tensor(self.Ts, dtype=torch.float32, device=self.device)
        # 历史数据矩阵缓存
        self._history_matrix = torch.zeros(
            self.n_inputs, self.history_len,
            dtype=torch.float32,
            device=self.device
        )
        # 输出动态参数的偏移张量
        self.output_offset_tensor = torch.tensor([-3, 0, 3], dtype=torch.float32, device=self.device)



    def _init_static_output_membership_functions(self):

        self.output_mf_params = torch.zeros(self.n_outputs, self.n_output_mfs, 2, device=self.device)
        # 初始静态值
        output_centers_matrix = [
            [1, 3, 5],  # leftspeed
            [1, 3, 5]  # rightspeed
        ]
        output_widths_matrix = [
            [0, 0, 0],  # leftspeed宽度
            [0, 0, 0]  # rightspeed宽度
        ]
        self.output_mf_params[:, :, 0] = torch.tensor(output_centers_matrix, device=self.device)
        self.output_mf_params[:, :, 1] = torch.tensor(output_widths_matrix, device=self.device)

    def _init_fuzzy_rules(self):
        """初始化7条模糊规则"""
        predefined_antecedents = [
            #[0, 1, 1],  # s4.near, s5.normal, s7.normal
            [0, 0, 1],  # s4.near, s5.near, s7.normal
            [1, 2, 2],  # s4.normal, s5.far, s7.far
            [1, 1, 1],  # s4.normal, s5.normal, s7.normal
            [2, 2, 2],  # s4.far, s5.far, s7.far
            [0, 0, 0],  # s4.near, s5.near, s7.near
            [1, 0, 0],  # s4.normal, s5.near, s7.near
            [2, 0, 0],  # s4.far, s5.near, s7.near
        ]
        predefined_consequents = [
            #[0, 1],  # 左转 0 1 2 ,慢中快
            [0, 2],  # 左转
            [1, 0],  # 右转
            [1, 1],  # 直行
            [1, 0],  # 右转
            [0, 2],  # 左转
            [0, 2],  # 左转
            [0, 2],  # 左转
        ]
        self.rule_antecedents = torch.tensor(predefined_antecedents, device=self.device)
        self.rule_consequents = torch.tensor(predefined_consequents, device=self.device)

    def _precompute_fixed_tensors(self):
        # 预计算解模糊化参数
        self.output_min = -400.0
        self.output_max = 400.0
        self.n_points = 401
        self.x_points = torch.linspace(self.output_min, self.output_max, self.n_points, device=self.device)
        self.dx = (self.output_max - self.output_min) / (self.n_points - 1)
        self.output_midpoint = (self.output_min + self.output_max) / 2
        self.min_rule_strength = 1e-6
        # 计算规则评估的索引矩阵
        self.input_indices = torch.arange(self.n_inputs, device=self.device).unsqueeze(0).expand(self.n_rules, -1)
        # 计算解模糊化所需的3D张量
        self.x_points_3d = self.x_points.unsqueeze(0).expand(self.n_outputs, -1)  # [2, 301]

    def update_sensor_history(self, sensor_data):
        """更新传感器历史数据"""
        s4, s5, s7 = sensor_data
        self.sensor_history['s4'].append(s4)
        self.sensor_history['s5'].append(s5)
        self.sensor_history['s7'].append(s7)

    def _build_history_matrix(self):
        """构建历史数据矩阵"""
        sensor_keys = ['s4', 's5', 's7']
        for i, key in enumerate(sensor_keys):
            history_list = list(self.sensor_history[key])
            # 用0填充不足的历史数据
            while len(history_list) < self.history_len:
                history_list.insert(0, 0.0)
            self._history_matrix[i] = torch.tensor(history_list, dtype=torch.float32, device=self.device)
        return self._history_matrix

    def _parallel_std(self, history_matrix):
        n_sensors, n_history = history_matrix.shape
        if n_history < 2:
            return torch.zeros(n_sensors, dtype=torch.float32, device=self.device)
        # 并行计算均值
        mean_vals = torch.mean(history_matrix, dim=1, keepdim=True)  # [3, 1]
        # 并行计算方差
        variance = torch.sum((history_matrix - mean_vals) ** 2, dim=1) / (n_history - 1)  # [3]
        # 并行计算标准差，并处理数值稳定性
        std_values = torch.sqrt(torch.clamp(variance, min=1e-8))  # [3]
        # 处理NaN值
        std_values = torch.where(torch.isnan(std_values),
                                 torch.zeros_like(std_values),
                                 std_values)

        return std_values

    def calculate_dynamic_parameters_tensor(self, sensor_data):
        # 转换输入为张量
        current_values = torch.tensor(sensor_data, dtype=torch.float32, device=self.device)
        # 构建历史数据矩阵
        history_matrix = self._build_history_matrix()  # [3, 3]
        # 一次性计算所有参数
        std_values = self._parallel_std(history_matrix)  # [3]
        #print("std_values",std_values)
        e_values =100* 6 * torch.maximum(self.Ts_tensor, std_values)  # [3]
        #e_values = 6 * torch.maximum(self.Ts_tensor, std_values)  # [3]
        # 并行计算参考值
        ref_values = torch.abs(current_values - self.ref_base_tensor)  # [3]
        # 并行计算方差 - 使用条件选择
        sigma_e = e_values / 6  # [3]
        sigma_ref = ref_values / 3  # [3]
        sigma_values = torch.where(e_values > ref_values, sigma_e, sigma_ref)  # [3]
        # 一次性生成所有中心值 - 使用广播
        all_centers = self.center_bases_tensor.unsqueeze(1) + sigma_values.unsqueeze(1) * self.centers_offset_tensor.unsqueeze(0)  # [3, 3]
        #print("sigma_values",sigma_values)
        out_put_sigma_value.append(sigma_values)
        return all_centers, sigma_values

    def calculate_dynamic_output_parameters(self, input_sigmas):
        # input_sigmas: [3] - 输入动态方差
        # 计算输入动态方差的平均值作为输出中心的基准
        avg_sigma = torch.mean(input_sigmas)  # 标量
        print("avg_sigma1",avg_sigma)
        avg_sigma = (avg_sigma / 2500) * 800
        # 输出中心值：μ-3σ, μ, μ+3σ
        dynamic_output_centers = self.output_base_centers.unsqueeze(1) + avg_sigma * self.output_offset_tensor.unsqueeze(0)  # [2, 3]
        # 输出方差：使用输入动态方差的平均值
        dynamic_output_sigmas = avg_sigma.expand(self.n_outputs, self.n_output_mfs)  # [2, 3]
        return dynamic_output_centers, dynamic_output_sigmas
    def _update_dynamic_output_tensors(self, dynamic_output_centers, dynamic_output_sigmas):
        # 更新输出隶属函数参数
        self.output_mf_params[:, :, 0] = dynamic_output_centers  # [2, 3]
        self.output_mf_params[:, :, 1] = dynamic_output_sigmas  # [2, 3]
        # 重新计算输出相关的张量
        self.output_centers = dynamic_output_centers  # [2, 3]
        self.output_widths = dynamic_output_sigmas  # [2, 3]
        self.output_inv_widths_squared = -0.5 / (dynamic_output_sigmas ** 2)  # [2, 3]

    def _precompute_dynamic_3d_matrices(self, dynamic_output_centers, dynamic_output_sigmas):
        all_gaussians = []
        all_consequent_indices = []
        for output_idx in range(self.n_outputs):
            # 当前输出的所有规则后件索引: [n_rules]
            consequent_indices = self.rule_consequents[:, output_idx]  # [7]
            rule_centers = dynamic_output_centers[output_idx][consequent_indices]  # [7]
            rule_inv_widths_squared = self.output_inv_widths_squared[output_idx][consequent_indices]  # [7]
            # self.x_points: [301], rule_centers: [7]
            # 广播计算: [301, 1] - [1, 7] = [301, 7]
            diff_squared = (self.x_points.unsqueeze(1) - rule_centers.unsqueeze(0)) ** 2
            precomputed_gaussians = torch.exp(rule_inv_widths_squared.unsqueeze(0) * diff_squared)
            all_gaussians.append(precomputed_gaussians)
            all_consequent_indices.append(consequent_indices)
        self.all_precomputed_gaussians = torch.stack(all_gaussians, dim=0)  # [2, 301, 7]
        self.all_consequent_indices = torch.stack(all_consequent_indices, dim=0)  # [2, 7]
    def to_device(self, tensor):
        if isinstance(tensor, torch.Tensor):
            return tensor.to(self.device)
        else:
            return torch.tensor(tensor, dtype=torch.float32, device=self.device)
    def stage_1_dynamic_fuzzification_tensor(self, inputs):
        inputs = self.to_device(inputs)
        # 更新历史数据
        self.update_sensor_history(inputs.cpu().tolist())
        # 计算动态参数
        dynamic_centers, dynamic_sigmas = self.calculate_dynamic_parameters_tensor(inputs.cpu().tolist())
        # inputs: [3], dynamic_centers: [3, 3], dynamic_sigmas: [3]
        # 广播计算所有隶属度: [3, 1] - [3, 3] = [3, 3]
        diff = inputs.unsqueeze(1) - dynamic_centers  # [3, 3]
        # 计算高斯隶属函数: [3, 3]
        input_memberships = torch.exp(-0.5 * (diff / dynamic_sigmas.unsqueeze(1)) ** 2)
        return input_memberships, dynamic_centers, dynamic_sigmas


    def stage_2_rule_evaluation(self, input_memberships):
        # input_memberships: [3, 3] - 3个传感器，每个3个模糊集
        all_rule_memberships = input_memberships[self.input_indices, self.rule_antecedents]  # [7, 3]
        rule_strengths = torch.min(all_rule_memberships, dim=1)[0]  # [7]
        return rule_strengths
    def stage_3_clipping_3d(self, rule_strengths):
        all_clipped_3d = torch.minimum(
            self.all_precomputed_gaussians,
            rule_strengths.unsqueeze(0).unsqueeze(0)
        )  # [2, 301, 7]
        return all_clipped_3d
    def stage_4_aggregation_3d(self, all_clipped_3d):
        aggregated_3d = torch.max(all_clipped_3d, dim=2)[0]  # [2, 301]
        return aggregated_3d
    def stage_5_defuzzification_3d(self, aggregated_3d):
        numerator = torch.sum(aggregated_3d * self.x_points_3d * self.dx, dim=1)  # [2]
        denominator = torch.sum(aggregated_3d * self.dx, dim=1)  # [2]
        denominator = torch.clamp(denominator, min=1e-8)
        crisp_outputs = numerator / denominator  # [2]
        return crisp_outputs

    def real_time_inference_dynamic_3d(self, sensor_data):
        input_memberships, dynamic_centers, dynamic_sigmas = self.stage_1_dynamic_fuzzification_tensor(sensor_data)
        dynamic_output_centers, dynamic_output_sigmas = self.calculate_dynamic_output_parameters(dynamic_sigmas)
        self._update_dynamic_output_tensors(dynamic_output_centers, dynamic_output_sigmas)
        self._precompute_dynamic_3d_matrices(dynamic_output_centers, dynamic_output_sigmas)
        rule_strengths = self.stage_2_rule_evaluation(input_memberships)
        all_clipped_3d = self.stage_3_clipping_3d(rule_strengths)  # [2, 301, 7]
        aggregated_3d = self.stage_4_aggregation_3d(all_clipped_3d)  # [2, 301]
        outputs = self.stage_5_defuzzification_3d(aggregated_3d)  # [2]
        processed_outputs = outputs.cpu().numpy()
        return {
            'left_speed': float(processed_outputs[0]),
            'right_speed': float(processed_outputs[1]),
            'timestamp': time.time(),
            'dynamic_params': {
                'input_centers': dynamic_centers.cpu().tolist(),
                'input_sigmas': dynamic_sigmas.cpu().tolist(),
                'output_centers': dynamic_output_centers.cpu().tolist(),
                'output_sigmas': dynamic_output_sigmas.cpu().tolist(),
                'avg_input_sigma': torch.mean(dynamic_sigmas).item()
            }
        }
    def real_time_inference(self, sensor_data):
        return self.real_time_inference_dynamic_3d(sensor_data)


