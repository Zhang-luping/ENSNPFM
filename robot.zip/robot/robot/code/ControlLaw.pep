num_ennp_fc = 
{
	
    H = {WallFollow,DistanceController,HeadingController,SpeedLeft,CruiseSpeedLeft,SpeedRight,CruiseSpeedRight};
					
    structure = [WallFollow 
				[DistanceController ]DistanceController [HeadingController ]HeadingController [SpeedLeft [CruiseSpeedLeft] CruiseSpeedLeft]SpeedLeft [SpeedRight [CruiseSpeedRight] CruiseSpeedRight]SpeedRight
				]WallFollow;
		
    WallFollow = {
	    var = {uErr}; 
        pr = {2*uErr  ->  1|uRight+1|uLeft};
		var0 = (0);
	};
	
	DistanceController = {
        var = {sd,rd,kd}; 
        pr = {kd*rd-kd*sd  ->  1|uErr};
		var0 = (0,0,0);
    };
	
	HeadingController = {
        var = {sa,sf,sb,kh,alfa,gama}; 
        pr = {0-kh*(gama*sa+sf-alfa*sb)  ->  1|uErr};
		var0 = (0,0,0,0,0,0);
		
    };
	SpeedLeft = {
        var = {uLeft,lw}; 
        pr = {uLeft ->  1|lw};
		var0 = (0,0);
    };
	CruiseSpeedLeft = {
        var = {CruiseSpeedleft,lw}; 
        pr = {CruiseSpeedleft ->  1|lw};
		var0 = (0,0);
    };
	SpeedRight = {
        var = {uRight,rw}; 
        pr = {0-uRight ->  1|rw};
		var0 = (0,0);
    };
	CruiseSpeedRight = {
        var = {CruiseSpeedright,rw}; 
        pr = {CruiseSpeedright ->  1|rw};
		var0 = (0,0);
    };
}