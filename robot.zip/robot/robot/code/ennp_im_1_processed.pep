num_ennp_fc = 
{
	# membrane names (labels)
    H = {S4_1,S4_2,S4_3,S4_4,S4_5,S4_6,S4_close,S4_near,S4_normal,S4_far,S4_remote,
		 S5_1,S5_2,S5_3,S5_4,S5_5,S5_6,S5_close,S5_near,S5_normal,S5_far,S5_remote,
		 S6_1,S6_2,S6_3,S6_4,S6_5,S6_6,S6_close,S6_near,S6_normal,S6_far,S6_remote,
		 S7_1,S7_2,S7_3,S7_4,S7_5,S7_6,S7_close,S7_near,S7_normal,S7_far,S7_remote,
		
					layer2_regular_leftspeed1,layer2_regular_leftspeed2,layer2_regular_leftspeed3,layer2_regular_leftspeed4,layer2_regular_leftspeed5,layer2_regular_leftspeed6,layer2_regular_leftspeed7,layer2_regular_leftspeed8,layer2_regular_leftspeed9,layer2_regular_leftspeed10,
					layer2_regular_leftspeed11,layer2_regular_leftspeed12,layer2_regular_leftspeed13,layer2_regular_leftspeed14,layer2_regular_leftspeed15,layer2_regular_leftspeed16,layer2_regular_leftspeed17,layer2_regular_leftspeed18,layer2_regular_leftspeed19,layer2_regular_leftspeed20,
					layer2_regular_leftspeed21,layer2_regular_leftspeed22,layer2_regular_leftspeed23,layer2_regular_leftspeed24,layer2_regular_leftspeed25,layer2_regular_leftspeed26,layer2_regular_leftspeed27,layer2_regular_leftspeed28,layer2_regular_leftspeed29,layer2_regular_leftspeed30,
					layer2_regular_leftspeed31,layer2_regular_leftspeed32,layer2_regular_leftspeed33,layer2_regular_leftspeed34,layer2_regular_leftspeed35,layer2_regular_leftspeed36,layer2_regular_leftspeed37,layer2_regular_leftspeed38,layer2_regular_leftspeed39,layer2_regular_leftspeed40,
					layer2_regular_leftspeed41,layer2_regular_leftspeed42,layer2_regular_leftspeed43,layer2_regular_leftspeed44,layer2_regular_leftspeed45,layer2_regular_leftspeed46,layer2_regular_leftspeed47,layer2_regular_leftspeed48,layer2_regular_leftspeed49,layer2_regular_leftspeed50,
					layer2_regular_leftspeed51,layer2_regular_leftspeed52,layer2_regular_leftspeed53,layer2_regular_leftspeed54,layer2_regular_leftspeed55,layer2_regular_leftspeed56,layer2_regular_leftspeed57,layer2_regular_leftspeed58,layer2_regular_leftspeed59,layer2_regular_leftspeed60,
					layer2_regular_leftspeed61,layer2_regular_leftspeed62,layer2_regular_leftspeed63,layer2_regular_leftspeed64,layer2_regular_leftspeed65,layer2_regular_leftspeed66,layer2_regular_leftspeed67,layer2_regular_leftspeed68,layer2_regular_leftspeed69,layer2_regular_leftspeed70,		
					layer2_regular_leftspeed71,layer2_regular_leftspeed72,layer2_regular_leftspeed73,layer2_regular_leftspeed74,layer2_regular_leftspeed75,layer2_regular_leftspeed76,layer2_regular_leftspeed77,layer2_regular_leftspeed78,layer2_regular_leftspeed79,layer2_regular_leftspeed80,		
					layer2_regular_leftspeed81,layer2_regular_leftspeed82,layer2_regular_leftspeed83,layer2_regular_leftspeed84,layer2_regular_leftspeed85,
					layer3_leftspeed_slow, layer3_leftspeed_normal, layer3_leftspeed_quick, layer3_leftspeed_fast, layer3_rightspeed_slow, layer3_rightspeed_normal, layer3_rightspeed_quick,layer3_rightspeed_fast,
					layer5_leftspeed, layer5_rightspeed,
					layer6_leftspeed,layer6_rightspeed
	
	};
    structure =  [S4_1 ] S4_1 [S4_2 ]S4_2 [S4_3 ]S4_3 [S4_4 ]S4_4 [S4_5 ] S4_5 [S4_6 ]S4_6 [S4_close ]S4_close [S4_near ]S4_near [S4_normal ]S4_normal [S4_far ]S4_far [S4_remote ]S4_remote
			     [S5_1 ] S5_1 [S5_2 ]S5_2 [S5_3 ]S5_3 [S5_4 ]S5_4 [S5_5 ] S5_5 [S5_6 ]S5_6 [S5_close ]S5_close [S5_near ]S5_near [S5_normal ]S5_normal [S5_far ]S5_far [S5_remote ]S5_remote
			     [S6_1 ] S6_1 [S6_2 ]S6_2 [S6_3 ]S6_3 [S6_4 ]S6_4 [S6_5 ] S6_5 [S6_6 ]S6_6 [S6_close ]S6_close [S6_near ]S6_near [S6_normal ]S6_normal [S6_far ]S6_far [S6_remote ]S6_remote
			   
				 [S7_1 ] S7_1 [S7_2 ]S7_2 [S7_3 ]S7_3 [S7_4 ]S7_4 [S7_5 ] S7_5 [S7_6 ]S7_6 [S7_close ]S7_close [S7_near ]S7_near [S7_normal ]S7_normal [S7_far ]S7_far [S7_remote ]S7_remote   
				 [layer2_regular_leftspeed1 ]layer2_regular_leftspeed1 [layer2_regular_leftspeed2 ]layer2_regular_leftspeed2 [layer2_regular_leftspeed3 ]layer2_regular_leftspeed3 [layer2_regular_leftspeed4 ]layer2_regular_leftspeed4 [layer2_regular_leftspeed5 ]layer2_regular_leftspeed5 [layer2_regular_leftspeed6 ]layer2_regular_leftspeed6 [layer2_regular_leftspeed7 ]layer2_regular_leftspeed7 [layer2_regular_leftspeed8 ]layer2_regular_leftspeed8 [layer2_regular_leftspeed9 ]layer2_regular_leftspeed9 [layer2_regular_leftspeed10 ]layer2_regular_leftspeed10
				 [layer2_regular_leftspeed11 ]layer2_regular_leftspeed11 [layer2_regular_leftspeed12 ]layer2_regular_leftspeed12 [layer2_regular_leftspeed13 ]layer2_regular_leftspeed13 [layer2_regular_leftspeed14 ]layer2_regular_leftspeed14 [layer2_regular_leftspeed15 ]layer2_regular_leftspeed15 [layer2_regular_leftspeed16 ]layer2_regular_leftspeed16 [layer2_regular_leftspeed17 ]layer2_regular_leftspeed17 [layer2_regular_leftspeed18 ]layer2_regular_leftspeed18 [layer2_regular_leftspeed19 ]layer2_regular_leftspeed19 [layer2_regular_leftspeed20 ]layer2_regular_leftspeed20
				 [layer2_regular_leftspeed21 ]layer2_regular_leftspeed21 [layer2_regular_leftspeed22 ]layer2_regular_leftspeed22 [layer2_regular_leftspeed23 ]layer2_regular_leftspeed23 [layer2_regular_leftspeed24 ]layer2_regular_leftspeed24 [layer2_regular_leftspeed25 ]layer2_regular_leftspeed25 [layer2_regular_leftspeed26 ]layer2_regular_leftspeed26 [layer2_regular_leftspeed27 ]layer2_regular_leftspeed27 [layer2_regular_leftspeed28 ]layer2_regular_leftspeed28 [layer2_regular_leftspeed29 ]layer2_regular_leftspeed29 [layer2_regular_leftspeed30 ]layer2_regular_leftspeed30
				 [layer2_regular_leftspeed31 ]layer2_regular_leftspeed31 [layer2_regular_leftspeed32 ]layer2_regular_leftspeed32 [layer2_regular_leftspeed33 ]layer2_regular_leftspeed33 [layer2_regular_leftspeed34 ]layer2_regular_leftspeed34 [layer2_regular_leftspeed35 ]layer2_regular_leftspeed35 [layer2_regular_leftspeed36 ]layer2_regular_leftspeed36 [layer2_regular_leftspeed37 ]layer2_regular_leftspeed37 [layer2_regular_leftspeed38 ]layer2_regular_leftspeed38 [layer2_regular_leftspeed39 ]layer2_regular_leftspeed39 [layer2_regular_leftspeed40 ]layer2_regular_leftspeed40
				 [layer2_regular_leftspeed41 ]layer2_regular_leftspeed41 [layer2_regular_leftspeed42 ]layer2_regular_leftspeed42 [layer2_regular_leftspeed43 ]layer2_regular_leftspeed43 [layer2_regular_leftspeed44 ]layer2_regular_leftspeed44 [layer2_regular_leftspeed45 ]layer2_regular_leftspeed45 [layer2_regular_leftspeed46 ]layer2_regular_leftspeed46 [layer2_regular_leftspeed47 ]layer2_regular_leftspeed47 [layer2_regular_leftspeed48 ]layer2_regular_leftspeed48 [layer2_regular_leftspeed49 ]layer2_regular_leftspeed49 [layer2_regular_leftspeed50 ]layer2_regular_leftspeed50
				 [layer2_regular_leftspeed51 ]layer2_regular_leftspeed51 [layer2_regular_leftspeed52 ]layer2_regular_leftspeed52 [layer2_regular_leftspeed53 ]layer2_regular_leftspeed53 [layer2_regular_leftspeed54 ]layer2_regular_leftspeed54 [layer2_regular_leftspeed55 ]layer2_regular_leftspeed55 [layer2_regular_leftspeed56 ]layer2_regular_leftspeed56 [layer2_regular_leftspeed57 ]layer2_regular_leftspeed57 [layer2_regular_leftspeed58 ]layer2_regular_leftspeed58 [layer2_regular_leftspeed59 ]layer2_regular_leftspeed59 [layer2_regular_leftspeed60 ]layer2_regular_leftspeed60
				 [layer2_regular_leftspeed61 ]layer2_regular_leftspeed61 [layer2_regular_leftspeed62 ]layer2_regular_leftspeed62 [layer2_regular_leftspeed63 ]layer2_regular_leftspeed63 [layer2_regular_leftspeed64 ]layer2_regular_leftspeed64 [layer2_regular_leftspeed65 ]layer2_regular_leftspeed65 [layer2_regular_leftspeed66 ]layer2_regular_leftspeed66 [layer2_regular_leftspeed67 ]layer2_regular_leftspeed67 [layer2_regular_leftspeed68 ]layer2_regular_leftspeed68 [layer2_regular_leftspeed69 ]layer2_regular_leftspeed69 [layer2_regular_leftspeed70 ]layer2_regular_leftspeed70
				 [layer2_regular_leftspeed71 ]layer2_regular_leftspeed71 [layer2_regular_leftspeed72 ]layer2_regular_leftspeed72 [layer2_regular_leftspeed73 ]layer2_regular_leftspeed73 [layer2_regular_leftspeed74 ]layer2_regular_leftspeed74 [layer2_regular_leftspeed75 ]layer2_regular_leftspeed75 [layer2_regular_leftspeed76 ]layer2_regular_leftspeed76 [layer2_regular_leftspeed77 ]layer2_regular_leftspeed77 [layer2_regular_leftspeed78 ]layer2_regular_leftspeed78 [layer2_regular_leftspeed79 ]layer2_regular_leftspeed79 [layer2_regular_leftspeed80 ]layer2_regular_leftspeed80
				 [layer2_regular_leftspeed81 ]layer2_regular_leftspeed81 [layer2_regular_leftspeed82 ]layer2_regular_leftspeed82 [layer2_regular_leftspeed83 ]layer2_regular_leftspeed83 [layer2_regular_leftspeed84 ]layer2_regular_leftspeed84 [layer2_regular_leftspeed85 ]layer2_regular_leftspeed85 
				 
				
				 [layer3_leftspeed_slow ]layer3_leftspeed_slow [layer3_leftspeed_normal ]layer3_leftspeed_normal [layer3_leftspeed_quick ]layer3_leftspeed_quick [layer3_leftspeed_fast ]layer3_leftspeed_fast [layer3_rightspeed_slow ]layer3_rightspeed_slow [layer3_rightspeed_normal ]layer3_rightspeed_normal [layer3_rightspeed_quick ]layer3_rightspeed_quick [layer3_rightspeed_fast ]layer3_rightspeed_fast
				 [layer5_leftspeed ]layer5_leftspeed  [layer5_rightspeed ]layer5_rightspeed  
				 [layer6_leftspeed ]layer6_leftspeed [layer6_rightspeed ]layer6_rightspeed];
				

	
	##################################S4
	S4_1 = {
        var = {f0,layer1_S4}; 
        E = {layer1_S4};
        pr = {f0+layer1_S4 [layer1_S4 -> ] 1|layer1_S4_0};
		var0 = (0,0);
        E0  = (0);
    };
	
	S4_2 = {
        var = {f0,layer1_S4_0}; 
        E = {layer1_S4_0};
        pr = {f0+layer1_S4_0 [layer1_S4_0 -> ] 1|layer1_S4_1};
		var0 = (0,0);
        E0  = (0);
    };
	
	S4_3 = {
        var = {f0,layer1_S4_1}; 
        E = {layer1_S4_1};
        pr = {f0+layer1_S4_1 [layer1_S4_1 -> ] 1|layer1_S4_2};
		var0 = (0,0);
        E0  = (0);
    };
	
	S4_4 = {
        var = {f0,layer1_S4_2}; 
        E = {layer1_S4_2};
        pr = {f0+layer1_S4_2 [layer1_S4_2 -> ] 1|layer1_S4_3};
		var0 = (0,0);
        E0  = (0);
    };
	S4_5 = {
        var = {f0,layer1_S4_3}; 
        E = {layer1_S4_3};
        pr = {f0+layer1_S4_3 [layer1_S4_3 -> ] 1|layer1_S4_4};
		var0 = (0,0);
        E0  = (0);
    };

    S4_6 = {
        var = {f0,layer1_S4_4}; 
        E = {layer1_S4_4};
        pr = {f0+max((1) (0.25*((layer1_S4_0-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)*(layer1_S4_0-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)+(layer1_S4_1-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)*(layer1_S4_1-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)+(layer1_S4_2-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)*(layer1_S4_2-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)+(layer1_S4_3-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)*(layer1_S4_3-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)+(layer1_S4_4-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)*(layer1_S4_4-(layer1_S4_0+layer1_S4_1+layer1_S4_2+layer1_S4_3+layer1_S4_4)/5)))) [layer1_S4_4 -> ] 1|e_S4};
		var0 = (0,0);
        E0  = (0);
    };
	S4_close = {
        var = {f0,e_S4,layer1_S4_close_to_layer2}; 
        E = {e_S4};
        pr = {f0+gauss_mf((layer1_S4_0)(1000-6*sqrt(e_S4))(sqrt(e_S4))) [e_S4 -> ] 1|layer1_S4_close_to_layer2};
		var0 = (0,0,0);
        E0  = (0);
    };
	S4_near = {
        var = {f0,layer1_S4_near_to_layer2}; 
        E = {e_S4};
        pr = {f0+gauss_mf((layer1_S4_0)(1000-3*sqrt(e_S4))(sqrt(e_S4))) [e_S4 -> ] 1|layer1_S4_near_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S4_normal = {
        var = {f0,layer1_S4_normal_to_layer2}; 
        E = {e_S4};
        pr = {f0+gauss_mf((layer1_S4_0)(1000)(sqrt(e_S4))) [e_S4 -> ] 1|layer1_S4_normal_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S4_far = {
        var = {f0,layer1_S4_far_to_layer2}; 
        E = {e_S4};
        pr = {f0+gauss_mf((layer1_S4_0)(1000+sqrt(e_S4))(sqrt(e_S4))) [e_S4 -> ] 1|layer1_S4_far_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S4_remote = {
        var = {f0,layer1_S4_remote_to_layer2}; 
        E = {e_S4};
        pr = {f0+gauss_mf((layer1_S4_0)(1000+2*sqrt(e_S4))(sqrt(e_S4))) [e_S4 -> ] 1|layer1_S4_remote_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	
	##################################S5
	S5_1 = {
        var = {f0,layer1_S5}; 
        E = {layer1_S5};
        pr = {f0+layer1_S5 [layer1_S5 -> ] 1|layer1_S5_0};
		var0 = (0,0);
        E0  = (0);
    };
	
	S5_2 = {
        var = {f0,layer1_S5_0}; 
        E = {layer1_S5_0};
        pr = {f0+layer1_S5_0 [layer1_S5_0 -> ] 1|layer1_S5_1};
		var0 = (0,0);
        E0  = (0);
    };
	
	S5_3 = {
        var = {f0,layer1_S5_1}; 
        E = {layer1_S5_1};
        pr = {f0+layer1_S5_1 [layer1_S5_1 -> ] 1|layer1_S5_2};
		var0 = (0,0);
        E0  = (0);
    };
	
	S5_4 = {
        var = {f0,layer1_S5_2}; 
        E = {layer1_S5_2};
        pr = {f0+layer1_S5_2 [layer1_S5_2 -> ] 1|layer1_S5_3};
		var0 = (0,0);
        E0  = (0);
    };
	S5_5 = {
        var = {f0,layer1_S5_3}; 
        E = {layer1_S5_3};
        pr = {f0+layer1_S5_3 [layer1_S5_3 -> ] 1|layer1_S5_4};
		var0 = (0,0);
        E0  = (0);
    };

    S5_6 = {
        var = {f0,layer1_S5_4}; 
        E = {layer1_S5_4};
        pr = {f0+max((1) (0.25*((layer1_S5_0-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)*(layer1_S5_0-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)+(layer1_S5_1-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)*(layer1_S5_1-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)+(layer1_S5_2-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)*(layer1_S5_2-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)+(layer1_S5_3-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)*(layer1_S5_3-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)+(layer1_S5_4-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)*(layer1_S5_4-(layer1_S5_0+layer1_S5_1+layer1_S5_2+layer1_S5_3+layer1_S5_4)/5)))) [layer1_S5_4 -> ] 1|e_S5};
		var0 = (0,0);
        E0  = (0);
    };
	S5_close = {
        var = {f0,e_S5,layer1_S5_close_to_layer2}; 
        E = {e_S5};
        pr = {f0+gauss_mf((layer1_S5_0)(600-3*sqrt(e_S5))(sqrt(e_S5))) [e_S5 -> ] 1|layer1_S5_close_to_layer2};
		var0 = (0,0,0);
        E0  = (0);
    };
	S5_near = {
        var = {f0,layer1_S5_near_to_layer2}; 
        E = {e_S5};
        pr = {f0+gauss_mf((layer1_S5_0)(600-sqrt(e_S5))(sqrt(e_S5))) [e_S5 -> ] 1|layer1_S5_near_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S5_normal = {
        var = {f0,layer1_S5_normal_to_layer2}; 
        E = {e_S5};
        pr = {f0+gauss_mf((layer1_S5_0)(600)(sqrt(e_S5))) [e_S5 -> ] 1|layer1_S5_normal_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S5_far = {
        var = {f0,layer1_S5_far_to_layer2}; 
        E = {e_S5};
        pr = {f0+gauss_mf((layer1_S5_0)(600+sqrt(e_S5))(sqrt(e_S5))) [e_S5 -> ] 1|layer1_S5_far_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S5_remote = {
        var = {f0,layer1_S5_remote_to_layer2}; 
        E = {e_S5};
        pr = {f0+gauss_mf((layer1_S5_0)(600+3*sqrt(e_S5))(sqrt(e_S5))) [e_S5 -> ] 1|layer1_S5_remote_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	##################################S6
	S6_1 = {
        var = {f0,layer1_S6}; 
        E = {layer1_S6};
        pr = {f0+layer1_S6 [layer1_S6 -> ] 1|layer1_S6_0};
		var0 = (0,0);
        E0  = (0);
    };
	
	S6_2 = {
        var = {f0,layer1_S6_0}; 
        E = {layer1_S6_0};
        pr = {f0+layer1_S6_0 [layer1_S6_0 -> ] 1|layer1_S6_1};
		var0 = (0,0);
        E0  = (0);
    };
	
	S6_3 = {
        var = {f0,layer1_S6_1}; 
        E = {layer1_S6_1};
        pr = {f0+layer1_S6_1 [layer1_S6_1 -> ] 1|layer1_S6_2};
		var0 = (0,0);
        E0  = (0);
    };
	
	S6_4 = {
        var = {f0,layer1_S6_2}; 
        E = {layer1_S6_2};
        pr = {f0+layer1_S6_2 [layer1_S6_2 -> ] 1|layer1_S6_3};
		var0 = (0,0);
        E0  = (0);
    };
	S6_5 = {
        var = {f0,layer1_S6_3}; 
        E = {layer1_S6_3};
        pr = {f0+layer1_S6_3 [layer1_S6_3 -> ] 1|layer1_S6_4};
		var0 = (0,0);
        E0  = (0);
    };

    S6_6 = {
        var = {f0,layer1_S6_4}; 
        E = {layer1_S6_4};
        pr = {f0+max((1) (0.25*((layer1_S6_0-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)*(layer1_S6_0-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)+(layer1_S6_1-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)*(layer1_S6_1-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)+(layer1_S6_2-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)*(layer1_S6_2-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)+(layer1_S6_3-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)*(layer1_S6_3-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)+(layer1_S6_4-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)*(layer1_S6_4-(layer1_S6_0+layer1_S6_1+layer1_S6_2+layer1_S6_3+layer1_S6_4)/5)))) [layer1_S6_4 -> ] 1|e_S6};
		
		var0 = (0,0);
        E0  = (0);
    };
	S6_close = {
        var = {f0,e_S6,layer1_S6_close_to_layer2}; 
        E = {e_S6};
        pr = {f0+gauss_mf((layer1_S6_0)(387-3*sqrt(e_S6))(sqrt(e_S6))) [e_S6 -> ] 1|layer1_S6_close_to_layer2};
		
		
        E0  = (0);
		var0 = (0,0,0);
    };
	S6_near = {
        var = {f0,layer1_S6_near_to_layer2}; 
        E = {e_S6};
        pr = {f0+gauss_mf((layer1_S6_0)(387-sqrt(e_S6))(sqrt(e_S6))) [e_S6 -> ] 1|layer1_S6_near_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S6_normal = {
        var = {f0,layer1_S6_normal_to_layer2}; 
        E = {e_S6};
        pr = {f0+gauss_mf((layer1_S6_0)(387)(sqrt(e_S6))) [e_S6 -> ] 1|layer1_S6_normal_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S6_far = {
        var = {f0,layer1_S6_far_to_layer2}; 
        E = {e_S6};
        pr = {f0+gauss_mf((layer1_S6_0)(387+sqrt(e_S6))(sqrt(e_S6))) [e_S6 -> ] 1|layer1_S6_far_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S6_remote = {
        var = {f0,layer1_S6_remote_to_layer2}; 
        E = {e_S6};
        pr = {f0+gauss_mf((layer1_S6_0)(387+3*sqrt(e_S6))(sqrt(e_S6))) [e_S6 -> ] 1|layer1_S6_remote_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	
	##################################S7
	S7_1 = {
        var = {f0,layer1_S7}; 
        E = {layer1_S7};
        pr = {f0+layer1_S7 [layer1_S7 -> ] 1|layer1_S7_0};
		var0 = (0,0);
        E0  = (0);
    };
	
	S7_2 = {
        var = {f0,layer1_S7_0}; 
        E = {layer1_S7_0};
        pr = {f0+layer1_S7_0 [layer1_S7_0 -> ] 1|layer1_S7_1};
		var0 = (0,0);
        E0  = (0);
    };
	
	S7_3 = {
        var = {f0,layer1_S7_1}; 
        E = {layer1_S7_1};
        pr = {f0+layer1_S7_1 [layer1_S7_1 -> ] 1|layer1_S7_2};
		var0 = (0,0);
        E0  = (0);
    };
	
	S7_4 = {
        var = {f0,layer1_S7_2}; 
        E = {layer1_S7_2};
        pr = {f0+layer1_S7_2 [layer1_S7_2 -> ] 1|layer1_S7_3};
		var0 = (0,0);
        E0  = (0);
    };
	S7_5 = {
        var = {f0,layer1_S7_3}; 
        E = {layer1_S7_3};
        pr = {f0+layer1_S7_3 [layer1_S7_3 -> ] 1|layer1_S7_4};
		var0 = (0,0);
        E0  = (0);
    };

    S7_6 = {
        var = {f0,layer1_S7_4}; 
        E = {layer1_S7_4};
        pr = {f0+max((1) (0.25*((layer1_S7_0-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)*(layer1_S7_0-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)+(layer1_S7_1-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)*(layer1_S7_1-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)+(layer1_S7_2-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)*(layer1_S7_2-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)+(layer1_S7_3-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)*(layer1_S7_3-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)+(layer1_S7_4-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)*(layer1_S7_4-(layer1_S7_0+layer1_S7_1+layer1_S7_2+layer1_S7_3+layer1_S7_4)/5)))) [layer1_S7_4 -> ] 1|e_S7};
		var0 = (0,0);
        E0  = (0);
    };
	S7_close = {
        var = {f0,e_S7,layer1_S7_close_to_layer2}; 
        E = {e_S7};
        pr = {f0+gauss_mf((layer1_S7_0)(300 - 3*sqrt(e_S7))(sqrt(e_S7))) [e_S7 -> ] 1|layer1_S7_close_to_layer2};
		var0 = (0,0,0);
        E0  = (0);
    };
	S7_near = {
        var = {f0,layer1_S7_near_to_layer2}; 
        E = {e_S7};
        pr = {f0+gauss_mf((layer1_S7_0)(300-sqrt(e_S7))(sqrt(e_S7))) [e_S7 -> ] 1|layer1_S7_near_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S7_normal = {
        var = {f0,layer1_S7_normal_to_layer2}; 
        E = {e_S7};
        pr = {f0+gauss_mf((layer1_S7_0)(300)(sqrt(e_S7))) [e_S7 -> ] 1|layer1_S7_normal_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S7_far = {
        var = {f0,layer1_S7_far_to_layer2}; 
        E = {e_S7};
        pr = {f0+gauss_mf((layer1_S7_0)(300 + sqrt(e_S7))(sqrt(e_S7))) [e_S7 -> ] 1|layer1_S7_far_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	S7_remote = {
        var = {f0,layer1_S7_remote_to_layer2}; 
        E = {e_S7};
        pr = {f0+gauss_mf((layer1_S7_0)(300 + 3*sqrt(e_S7))(sqrt(e_S7))) [e_S7 -> ] 1|layer1_S7_remote_to_layer2};
		var0 = (0,0);
        E0  = (0);
    };
	
	
	
	
	#layer2   ########################
	
	layer2_regular_leftspeed1 = {
		E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal1,layer2_regular_rightspeed_to_layer3_rightspeed_normal1}; 
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal1 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal1};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed2 = {
		E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow2,layer2_regular_rightspeed_to_layer3_rightspeed_normal2};  
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow2 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal2};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed3 = {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow3,layer2_regular_rightspeed_to_layer3_rightspeed_normal3};  
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow3 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal3};
        var0 = (0,0,0);
		E0  = (1);
      
    };
	layer2_regular_leftspeed4= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow4,layer2_regular_rightspeed_to_layer3_rightspeed_normal4};  
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow4 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal4};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed5= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow5,layer2_regular_rightspeed_to_layer3_rightspeed_fast5};  
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow5 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast5};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed6= {
        E={e2};
	    var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow6,layer2_regular_rightspeed_to_layer3_rightspeed_fast6};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow6 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast6};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed7= {
		E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow7,layer2_regular_rightspeed_to_layer3_rightspeed_normal7};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow7 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal7};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed8= {
		E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal8,layer2_regular_rightspeed_to_layer3_rightspeed_slow8};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal8 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow8};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed9= {
		E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal9,layer2_regular_rightspeed_to_layer3_rightspeed_slow9};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal9 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow9};
       var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed10= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow10,layer2_regular_rightspeed_to_layer3_rightspeed_normal10};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_remote_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow10 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal10};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed11= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_fast11,layer2_regular_rightspeed_to_layer3_rightspeed_normal11};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_fast11 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal11};
       var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed12= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal12,layer2_regular_rightspeed_to_layer3_rightspeed_slow12};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_remote_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal12 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow12};
       var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed13= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal13,layer2_regular_rightspeed_to_layer3_rightspeed_normal13};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal13 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal13};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed14= {
	     E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow14,layer2_regular_rightspeed_to_layer3_rightspeed_normal14};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow14 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal14};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed15= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow15,layer2_regular_rightspeed_to_layer3_rightspeed_normal15};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow15 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal15};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed16= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow16,layer2_regular_rightspeed_to_layer3_rightspeed_normal16};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow16 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal16};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed17= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow17,layer2_regular_rightspeed_to_layer3_rightspeed_fast17};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow17 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast17};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed18= {
	    E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow18,layer2_regular_rightspeed_to_layer3_rightspeed_fast18};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow18 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast18};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed19= {
		 E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow19,layer2_regular_rightspeed_to_layer3_rightspeed_normal19};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow19 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal19};
        var0 = (0,0,0);
         E0  = (1);
    };
	layer2_regular_leftspeed20= {
	   E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal20,layer2_regular_rightspeed_to_layer3_rightspeed_slow20};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal20 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow20};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed21= {
		E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal21,layer2_regular_rightspeed_to_layer3_rightspeed_normal21};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal21 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal21};
        var0 = (0,0,0);
         E0  = (1);
    };
	layer2_regular_leftspeed22= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow22,layer2_regular_rightspeed_to_layer3_rightspeed_normal22};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_remote_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow22 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal22};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed23= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_quick23,layer2_regular_rightspeed_to_layer3_rightspeed_slow23};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_quick23 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow23};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed24= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal24,layer2_regular_rightspeed_to_layer3_rightspeed_slow24};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_remote_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal24 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow24};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed25= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_quick25,layer2_regular_rightspeed_to_layer3_rightspeed_normal25};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_quick25 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal25};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed26= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow26,layer2_regular_rightspeed_to_layer3_rightspeed_normal26};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow26 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal26};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed27= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_quick27,layer2_regular_rightspeed_to_layer3_rightspeed_normal27};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_quick27 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal27};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed28= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_quick28,layer2_regular_rightspeed_to_layer3_rightspeed_slow28};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_far_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_quick28 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow28};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed29= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow29,layer2_regular_rightspeed_to_layer3_rightspeed_normal29};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow29 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal29};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed30= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow30,layer2_regular_rightspeed_to_layer3_rightspeed_normal30};  
        
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow30 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal30};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed31= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal31,layer2_regular_rightspeed_to_layer3_rightspeed_normal31};  
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal31 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal31};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed32= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_quick32,layer2_regular_rightspeed_to_layer3_rightspeed_slow32};  
       
        pr = {f0+2*min((layer1_S4_remote_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_quick32 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow32};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed33= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow33,layer2_regular_rightspeed_to_layer3_rightspeed_normal33};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow33 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal33};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed34= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow34,layer2_regular_rightspeed_to_layer3_rightspeed_fast34};  
      
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow34 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast34};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed35= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow35,layer2_regular_rightspeed_to_layer3_rightspeed_fast35};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow35 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast35};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed36= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow36,layer2_regular_rightspeed_to_layer3_rightspeed_quick36};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow36 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick36};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed37= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow37,layer2_regular_rightspeed_to_layer3_rightspeed_quick37};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow37 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick37};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed38= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow38,layer2_regular_rightspeed_to_layer3_rightspeed_quick38};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow38 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick38};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed39= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow39,layer2_regular_rightspeed_to_layer3_rightspeed_normal39};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow39 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal39};
        var0 = (0,0,0);
       E0  = (1);
    };
	layer2_regular_leftspeed40= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow40,layer2_regular_rightspeed_to_layer3_rightspeed_quick40};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow40 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick40};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed41= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow41,layer2_regular_rightspeed_to_layer3_rightspeed_quick41};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow41 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick41};
        var0 = (0,0,0);
        E0  = (1);
    };
	layer2_regular_leftspeed42= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow42,layer2_regular_rightspeed_to_layer3_rightspeed_normal42};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow42 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal42};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed43= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow43,layer2_regular_rightspeed_to_layer3_rightspeed_normal43};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow43 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal43};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed44= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow44,layer2_regular_rightspeed_to_layer3_rightspeed_quick44};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow44 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick44};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed45= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow45,layer2_regular_rightspeed_to_layer3_rightspeed_quick45};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow45 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick45};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed46= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow46,layer2_regular_rightspeed_to_layer3_rightspeed_normal46};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow46 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal46};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed47= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow47,layer2_regular_rightspeed_to_layer3_rightspeed_quick47};  
      
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow47 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick47};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed48= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow48,layer2_regular_rightspeed_to_layer3_rightspeed_fast48};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow48 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast48};
       var0 = (0,0,0);
	   E0  = (1);
    };
	layer2_regular_leftspeed49= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal49,layer2_regular_rightspeed_to_layer3_rightspeed_normal49};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal49 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal49};
       var0 = (0,0,0);
	   E0  = (1);
    };
	layer2_regular_leftspeed50= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow50,layer2_regular_rightspeed_to_layer3_rightspeed_fast50};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow50 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast50};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed51= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow51,layer2_regular_rightspeed_to_layer3_rightspeed_fast51};  
        
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow51 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast51};
       var0 = (0,0,0);
	   E0  = (1);
    };
	layer2_regular_leftspeed52= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow52,layer2_regular_rightspeed_to_layer3_rightspeed_normal52};  
       
        pr = {f0+2*min((layer1_S4_normal_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow52 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal52};
       var0 = (0,0,0);
	   E0  = (1);
    };
	layer2_regular_leftspeed53= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow53,layer2_regular_rightspeed_to_layer3_rightspeed_normal53};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow53 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal53};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed54= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow54,layer2_regular_rightspeed_to_layer3_rightspeed_normal54};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow54 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal54};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed55= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_quick55,layer2_regular_rightspeed_to_layer3_rightspeed_slow55};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_quick55 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow55};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed56= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal56,layer2_regular_rightspeed_to_layer3_rightspeed_slow56};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal56 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow56};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed57= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal57,layer2_regular_rightspeed_to_layer3_rightspeed_normal57};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal57 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal57};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed58= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow58,layer2_regular_rightspeed_to_layer3_rightspeed_normal58};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow58 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal58};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed59= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow59,layer2_regular_rightspeed_to_layer3_rightspeed_normal59};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow59 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal59};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed60= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow60,layer2_regular_rightspeed_to_layer3_rightspeed_normal60};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow60 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal60};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed61= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow61,layer2_regular_rightspeed_to_layer3_rightspeed_fast61};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow61 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast61};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed62= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow62,layer2_regular_rightspeed_to_layer3_rightspeed_fast62};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow62 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast62};
         var0 = (0,0,0);
		 E0  = (1);
    };
	layer2_regular_leftspeed63= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow63,layer2_regular_rightspeed_to_layer3_rightspeed_normal63};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow63 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal63};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed64= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow64,layer2_regular_rightspeed_to_layer3_rightspeed_normal64};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow64 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal64};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed65= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow65,layer2_regular_rightspeed_to_layer3_rightspeed_normal65};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow65 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal65};
		var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed66= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal66,layer2_regular_rightspeed_to_layer3_rightspeed_normal66};  
       
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_remote_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal66 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal66};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed67= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal67,layer2_regular_rightspeed_to_layer3_rightspeed_normal67};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal67 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal67};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed68= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal68,layer2_regular_rightspeed_to_layer3_rightspeed_normal68};  
        
        pr = {f0+2*min((layer1_S4_far_to_layer2) (min(layer1_S5_remote_to_layer2) min((layer1_S6_remote_to_layer2) (layer1_S7_remote_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal68 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal68};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed69= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow69,layer2_regular_rightspeed_to_layer3_rightspeed_quick69};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow69 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick69};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed70= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow70,layer2_regular_rightspeed_to_layer3_rightspeed_quick70};  
       
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow70 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick70};
		var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed71= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow71,layer2_regular_rightspeed_to_layer3_rightspeed_quick71};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow71 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick71};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed72= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow72,layer2_regular_rightspeed_to_layer3_rightspeed_fast72};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow72 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast72};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed73= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_normal73,layer2_regular_rightspeed_to_layer3_rightspeed_slow73};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_normal73 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_slow73};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed74= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow74,layer2_regular_rightspeed_to_layer3_rightspeed_quick74};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow74 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick74};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed75= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow75,layer2_regular_rightspeed_to_layer3_rightspeed_fast75};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow75 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast75};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed76= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow76,layer2_regular_rightspeed_to_layer3_rightspeed_quick76};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_near_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow76 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick76};
		var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed77= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow77,layer2_regular_rightspeed_to_layer3_rightspeed_normal77};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow77 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal77};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed78= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow78,layer2_regular_rightspeed_to_layer3_rightspeed_quick78};  
       
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_normal_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow78 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick78};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed79= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow79,layer2_regular_rightspeed_to_layer3_rightspeed_normal79};  
       
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_near_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow79 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_normal79};
		var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed80= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow80,layer2_regular_rightspeed_to_layer3_rightspeed_quick80};  
       
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_normal_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow80 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick80};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed81= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow81,layer2_regular_rightspeed_to_layer3_rightspeed_quick81};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2)min((layer1_S6_normal_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow81 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick81};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed82= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow82,layer2_regular_rightspeed_to_layer3_rightspeed_quick82};  
        
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_far_to_layer2) (layer1_S7_far_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow82 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_quick82};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed83= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow83,layer2_regular_rightspeed_to_layer3_rightspeed_fast83};  
       
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow83 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast83};
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed84= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow84,layer2_regular_rightspeed_to_layer3_rightspeed_quick84};  
        pr = {f0+2*min((layer1_S4_near_to_layer2) (min(layer1_S5_normal_to_layer2) min((layer1_S6_near_to_layer2) (layer1_S7_close_to_layer2))))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow84 +1|layer2_regular_rightspeed_to_layer3_rightspeed_quick84 };
        var0 = (0,0,0);
		E0  = (1);
    };
	layer2_regular_leftspeed85= {
	E={e2};
        var = {f0,layer2_regular_leftspeed_to_layer3_leftspeed_slow85,layer2_regular_rightspeed_to_layer3_rightspeed_fast85};  
        
        pr = {f0+2*min((layer1_S6_close_to_layer2) (layer1_S7_close_to_layer2))  [e2 -> ] 1|layer2_regular_leftspeed_to_layer3_leftspeed_slow85 + 1|layer2_regular_rightspeed_to_layer3_rightspeed_fast85};
		var0 = (0,0,0);
		E0  = (1);
    };
	###################layer3#################
	##layer3  ##################
	
	layer3_leftspeed_slow= {
        var = {f0,layer3_leftspeed_slow_to_layer4}; 
        E = {e3};
        pr = {f0 + max((layer2_regular_leftspeed_to_layer3_leftspeed_slow2) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow3) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow4) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow5) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow6) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow7) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow10) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow14) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow15) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow16) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow17) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow18) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow19) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow22) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow29) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow33) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow34) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow35) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow36) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow37) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow38) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow39) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow40) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow41) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow42) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow43) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow44) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow45) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow46) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow47) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow48) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow50) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow51) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow52) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow53) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow54) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow58) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow59) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow60) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow61) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow62) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow63) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow64) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow65) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow69) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow70) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow71) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow72) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow74) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow75) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow76) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow77) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow78) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow79) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow80) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow81) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow82) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow83) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow84) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow85) max((layer2_regular_leftspeed_to_layer3_leftspeed_slow30)(layer2_regular_leftspeed_to_layer3_leftspeed_slow26)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) [e3 -> ] 1|layer3_leftspeed_slow_to_layer4};
       
		var0 = (0,0);
        E0  = (1);
    };
	layer3_leftspeed_normal = {
	 E = {e3};
        var = {f0,layer3_leftspeed_normal_to_layer4}; 
        
        pr = {f0+max((layer2_regular_leftspeed_to_layer3_leftspeed_normal1) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal8) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal9) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal12) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal13) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal20) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal21) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal24)  max((layer2_regular_leftspeed_to_layer3_leftspeed_normal49) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal56) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal57) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal66) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal67) max((layer2_regular_leftspeed_to_layer3_leftspeed_normal68)max((layer2_regular_leftspeed_to_layer3_leftspeed_normal31)(layer2_regular_leftspeed_to_layer3_leftspeed_normal73)))))))))))))))) [e3 -> ] 1|layer3_leftspeed_normal_to_layer4};
       
		var0 = (0,0);
        E0  = (1);
    };
	layer3_leftspeed_quick = {
	 E = {e3};
        var = {f0,layer3_leftspeed_quick_to_layer4}; 
        
        pr = {f0+max((layer2_regular_leftspeed_to_layer3_leftspeed_quick23) max((layer2_regular_leftspeed_to_layer3_leftspeed_quick25) max((layer2_regular_leftspeed_to_layer3_leftspeed_quick27) max((layer2_regular_leftspeed_to_layer3_leftspeed_quick28) max((layer2_regular_leftspeed_to_layer3_leftspeed_quick55)(layer2_regular_leftspeed_to_layer3_leftspeed_quick32)))))) [e3 -> ] 1|layer3_leftspeed_quick_to_layer4};
        
		var0 = (0,0);
        E0  = (1);
    };
	layer3_leftspeed_fast = {
	 E = {e3};
        var = {f0,layer3_leftspeed_fast_to_layer4}; # variables used in the production function
        
        pr = {f0+max((layer2_regular_leftspeed_to_layer3_leftspeed_fast11) (0)) [e3 -> ] 1|layer3_leftspeed_fast_to_layer4};
        var0 = (0,0);
       E0  = (1);
    };
	layer3_rightspeed_slow = {
	 E = {e3};
        var = {f0,layer3_rightspeed_slow_to_layer4}; 
       
        pr = {f0+max((layer2_regular_rightspeed_to_layer3_rightspeed_slow8) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow9) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow12) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow20) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow23) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow24)  max((layer2_regular_rightspeed_to_layer3_rightspeed_slow28) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow55) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow56) max((layer2_regular_rightspeed_to_layer3_rightspeed_slow73) (layer2_regular_rightspeed_to_layer3_rightspeed_slow32)))))))))))  [e3 -> ] 1|layer3_rightspeed_slow_to_layer4};
       
		var0 = (0,0);
       E0  = (1);
    };
	layer3_rightspeed_normal = {
	 E = {e3};
        var = {f0,layer3_rightspeed_normal_to_layer4}; 
       
        pr = {f0+max((layer2_regular_rightspeed_to_layer3_rightspeed_normal1) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal2) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal3) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal4) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal7) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal10) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal11) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal13) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal14) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal15) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal16) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal19) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal21) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal22) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal29) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal30) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal33) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal39) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal42) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal43) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal46) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal49) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal52) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal53) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal54) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal57) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal58) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal59) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal60) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal63) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal64) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal65) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal66) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal67) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal68) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal77) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal79) max((layer2_regular_rightspeed_to_layer3_rightspeed_normal27)max((layer2_regular_rightspeed_to_layer3_rightspeed_normal26)max((layer2_regular_rightspeed_to_layer3_rightspeed_normal31))(layer2_regular_rightspeed_to_layer3_rightspeed_normal25)))))))))))))))))))))))))))))))))))))))) [e3 -> ] 1|layer3_rightspeed_normal_to_layer4};
        var0 = (0,0);
        E0  = (1);
    };
	layer3_rightspeed_quick = {
	 E = {e3};
        var = {f0,layer3_rightspeed_quick_to_layer4}; 
       
        pr = {f0+ max((layer2_regular_rightspeed_to_layer3_rightspeed_quick36) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick37) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick38) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick40) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick41) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick44) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick45) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick47) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick69) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick70) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick71) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick74) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick76) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick78) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick80) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick81) max((layer2_regular_rightspeed_to_layer3_rightspeed_quick82) (layer2_regular_rightspeed_to_layer3_rightspeed_quick84)))))))))))))))))) [e3 -> ] 1|layer3_rightspeed_quick_to_layer4};
        var0 = (0,0);
       E0  = (1);
    };
	layer3_rightspeed_fast = {
	 E = {e3};
        var = {f0,layer3_rightspeed_fast_to_layer4}; 
       
        pr = {f0+max((layer2_regular_rightspeed_to_layer3_rightspeed_fast5) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast6) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast17) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast18)  max((layer2_regular_rightspeed_to_layer3_rightspeed_fast34) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast35) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast48) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast50) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast51) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast61) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast62) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast72) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast75) max((layer2_regular_rightspeed_to_layer3_rightspeed_fast83) (layer2_regular_rightspeed_to_layer3_rightspeed_fast85))))))))))))))) [e3 -> ] 1|layer3_rightspeed_fast_to_layer4};
        var0 = (0,0);
        E0  = (1);
    };
	
	
	layer5_leftspeed = {
		var = {f0,layer5_leftspeed1_to_layer6,layer5_leftspeed2_to_layer6,layer5_leftspeed3_to_layer6,layer5_leftspeed4_to_layer6,layer5_leftspeed5_to_layer6,layer5_leftspeed6_to_layer6,layer5_leftspeed7_to_layer6,layer5_leftspeed8_to_layer6,layer5_leftspeed9_to_layer6,layer5_leftspeed10_to_layer6,layer5_leftspeed11_to_layer6,layer5_leftspeed12_to_layer6,layer5_leftspeed13_to_layer6,layer5_leftspeed14_to_layer6,layer5_leftspeed15_to_layer6,layer5_leftspeed16_to_layer6,layer5_leftspeed17_to_layer6,layer5_leftspeed18_to_layer6,layer5_leftspeed19_to_layer6,layer5_leftspeed20_to_layer6,layer5_leftspeed21_to_layer6,layer5_leftspeed22_to_layer6,layer5_leftspeed23_to_layer6,layer5_leftspeed24_to_layer6,layer5_leftspeed25_to_layer6,layer5_leftspeed26_to_layer6,layer5_leftspeed27_to_layer6,layer5_leftspeed28_to_layer6,layer5_leftspeed29_to_layer6,layer5_leftspeed30_to_layer6,layer5_leftspeed31_to_layer6,layer5_leftspeed32_to_layer6,layer5_leftspeed33_to_layer6,layer5_leftspeed34_to_layer6,layer5_leftspeed35_to_layer6,layer5_leftspeed36_to_layer6,layer5_leftspeed37_to_layer6,layer5_leftspeed38_to_layer6,layer5_leftspeed39_to_layer6,layer5_leftspeed40_to_layer6,layer5_leftspeed41_to_layer6,layer5_leftspeed42_to_layer6,layer5_leftspeed43_to_layer6,layer5_leftspeed44_to_layer6,layer5_leftspeed45_to_layer6,layer5_leftspeed46_to_layer6,layer5_leftspeed47_to_layer6,layer5_leftspeed48_to_layer6,layer5_leftspeed49_to_layer6,layer5_leftspeed50_to_layer6,layer5_leftspeed51_to_layer6,layer5_leftspeed52_to_layer6,layer5_leftspeed53_to_layer6,layer5_leftspeed54_to_layer6,layer5_leftspeed55_to_layer6,layer5_leftspeed56_to_layer6,layer5_leftspeed57_to_layer6,layer5_leftspeed58_to_layer6,layer5_leftspeed59_to_layer6,layer5_leftspeed60_to_layer6,layer5_leftspeed61_to_layer6,layer5_leftspeed62_to_layer6,layer5_leftspeed63_to_layer6,layer5_leftspeed64_to_layer6,layer5_leftspeed65_to_layer6,layer5_leftspeed66_to_layer6,layer5_leftspeed67_to_layer6,layer5_leftspeed68_to_layer6,layer5_leftspeed69_to_layer6,layer5_leftspeed70_to_layer6,layer5_leftspeed71_to_layer6,layer5_leftspeed72_to_layer6,layer5_leftspeed73_to_layer6,layer5_leftspeed74_to_layer6,layer5_leftspeed75_to_layer6,layer5_leftspeed76_to_layer6,layer5_leftspeed77_to_layer6,layer5_leftspeed78_to_layer6,layer5_leftspeed79_to_layer6,layer5_leftspeed80_to_layer6,layer5_leftspeed81_to_layer6,layer5_leftspeed82_to_layer6,layer5_leftspeed83_to_layer6,layer5_leftspeed84_to_layer6,layer5_leftspeed85_to_layer6,layer5_leftspeed86_to_layer6,layer5_leftspeed87_to_layer6,layer5_leftspeed88_to_layer6,layer5_leftspeed89_to_layer6,layer5_leftspeed90_to_layer6,layer5_leftspeed91_to_layer6,layer5_leftspeed92_to_layer6,layer5_leftspeed93_to_layer6,layer5_leftspeed94_to_layer6,layer5_leftspeed95_to_layer6,layer5_leftspeed96_to_layer6,layer5_leftspeed97_to_layer6,layer5_leftspeed98_to_layer6,layer5_leftspeed99_to_layer6,layer5_leftspeed100_to_layer6,layer5_leftspeed101_to_layer6,layer5_leftspeed102_to_layer6,layer5_leftspeed103_to_layer6,layer5_leftspeed104_to_layer6,layer5_leftspeed105_to_layer6,layer5_leftspeed106_to_layer6,layer5_leftspeed107_to_layer6,layer5_leftspeed108_to_layer6,layer5_leftspeed109_to_layer6,layer5_leftspeed110_to_layer6,layer5_leftspeed111_to_layer6,layer5_leftspeed112_to_layer6,layer5_leftspeed113_to_layer6,layer5_leftspeed114_to_layer6,layer5_leftspeed115_to_layer6,layer5_leftspeed116_to_layer6,layer5_leftspeed117_to_layer6,layer5_leftspeed118_to_layer6,layer5_leftspeed119_to_layer6,layer5_leftspeed120_to_layer6,layer5_leftspeed121_to_layer6,layer5_leftspeed122_to_layer6,layer5_leftspeed123_to_layer6,layer5_leftspeed124_to_layer6,layer5_leftspeed125_to_layer6,layer5_leftspeed126_to_layer6,layer5_leftspeed127_to_layer6,layer5_leftspeed128_to_layer6,layer5_leftspeed129_to_layer6,layer5_leftspeed130_to_layer6,layer5_leftspeed131_to_layer6,layer5_leftspeed132_to_layer6,layer5_leftspeed133_to_layer6,layer5_leftspeed134_to_layer6,layer5_leftspeed135_to_layer6,layer5_leftspeed136_to_layer6,layer5_leftspeed137_to_layer6,layer5_leftspeed138_to_layer6,layer5_leftspeed139_to_layer6,layer5_leftspeed140_to_layer6,layer5_leftspeed141_to_layer6,layer5_leftspeed142_to_layer6,layer5_leftspeed143_to_layer6,layer5_leftspeed144_to_layer6,layer5_leftspeed145_to_layer6,layer5_leftspeed146_to_layer6,layer5_leftspeed147_to_layer6,layer5_leftspeed148_to_layer6,layer5_leftspeed149_to_layer6,layer5_leftspeed150_to_layer6,layer5_leftspeed151_to_layer6,layer5_leftspeed152_to_layer6,layer5_leftspeed153_to_layer6,layer5_leftspeed154_to_layer6,layer5_leftspeed155_to_layer6,layer5_leftspeed156_to_layer6,layer5_leftspeed157_to_layer6,layer5_leftspeed158_to_layer6,layer5_leftspeed159_to_layer6,layer5_leftspeed160_to_layer6,layer5_leftspeed161_to_layer6,layer5_leftspeed162_to_layer6,layer5_leftspeed163_to_layer6,layer5_leftspeed164_to_layer6,layer5_leftspeed165_to_layer6,layer5_leftspeed166_to_layer6,layer5_leftspeed167_to_layer6,layer5_leftspeed168_to_layer6,layer5_leftspeed169_to_layer6,layer5_leftspeed170_to_layer6,layer5_leftspeed171_to_layer6,layer5_leftspeed172_to_layer6,layer5_leftspeed173_to_layer6,layer5_leftspeed174_to_layer6,layer5_leftspeed175_to_layer6,layer5_leftspeed176_to_layer6,layer5_leftspeed177_to_layer6,layer5_leftspeed178_to_layer6,layer5_leftspeed179_to_layer6,layer5_leftspeed180_to_layer6,layer5_leftspeed181_to_layer6,layer5_leftspeed182_to_layer6,layer5_leftspeed183_to_layer6,layer5_leftspeed184_to_layer6,layer5_leftspeed185_to_layer6,layer5_leftspeed186_to_layer6,layer5_leftspeed187_to_layer6,layer5_leftspeed188_to_layer6,layer5_leftspeed189_to_layer6,layer5_leftspeed190_to_layer6,layer5_leftspeed191_to_layer6,layer5_leftspeed192_to_layer6,layer5_leftspeed193_to_layer6,layer5_leftspeed194_to_layer6,layer5_leftspeed195_to_layer6,layer5_leftspeed196_to_layer6,layer5_leftspeed197_to_layer6,layer5_leftspeed198_to_layer6,layer5_leftspeed199_to_layer6,layer5_leftspeed200_to_layer6,layer5_leftspeed201_to_layer6,layer5_leftspeed202_to_layer6,layer5_leftspeed203_to_layer6,layer5_leftspeed204_to_layer6,layer5_leftspeed205_to_layer6,layer5_leftspeed206_to_layer6,layer5_leftspeed207_to_layer6,layer5_leftspeed208_to_layer6,layer5_leftspeed209_to_layer6,layer5_leftspeed210_to_layer6,layer5_leftspeed211_to_layer6,layer5_leftspeed212_to_layer6,layer5_leftspeed213_to_layer6,layer5_leftspeed214_to_layer6,layer5_leftspeed215_to_layer6,layer5_leftspeed216_to_layer6,layer5_leftspeed217_to_layer6,layer5_leftspeed218_to_layer6,layer5_leftspeed219_to_layer6,layer5_leftspeed220_to_layer6,layer5_leftspeed221_to_layer6,layer5_leftspeed222_to_layer6,layer5_leftspeed223_to_layer6,layer5_leftspeed224_to_layer6,layer5_leftspeed225_to_layer6,layer5_leftspeed226_to_layer6,layer5_leftspeed227_to_layer6,layer5_leftspeed228_to_layer6,layer5_leftspeed229_to_layer6,layer5_leftspeed230_to_layer6,layer5_leftspeed231_to_layer6,layer5_leftspeed232_to_layer6,layer5_leftspeed233_to_layer6,layer5_leftspeed234_to_layer6,layer5_leftspeed235_to_layer6,layer5_leftspeed236_to_layer6,layer5_leftspeed237_to_layer6,layer5_leftspeed238_to_layer6,layer5_leftspeed239_to_layer6,layer5_leftspeed240_to_layer6,layer5_leftspeed241_to_layer6,layer5_leftspeed242_to_layer6,layer5_leftspeed243_to_layer6,layer5_leftspeed244_to_layer6,layer5_leftspeed245_to_layer6,layer5_leftspeed246_to_layer6,layer5_leftspeed247_to_layer6,layer5_leftspeed248_to_layer6,layer5_leftspeed249_to_layer6,layer5_leftspeed250_to_layer6,layer5_leftspeed251_to_layer6,layer5_leftspeed252_to_layer6,layer5_leftspeed253_to_layer6,layer5_leftspeed254_to_layer6,layer5_leftspeed255_to_layer6,layer5_leftspeed256_to_layer6,layer5_leftspeed257_to_layer6,layer5_leftspeed258_to_layer6,layer5_leftspeed259_to_layer6,layer5_leftspeed260_to_layer6,layer5_leftspeed261_to_layer6,layer5_leftspeed262_to_layer6,layer5_leftspeed263_to_layer6,layer5_leftspeed264_to_layer6,layer5_leftspeed265_to_layer6,layer5_leftspeed266_to_layer6,layer5_leftspeed267_to_layer6,layer5_leftspeed268_to_layer6,layer5_leftspeed269_to_layer6,layer5_leftspeed270_to_layer6,layer5_leftspeed271_to_layer6,layer5_leftspeed272_to_layer6,layer5_leftspeed273_to_layer6,layer5_leftspeed274_to_layer6,layer5_leftspeed275_to_layer6,layer5_leftspeed276_to_layer6,layer5_leftspeed277_to_layer6,layer5_leftspeed278_to_layer6,layer5_leftspeed279_to_layer6,layer5_leftspeed280_to_layer6,layer5_leftspeed281_to_layer6,layer5_leftspeed282_to_layer6,layer5_leftspeed283_to_layer6,layer5_leftspeed284_to_layer6,layer5_leftspeed285_to_layer6,layer5_leftspeed286_to_layer6,layer5_leftspeed287_to_layer6,layer5_leftspeed288_to_layer6,layer5_leftspeed289_to_layer6,layer5_leftspeed290_to_layer6,layer5_leftspeed291_to_layer6,layer5_leftspeed292_to_layer6,layer5_leftspeed293_to_layer6,layer5_leftspeed294_to_layer6,layer5_leftspeed295_to_layer6,layer5_leftspeed296_to_layer6,layer5_leftspeed297_to_layer6,layer5_leftspeed298_to_layer6,layer5_leftspeed299_to_layer6,layer5_leftspeed300_to_layer6};  
		 
		E = {e4};
		  pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.103))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed1_to_layer6};
         
		  pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.112))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed2_to_layer6};
         
		 pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.121))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed3_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.132))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed4_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.143))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed5_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.154))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed6_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.167))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed7_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.18))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed8_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.193))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed9_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.208))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed10_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.223))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed11_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.238))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed12_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.255))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed13_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.272))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed14_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.29))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed15_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.309))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed16_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.328))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed17_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.348))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed18_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.368))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed19_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.389))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed20_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.411))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed21_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.433))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed22_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.456))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed23_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.479))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed24_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.502))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed25_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.526))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed26_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.55))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed27_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.574))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed28_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.598))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed29_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.623))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed30_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.647))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed31_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.671))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed32_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.695))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed33_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.718))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed34_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.742))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed35_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.764))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed36_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.786))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed37_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.808))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed38_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.829))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed39_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.848))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed40_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.867))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed41_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.885))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed42_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.902))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed43_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.918))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed44_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.933))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed45_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.946))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed46_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.958))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed47_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.968))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed48_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.978))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed49_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.985))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed50_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.991))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed51_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.996))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed52_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.999))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed53_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (1.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed54_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (1.0))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed55_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.998))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed56_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.994))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed57_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.989))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed58_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.983))) (min((layer3_leftspeed_normal_to_layer4) (0.003))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed59_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.975))) (min((layer3_leftspeed_normal_to_layer4) (0.003))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed60_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.965))) (min((layer3_leftspeed_normal_to_layer4) (0.003))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed61_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.954))) (min((layer3_leftspeed_normal_to_layer4) (0.004))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed62_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.942))) (min((layer3_leftspeed_normal_to_layer4) (0.004))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed63_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.928))) (min((layer3_leftspeed_normal_to_layer4) (0.005))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed64_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.913))) (min((layer3_leftspeed_normal_to_layer4) (0.006))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed65_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.897))) (min((layer3_leftspeed_normal_to_layer4) (0.006))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed66_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.88))) (min((layer3_leftspeed_normal_to_layer4) (0.007))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed67_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.861))) (min((layer3_leftspeed_normal_to_layer4) (0.008))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed68_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.842))) (min((layer3_leftspeed_normal_to_layer4) (0.009))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed69_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.822))) (min((layer3_leftspeed_normal_to_layer4) (0.01))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed70_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.801))) (min((layer3_leftspeed_normal_to_layer4) (0.011))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed71_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.779))) (min((layer3_leftspeed_normal_to_layer4) (0.012))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed72_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.757))) (min((layer3_leftspeed_normal_to_layer4) (0.014))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed73_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.734))) (min((layer3_leftspeed_normal_to_layer4) (0.015))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed74_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.711))) (min((layer3_leftspeed_normal_to_layer4) (0.017))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed75_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.687))) (min((layer3_leftspeed_normal_to_layer4) (0.019))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed76_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.663))) (min((layer3_leftspeed_normal_to_layer4) (0.021))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed77_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.639))) (min((layer3_leftspeed_normal_to_layer4) (0.024))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed78_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.615))) (min((layer3_leftspeed_normal_to_layer4) (0.026))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed79_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.59))) (min((layer3_leftspeed_normal_to_layer4) (0.029))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed80_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.566))) (min((layer3_leftspeed_normal_to_layer4) (0.032))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed81_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.542))) (min((layer3_leftspeed_normal_to_layer4) (0.035))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed82_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.518))) (min((layer3_leftspeed_normal_to_layer4) (0.039))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed83_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.495))) (min((layer3_leftspeed_normal_to_layer4) (0.043))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed84_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.471))) (min((layer3_leftspeed_normal_to_layer4) (0.047))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed85_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.448))) (min((layer3_leftspeed_normal_to_layer4) (0.051))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed86_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.426))) (min((layer3_leftspeed_normal_to_layer4) (0.056))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed87_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.404))) (min((layer3_leftspeed_normal_to_layer4) (0.061))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed88_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.382))) (min((layer3_leftspeed_normal_to_layer4) (0.067))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed89_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.361))) (min((layer3_leftspeed_normal_to_layer4) (0.073))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed90_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.341))) (min((layer3_leftspeed_normal_to_layer4) (0.08))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed91_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.321))) (min((layer3_leftspeed_normal_to_layer4) (0.087))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed92_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.302))) (min((layer3_leftspeed_normal_to_layer4) (0.094))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed93_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.284))) (min((layer3_leftspeed_normal_to_layer4) (0.102))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed94_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.266))) (min((layer3_leftspeed_normal_to_layer4) (0.11))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed95_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.249))) (min((layer3_leftspeed_normal_to_layer4) (0.119))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed96_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.233))) (min((layer3_leftspeed_normal_to_layer4) (0.129))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed97_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.218))) (min((layer3_leftspeed_normal_to_layer4) (0.139))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed98_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.203))) (min((layer3_leftspeed_normal_to_layer4) (0.149))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed99_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.189))) (min((layer3_leftspeed_normal_to_layer4) (0.161))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed100_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.175))) (min((layer3_leftspeed_normal_to_layer4) (0.172))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed101_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.162))) (min((layer3_leftspeed_normal_to_layer4) (0.185))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed102_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.15))) (min((layer3_leftspeed_normal_to_layer4) (0.198))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed103_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.139))) (min((layer3_leftspeed_normal_to_layer4) (0.212))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed104_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.128))) (min((layer3_leftspeed_normal_to_layer4) (0.226))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed105_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.118))) (min((layer3_leftspeed_normal_to_layer4) (0.241))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed106_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.109))) (min((layer3_leftspeed_normal_to_layer4) (0.256))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed107_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.1))) (min((layer3_leftspeed_normal_to_layer4) (0.273))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed108_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.092))) (min((layer3_leftspeed_normal_to_layer4) (0.289))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed109_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.084))) (min((layer3_leftspeed_normal_to_layer4) (0.307))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed110_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.077))) (min((layer3_leftspeed_normal_to_layer4) (0.325))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed111_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.07))) (min((layer3_leftspeed_normal_to_layer4) (0.343))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed112_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.064))) (min((layer3_leftspeed_normal_to_layer4) (0.362))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed113_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.058))) (min((layer3_leftspeed_normal_to_layer4) (0.382))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed114_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.053))) (min((layer3_leftspeed_normal_to_layer4) (0.402))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed115_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.048))) (min((layer3_leftspeed_normal_to_layer4) (0.423))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed116_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.043))) (min((layer3_leftspeed_normal_to_layer4) (0.444))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed117_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.039))) (min((layer3_leftspeed_normal_to_layer4) (0.465))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed118_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.035))) (min((layer3_leftspeed_normal_to_layer4) (0.487))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed119_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.032))) (min((layer3_leftspeed_normal_to_layer4) (0.509))) (min((layer3_leftspeed_quick_to_layer4) (0.0))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed120_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.029))) (min((layer3_leftspeed_normal_to_layer4) (0.531))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed121_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.026))) (min((layer3_leftspeed_normal_to_layer4) (0.554))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed122_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.023))) (min((layer3_leftspeed_normal_to_layer4) (0.576))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed123_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.021))) (min((layer3_leftspeed_normal_to_layer4) (0.599))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed124_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.018))) (min((layer3_leftspeed_normal_to_layer4) (0.622))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed125_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.016))) (min((layer3_leftspeed_normal_to_layer4) (0.644))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed126_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.015))) (min((layer3_leftspeed_normal_to_layer4) (0.667))) (min((layer3_leftspeed_quick_to_layer4) (0.001))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed127_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.013))) (min((layer3_leftspeed_normal_to_layer4) (0.689))) (min((layer3_leftspeed_quick_to_layer4) (0.002))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed128_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.012))) (min((layer3_leftspeed_normal_to_layer4) (0.712))) (min((layer3_leftspeed_quick_to_layer4) (0.002))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed129_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.01))) (min((layer3_leftspeed_normal_to_layer4) (0.733))) (min((layer3_leftspeed_quick_to_layer4) (0.002))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed130_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.009))) (min((layer3_leftspeed_normal_to_layer4) (0.755))) (min((layer3_leftspeed_quick_to_layer4) (0.002))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed131_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.008))) (min((layer3_leftspeed_normal_to_layer4) (0.776))) (min((layer3_leftspeed_quick_to_layer4) (0.003))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed132_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.007))) (min((layer3_leftspeed_normal_to_layer4) (0.796))) (min((layer3_leftspeed_quick_to_layer4) (0.003))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed133_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.006))) (min((layer3_leftspeed_normal_to_layer4) (0.816))) (min((layer3_leftspeed_quick_to_layer4) (0.004))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed134_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.005))) (min((layer3_leftspeed_normal_to_layer4) (0.835))) (min((layer3_leftspeed_quick_to_layer4) (0.004))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed135_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.005))) (min((layer3_leftspeed_normal_to_layer4) (0.854))) (min((layer3_leftspeed_quick_to_layer4) (0.005))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed136_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.004))) (min((layer3_leftspeed_normal_to_layer4) (0.871))) (min((layer3_leftspeed_quick_to_layer4) (0.005))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed137_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.004))) (min((layer3_leftspeed_normal_to_layer4) (0.888))) (min((layer3_leftspeed_quick_to_layer4) (0.006))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed138_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.003))) (min((layer3_leftspeed_normal_to_layer4) (0.904))) (min((layer3_leftspeed_quick_to_layer4) (0.007))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed139_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.003))) (min((layer3_leftspeed_normal_to_layer4) (0.918))) (min((layer3_leftspeed_quick_to_layer4) (0.008))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed140_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.002))) (min((layer3_leftspeed_normal_to_layer4) (0.932))) (min((layer3_leftspeed_quick_to_layer4) (0.009))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed141_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.002))) (min((layer3_leftspeed_normal_to_layer4) (0.945))) (min((layer3_leftspeed_quick_to_layer4) (0.01))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed142_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.002))) (min((layer3_leftspeed_normal_to_layer4) (0.956))) (min((layer3_leftspeed_quick_to_layer4) (0.012))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed143_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.002))) (min((layer3_leftspeed_normal_to_layer4) (0.966))) (min((layer3_leftspeed_quick_to_layer4) (0.013))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed144_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (0.975))) (min((layer3_leftspeed_quick_to_layer4) (0.015))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed145_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (0.983))) (min((layer3_leftspeed_quick_to_layer4) (0.016))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed146_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (0.989))) (min((layer3_leftspeed_quick_to_layer4) (0.018))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed147_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (0.994))) (min((layer3_leftspeed_quick_to_layer4) (0.021))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed148_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (0.997))) (min((layer3_leftspeed_quick_to_layer4) (0.023))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed149_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (0.999))) (min((layer3_leftspeed_quick_to_layer4) (0.026))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed150_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.001))) (min((layer3_leftspeed_normal_to_layer4) (1.0))) (min((layer3_leftspeed_quick_to_layer4) (0.029))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed151_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.999))) (min((layer3_leftspeed_quick_to_layer4) (0.032))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed152_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.997))) (min((layer3_leftspeed_quick_to_layer4) (0.035))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed153_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.994))) (min((layer3_leftspeed_quick_to_layer4) (0.039))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed154_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.989))) (min((layer3_leftspeed_quick_to_layer4) (0.043))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed155_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.983))) (min((layer3_leftspeed_quick_to_layer4) (0.048))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed156_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.975))) (min((layer3_leftspeed_quick_to_layer4) (0.053))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed157_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.966))) (min((layer3_leftspeed_quick_to_layer4) (0.058))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed158_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.956))) (min((layer3_leftspeed_quick_to_layer4) (0.064))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed159_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.945))) (min((layer3_leftspeed_quick_to_layer4) (0.07))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed160_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.932))) (min((layer3_leftspeed_quick_to_layer4) (0.077))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed161_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.918))) (min((layer3_leftspeed_quick_to_layer4) (0.084))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed162_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.904))) (min((layer3_leftspeed_quick_to_layer4) (0.092))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed163_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.888))) (min((layer3_leftspeed_quick_to_layer4) (0.1))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed164_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.871))) (min((layer3_leftspeed_quick_to_layer4) (0.109))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed165_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.854))) (min((layer3_leftspeed_quick_to_layer4) (0.118))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed166_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.835))) (min((layer3_leftspeed_quick_to_layer4) (0.128))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed167_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.816))) (min((layer3_leftspeed_quick_to_layer4) (0.139))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed168_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.796))) (min((layer3_leftspeed_quick_to_layer4) (0.15))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed169_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.776))) (min((layer3_leftspeed_quick_to_layer4) (0.162))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed170_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.755))) (min((layer3_leftspeed_quick_to_layer4) (0.175))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed171_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.733))) (min((layer3_leftspeed_quick_to_layer4) (0.189))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed172_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.712))) (min((layer3_leftspeed_quick_to_layer4) (0.203))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed173_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.689))) (min((layer3_leftspeed_quick_to_layer4) (0.218))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed174_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.667))) (min((layer3_leftspeed_quick_to_layer4) (0.233))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed175_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.644))) (min((layer3_leftspeed_quick_to_layer4) (0.249))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed176_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.622))) (min((layer3_leftspeed_quick_to_layer4) (0.266))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed177_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.599))) (min((layer3_leftspeed_quick_to_layer4) (0.284))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed178_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.576))) (min((layer3_leftspeed_quick_to_layer4) (0.302))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed179_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.554))) (min((layer3_leftspeed_quick_to_layer4) (0.321))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed180_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.531))) (min((layer3_leftspeed_quick_to_layer4) (0.341))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed181_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.509))) (min((layer3_leftspeed_quick_to_layer4) (0.361))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed182_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.487))) (min((layer3_leftspeed_quick_to_layer4) (0.382))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed183_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.465))) (min((layer3_leftspeed_quick_to_layer4) (0.404))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed184_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.444))) (min((layer3_leftspeed_quick_to_layer4) (0.426))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed185_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.423))) (min((layer3_leftspeed_quick_to_layer4) (0.448))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed186_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.402))) (min((layer3_leftspeed_quick_to_layer4) (0.471))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed187_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.382))) (min((layer3_leftspeed_quick_to_layer4) (0.495))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed188_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.362))) (min((layer3_leftspeed_quick_to_layer4) (0.518))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed189_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.343))) (min((layer3_leftspeed_quick_to_layer4) (0.542))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed190_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.325))) (min((layer3_leftspeed_quick_to_layer4) (0.566))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed191_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.307))) (min((layer3_leftspeed_quick_to_layer4) (0.59))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed192_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.289))) (min((layer3_leftspeed_quick_to_layer4) (0.615))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed193_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.273))) (min((layer3_leftspeed_quick_to_layer4) (0.639))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed194_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.256))) (min((layer3_leftspeed_quick_to_layer4) (0.663))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed195_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.241))) (min((layer3_leftspeed_quick_to_layer4) (0.687))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed196_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.226))) (min((layer3_leftspeed_quick_to_layer4) (0.711))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed197_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.212))) (min((layer3_leftspeed_quick_to_layer4) (0.734))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed198_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.198))) (min((layer3_leftspeed_quick_to_layer4) (0.757))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed199_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.185))) (min((layer3_leftspeed_quick_to_layer4) (0.779))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed200_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.172))) (min((layer3_leftspeed_quick_to_layer4) (0.801))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed201_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.161))) (min((layer3_leftspeed_quick_to_layer4) (0.822))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed202_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.149))) (min((layer3_leftspeed_quick_to_layer4) (0.842))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed203_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.139))) (min((layer3_leftspeed_quick_to_layer4) (0.861))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed204_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.129))) (min((layer3_leftspeed_quick_to_layer4) (0.88))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed205_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.119))) (min((layer3_leftspeed_quick_to_layer4) (0.897))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed206_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.11))) (min((layer3_leftspeed_quick_to_layer4) (0.913))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed207_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.102))) (min((layer3_leftspeed_quick_to_layer4) (0.928))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed208_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.094))) (min((layer3_leftspeed_quick_to_layer4) (0.942))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed209_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.087))) (min((layer3_leftspeed_quick_to_layer4) (0.954))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed210_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.08))) (min((layer3_leftspeed_quick_to_layer4) (0.965))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed211_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.073))) (min((layer3_leftspeed_quick_to_layer4) (0.975))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed212_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.067))) (min((layer3_leftspeed_quick_to_layer4) (0.983))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed213_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.061))) (min((layer3_leftspeed_quick_to_layer4) (0.989))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed214_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.056))) (min((layer3_leftspeed_quick_to_layer4) (0.994))) (min((layer3_leftspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_leftspeed215_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.051))) (min((layer3_leftspeed_quick_to_layer4) (0.998))) (min((layer3_leftspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_leftspeed216_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.047))) (min((layer3_leftspeed_quick_to_layer4) (1.0))) (min((layer3_leftspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_leftspeed217_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.043))) (min((layer3_leftspeed_quick_to_layer4) (1.0))) (min((layer3_leftspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_leftspeed218_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.039))) (min((layer3_leftspeed_quick_to_layer4) (0.999))) (min((layer3_leftspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_leftspeed219_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.035))) (min((layer3_leftspeed_quick_to_layer4) (0.996))) (min((layer3_leftspeed_fast_to_layer4) (0.002))))  [e4 ->] 1 | layer5_leftspeed220_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.032))) (min((layer3_leftspeed_quick_to_layer4) (0.991))) (min((layer3_leftspeed_fast_to_layer4) (0.002))))  [e4 ->] 1 | layer5_leftspeed221_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.029))) (min((layer3_leftspeed_quick_to_layer4) (0.985))) (min((layer3_leftspeed_fast_to_layer4) (0.003))))  [e4 ->] 1 | layer5_leftspeed222_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.026))) (min((layer3_leftspeed_quick_to_layer4) (0.978))) (min((layer3_leftspeed_fast_to_layer4) (0.004))))  [e4 ->] 1 | layer5_leftspeed223_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.024))) (min((layer3_leftspeed_quick_to_layer4) (0.968))) (min((layer3_leftspeed_fast_to_layer4) (0.005))))  [e4 ->] 1 | layer5_leftspeed224_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.021))) (min((layer3_leftspeed_quick_to_layer4) (0.958))) (min((layer3_leftspeed_fast_to_layer4) (0.006))))  [e4 ->] 1 | layer5_leftspeed225_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.019))) (min((layer3_leftspeed_quick_to_layer4) (0.946))) (min((layer3_leftspeed_fast_to_layer4) (0.008))))  [e4 ->] 1 | layer5_leftspeed226_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.017))) (min((layer3_leftspeed_quick_to_layer4) (0.933))) (min((layer3_leftspeed_fast_to_layer4) (0.01))))  [e4 ->] 1 | layer5_leftspeed227_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.015))) (min((layer3_leftspeed_quick_to_layer4) (0.918))) (min((layer3_leftspeed_fast_to_layer4) (0.012))))  [e4 ->] 1 | layer5_leftspeed228_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.014))) (min((layer3_leftspeed_quick_to_layer4) (0.902))) (min((layer3_leftspeed_fast_to_layer4) (0.015))))  [e4 ->] 1 | layer5_leftspeed229_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.012))) (min((layer3_leftspeed_quick_to_layer4) (0.885))) (min((layer3_leftspeed_fast_to_layer4) (0.018))))  [e4 ->] 1 | layer5_leftspeed230_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.011))) (min((layer3_leftspeed_quick_to_layer4) (0.867))) (min((layer3_leftspeed_fast_to_layer4) (0.023))))  [e4 ->] 1 | layer5_leftspeed231_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.01))) (min((layer3_leftspeed_quick_to_layer4) (0.848))) (min((layer3_leftspeed_fast_to_layer4) (0.028))))  [e4 ->] 1 | layer5_leftspeed232_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.009))) (min((layer3_leftspeed_quick_to_layer4) (0.829))) (min((layer3_leftspeed_fast_to_layer4) (0.034))))  [e4 ->] 1 | layer5_leftspeed233_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.008))) (min((layer3_leftspeed_quick_to_layer4) (0.808))) (min((layer3_leftspeed_fast_to_layer4) (0.041))))  [e4 ->] 1 | layer5_leftspeed234_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.007))) (min((layer3_leftspeed_quick_to_layer4) (0.786))) (min((layer3_leftspeed_fast_to_layer4) (0.05))))  [e4 ->] 1 | layer5_leftspeed235_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.006))) (min((layer3_leftspeed_quick_to_layer4) (0.764))) (min((layer3_leftspeed_fast_to_layer4) (0.06))))  [e4 ->] 1 | layer5_leftspeed236_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.006))) (min((layer3_leftspeed_quick_to_layer4) (0.742))) (min((layer3_leftspeed_fast_to_layer4) (0.071))))  [e4 ->] 1 | layer5_leftspeed237_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.005))) (min((layer3_leftspeed_quick_to_layer4) (0.718))) (min((layer3_leftspeed_fast_to_layer4) (0.084))))  [e4 ->] 1 | layer5_leftspeed238_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.004))) (min((layer3_leftspeed_quick_to_layer4) (0.695))) (min((layer3_leftspeed_fast_to_layer4) (0.099))))  [e4 ->] 1 | layer5_leftspeed239_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.004))) (min((layer3_leftspeed_quick_to_layer4) (0.671))) (min((layer3_leftspeed_fast_to_layer4) (0.116))))  [e4 ->] 1 | layer5_leftspeed240_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.003))) (min((layer3_leftspeed_quick_to_layer4) (0.647))) (min((layer3_leftspeed_fast_to_layer4) (0.135))))  [e4 ->] 1 | layer5_leftspeed241_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.003))) (min((layer3_leftspeed_quick_to_layer4) (0.623))) (min((layer3_leftspeed_fast_to_layer4) (0.157))))  [e4 ->] 1 | layer5_leftspeed242_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.003))) (min((layer3_leftspeed_quick_to_layer4) (0.598))) (min((layer3_leftspeed_fast_to_layer4) (0.181))))  [e4 ->] 1 | layer5_leftspeed243_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.574))) (min((layer3_leftspeed_fast_to_layer4) (0.207))))  [e4 ->] 1 | layer5_leftspeed244_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.55))) (min((layer3_leftspeed_fast_to_layer4) (0.236))))  [e4 ->] 1 | layer5_leftspeed245_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.526))) (min((layer3_leftspeed_fast_to_layer4) (0.267))))  [e4 ->] 1 | layer5_leftspeed246_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.002))) (min((layer3_leftspeed_quick_to_layer4) (0.502))) (min((layer3_leftspeed_fast_to_layer4) (0.301))))  [e4 ->] 1 | layer5_leftspeed247_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.479))) (min((layer3_leftspeed_fast_to_layer4) (0.337))))  [e4 ->] 1 | layer5_leftspeed248_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.456))) (min((layer3_leftspeed_fast_to_layer4) (0.375))))  [e4 ->] 1 | layer5_leftspeed249_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.433))) (min((layer3_leftspeed_fast_to_layer4) (0.416))))  [e4 ->] 1 | layer5_leftspeed250_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.411))) (min((layer3_leftspeed_fast_to_layer4) (0.458))))  [e4 ->] 1 | layer5_leftspeed251_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.389))) (min((layer3_leftspeed_fast_to_layer4) (0.501))))  [e4 ->] 1 | layer5_leftspeed252_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.368))) (min((layer3_leftspeed_fast_to_layer4) (0.546))))  [e4 ->] 1 | layer5_leftspeed253_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.001))) (min((layer3_leftspeed_quick_to_layer4) (0.348))) (min((layer3_leftspeed_fast_to_layer4) (0.591))))  [e4 ->] 1 | layer5_leftspeed254_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.328))) (min((layer3_leftspeed_fast_to_layer4) (0.637))))  [e4 ->] 1 | layer5_leftspeed255_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.309))) (min((layer3_leftspeed_fast_to_layer4) (0.682))))  [e4 ->] 1 | layer5_leftspeed256_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.29))) (min((layer3_leftspeed_fast_to_layer4) (0.726))))  [e4 ->] 1 | layer5_leftspeed257_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.272))) (min((layer3_leftspeed_fast_to_layer4) (0.769))))  [e4 ->] 1 | layer5_leftspeed258_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.255))) (min((layer3_leftspeed_fast_to_layer4) (0.81))))  [e4 ->] 1 | layer5_leftspeed259_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.238))) (min((layer3_leftspeed_fast_to_layer4) (0.848))))  [e4 ->] 1 | layer5_leftspeed260_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.223))) (min((layer3_leftspeed_fast_to_layer4) (0.882))))  [e4 ->] 1 | layer5_leftspeed261_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.208))) (min((layer3_leftspeed_fast_to_layer4) (0.914))))  [e4 ->] 1 | layer5_leftspeed262_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.193))) (min((layer3_leftspeed_fast_to_layer4) (0.941))))  [e4 ->] 1 | layer5_leftspeed263_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.18))) (min((layer3_leftspeed_fast_to_layer4) (0.963))))  [e4 ->] 1 | layer5_leftspeed264_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.167))) (min((layer3_leftspeed_fast_to_layer4) (0.98))))  [e4 ->] 1 | layer5_leftspeed265_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.154))) (min((layer3_leftspeed_fast_to_layer4) (0.992))))  [e4 ->] 1 | layer5_leftspeed266_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.143))) (min((layer3_leftspeed_fast_to_layer4) (0.999))))  [e4 ->] 1 | layer5_leftspeed267_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.132))) (min((layer3_leftspeed_fast_to_layer4) (1.0))))  [e4 ->] 1 | layer5_leftspeed268_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.121))) (min((layer3_leftspeed_fast_to_layer4) (0.995))))  [e4 ->] 1 | layer5_leftspeed269_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.112))) (min((layer3_leftspeed_fast_to_layer4) (0.985))))  [e4 ->] 1 | layer5_leftspeed270_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.103))) (min((layer3_leftspeed_fast_to_layer4) (0.969))))  [e4 ->] 1 | layer5_leftspeed271_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.094))) (min((layer3_leftspeed_fast_to_layer4) (0.949))))  [e4 ->] 1 | layer5_leftspeed272_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.086))) (min((layer3_leftspeed_fast_to_layer4) (0.923))))  [e4 ->] 1 | layer5_leftspeed273_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.079))) (min((layer3_leftspeed_fast_to_layer4) (0.893))))  [e4 ->] 1 | layer5_leftspeed274_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.072))) (min((layer3_leftspeed_fast_to_layer4) (0.86))))  [e4 ->] 1 | layer5_leftspeed275_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.066))) (min((layer3_leftspeed_fast_to_layer4) (0.823))))  [e4 ->] 1 | layer5_leftspeed276_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.06))) (min((layer3_leftspeed_fast_to_layer4) (0.783))))  [e4 ->] 1 | layer5_leftspeed277_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.054))) (min((layer3_leftspeed_fast_to_layer4) (0.741))))  [e4 ->] 1 | layer5_leftspeed278_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.049))) (min((layer3_leftspeed_fast_to_layer4) (0.697))))  [e4 ->] 1 | layer5_leftspeed279_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.045))) (min((layer3_leftspeed_fast_to_layer4) (0.652))))  [e4 ->] 1 | layer5_leftspeed280_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.04))) (min((layer3_leftspeed_fast_to_layer4) (0.607))))  [e4 ->] 1 | layer5_leftspeed281_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.036))) (min((layer3_leftspeed_fast_to_layer4) (0.561))))  [e4 ->] 1 | layer5_leftspeed282_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.033))) (min((layer3_leftspeed_fast_to_layer4) (0.516))))  [e4 ->] 1 | layer5_leftspeed283_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.03))) (min((layer3_leftspeed_fast_to_layer4) (0.472))))  [e4 ->] 1 | layer5_leftspeed284_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.027))) (min((layer3_leftspeed_fast_to_layer4) (0.43))))  [e4 ->] 1 | layer5_leftspeed285_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.024))) (min((layer3_leftspeed_fast_to_layer4) (0.389))))  [e4 ->] 1 | layer5_leftspeed286_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.021))) (min((layer3_leftspeed_fast_to_layer4) (0.35))))  [e4 ->] 1 | layer5_leftspeed287_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.019))) (min((layer3_leftspeed_fast_to_layer4) (0.313))))  [e4 ->] 1 | layer5_leftspeed288_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.017))) (min((layer3_leftspeed_fast_to_layer4) (0.278))))  [e4 ->] 1 | layer5_leftspeed289_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.015))) (min((layer3_leftspeed_fast_to_layer4) (0.246))))  [e4 ->] 1 | layer5_leftspeed290_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.014))) (min((layer3_leftspeed_fast_to_layer4) (0.216))))  [e4 ->] 1 | layer5_leftspeed291_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.012))) (min((layer3_leftspeed_fast_to_layer4) (0.189))))  [e4 ->] 1 | layer5_leftspeed292_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.011))) (min((layer3_leftspeed_fast_to_layer4) (0.164))))  [e4 ->] 1 | layer5_leftspeed293_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.009))) (min((layer3_leftspeed_fast_to_layer4) (0.142))))  [e4 ->] 1 | layer5_leftspeed294_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.008))) (min((layer3_leftspeed_fast_to_layer4) (0.122))))  [e4 ->] 1 | layer5_leftspeed295_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.007))) (min((layer3_leftspeed_fast_to_layer4) (0.105))))  [e4 ->] 1 | layer5_leftspeed296_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.007))) (min((layer3_leftspeed_fast_to_layer4) (0.089))))  [e4 ->] 1 | layer5_leftspeed297_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.006))) (min((layer3_leftspeed_fast_to_layer4) (0.075))))  [e4 ->] 1 | layer5_leftspeed298_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.005))) (min((layer3_leftspeed_fast_to_layer4) (0.063))))  [e4 ->] 1 | layer5_leftspeed299_to_layer6};
          pr = {f0 + f_max( (min((layer3_leftspeed_slow_to_layer4) (0.0))) (min((layer3_leftspeed_normal_to_layer4) (0.0))) (min((layer3_leftspeed_quick_to_layer4) (0.004))) (min((layer3_leftspeed_fast_to_layer4) (0.053))))  [e4 ->] 1 | layer5_leftspeed300_to_layer6};
       

		  var0 = (0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);	
		  
          E0  = (1);
	};
	layer5_rightspeed = {
		var = {f0,layer5_rightspeed1_to_layer6,layer5_rightspeed2_to_layer6,layer5_rightspeed3_to_layer6,layer5_rightspeed4_to_layer6,layer5_rightspeed5_to_layer6,layer5_rightspeed6_to_layer6,layer5_rightspeed7_to_layer6,layer5_rightspeed8_to_layer6,layer5_rightspeed9_to_layer6,layer5_rightspeed10_to_layer6,layer5_rightspeed11_to_layer6,layer5_rightspeed12_to_layer6,layer5_rightspeed13_to_layer6,layer5_rightspeed14_to_layer6,layer5_rightspeed15_to_layer6,layer5_rightspeed16_to_layer6,layer5_rightspeed17_to_layer6,layer5_rightspeed18_to_layer6,layer5_rightspeed19_to_layer6,layer5_rightspeed20_to_layer6,layer5_rightspeed21_to_layer6,layer5_rightspeed22_to_layer6,layer5_rightspeed23_to_layer6,layer5_rightspeed24_to_layer6,layer5_rightspeed25_to_layer6,layer5_rightspeed26_to_layer6,layer5_rightspeed27_to_layer6,layer5_rightspeed28_to_layer6,layer5_rightspeed29_to_layer6,layer5_rightspeed30_to_layer6,layer5_rightspeed31_to_layer6,layer5_rightspeed32_to_layer6,layer5_rightspeed33_to_layer6,layer5_rightspeed34_to_layer6,layer5_rightspeed35_to_layer6,layer5_rightspeed36_to_layer6,layer5_rightspeed37_to_layer6,layer5_rightspeed38_to_layer6,layer5_rightspeed39_to_layer6,layer5_rightspeed40_to_layer6,layer5_rightspeed41_to_layer6,layer5_rightspeed42_to_layer6,layer5_rightspeed43_to_layer6,layer5_rightspeed44_to_layer6,layer5_rightspeed45_to_layer6,layer5_rightspeed46_to_layer6,layer5_rightspeed47_to_layer6,layer5_rightspeed48_to_layer6,layer5_rightspeed49_to_layer6,layer5_rightspeed50_to_layer6,layer5_rightspeed51_to_layer6,layer5_rightspeed52_to_layer6,layer5_rightspeed53_to_layer6,layer5_rightspeed54_to_layer6,layer5_rightspeed55_to_layer6,layer5_rightspeed56_to_layer6,layer5_rightspeed57_to_layer6,layer5_rightspeed58_to_layer6,layer5_rightspeed59_to_layer6,layer5_rightspeed60_to_layer6,layer5_rightspeed61_to_layer6,layer5_rightspeed62_to_layer6,layer5_rightspeed63_to_layer6,layer5_rightspeed64_to_layer6,layer5_rightspeed65_to_layer6,layer5_rightspeed66_to_layer6,layer5_rightspeed67_to_layer6,layer5_rightspeed68_to_layer6,layer5_rightspeed69_to_layer6,layer5_rightspeed70_to_layer6,layer5_rightspeed71_to_layer6,layer5_rightspeed72_to_layer6,layer5_rightspeed73_to_layer6,layer5_rightspeed74_to_layer6,layer5_rightspeed75_to_layer6,layer5_rightspeed76_to_layer6,layer5_rightspeed77_to_layer6,layer5_rightspeed78_to_layer6,layer5_rightspeed79_to_layer6,layer5_rightspeed80_to_layer6,layer5_rightspeed81_to_layer6,layer5_rightspeed82_to_layer6,layer5_rightspeed83_to_layer6,layer5_rightspeed84_to_layer6,layer5_rightspeed85_to_layer6,layer5_rightspeed86_to_layer6,layer5_rightspeed87_to_layer6,layer5_rightspeed88_to_layer6,layer5_rightspeed89_to_layer6,layer5_rightspeed90_to_layer6,layer5_rightspeed91_to_layer6,layer5_rightspeed92_to_layer6,layer5_rightspeed93_to_layer6,layer5_rightspeed94_to_layer6,layer5_rightspeed95_to_layer6,layer5_rightspeed96_to_layer6,layer5_rightspeed97_to_layer6,layer5_rightspeed98_to_layer6,layer5_rightspeed99_to_layer6,layer5_rightspeed100_to_layer6,layer5_rightspeed101_to_layer6,layer5_rightspeed102_to_layer6,layer5_rightspeed103_to_layer6,layer5_rightspeed104_to_layer6,layer5_rightspeed105_to_layer6,layer5_rightspeed106_to_layer6,layer5_rightspeed107_to_layer6,layer5_rightspeed108_to_layer6,layer5_rightspeed109_to_layer6,layer5_rightspeed110_to_layer6,layer5_rightspeed111_to_layer6,layer5_rightspeed112_to_layer6,layer5_rightspeed113_to_layer6,layer5_rightspeed114_to_layer6,layer5_rightspeed115_to_layer6,layer5_rightspeed116_to_layer6,layer5_rightspeed117_to_layer6,layer5_rightspeed118_to_layer6,layer5_rightspeed119_to_layer6,layer5_rightspeed120_to_layer6,layer5_rightspeed121_to_layer6,layer5_rightspeed122_to_layer6,layer5_rightspeed123_to_layer6,layer5_rightspeed124_to_layer6,layer5_rightspeed125_to_layer6,layer5_rightspeed126_to_layer6,layer5_rightspeed127_to_layer6,layer5_rightspeed128_to_layer6,layer5_rightspeed129_to_layer6,layer5_rightspeed130_to_layer6,layer5_rightspeed131_to_layer6,layer5_rightspeed132_to_layer6,layer5_rightspeed133_to_layer6,layer5_rightspeed134_to_layer6,layer5_rightspeed135_to_layer6,layer5_rightspeed136_to_layer6,layer5_rightspeed137_to_layer6,layer5_rightspeed138_to_layer6,layer5_rightspeed139_to_layer6,layer5_rightspeed140_to_layer6,layer5_rightspeed141_to_layer6,layer5_rightspeed142_to_layer6,layer5_rightspeed143_to_layer6,layer5_rightspeed144_to_layer6,layer5_rightspeed145_to_layer6,layer5_rightspeed146_to_layer6,layer5_rightspeed147_to_layer6,layer5_rightspeed148_to_layer6,layer5_rightspeed149_to_layer6,layer5_rightspeed150_to_layer6,layer5_rightspeed151_to_layer6,layer5_rightspeed152_to_layer6,layer5_rightspeed153_to_layer6,layer5_rightspeed154_to_layer6,layer5_rightspeed155_to_layer6,layer5_rightspeed156_to_layer6,layer5_rightspeed157_to_layer6,layer5_rightspeed158_to_layer6,layer5_rightspeed159_to_layer6,layer5_rightspeed160_to_layer6,layer5_rightspeed161_to_layer6,layer5_rightspeed162_to_layer6,layer5_rightspeed163_to_layer6,layer5_rightspeed164_to_layer6,layer5_rightspeed165_to_layer6,layer5_rightspeed166_to_layer6,layer5_rightspeed167_to_layer6,layer5_rightspeed168_to_layer6,layer5_rightspeed169_to_layer6,layer5_rightspeed170_to_layer6,layer5_rightspeed171_to_layer6,layer5_rightspeed172_to_layer6,layer5_rightspeed173_to_layer6,layer5_rightspeed174_to_layer6,layer5_rightspeed175_to_layer6,layer5_rightspeed176_to_layer6,layer5_rightspeed177_to_layer6,layer5_rightspeed178_to_layer6,layer5_rightspeed179_to_layer6,layer5_rightspeed180_to_layer6,layer5_rightspeed181_to_layer6,layer5_rightspeed182_to_layer6,layer5_rightspeed183_to_layer6,layer5_rightspeed184_to_layer6,layer5_rightspeed185_to_layer6,layer5_rightspeed186_to_layer6,layer5_rightspeed187_to_layer6,layer5_rightspeed188_to_layer6,layer5_rightspeed189_to_layer6,layer5_rightspeed190_to_layer6,layer5_rightspeed191_to_layer6,layer5_rightspeed192_to_layer6,layer5_rightspeed193_to_layer6,layer5_rightspeed194_to_layer6,layer5_rightspeed195_to_layer6,layer5_rightspeed196_to_layer6,layer5_rightspeed197_to_layer6,layer5_rightspeed198_to_layer6,layer5_rightspeed199_to_layer6,layer5_rightspeed200_to_layer6,layer5_rightspeed201_to_layer6,layer5_rightspeed202_to_layer6,layer5_rightspeed203_to_layer6,layer5_rightspeed204_to_layer6,layer5_rightspeed205_to_layer6,layer5_rightspeed206_to_layer6,layer5_rightspeed207_to_layer6,layer5_rightspeed208_to_layer6,layer5_rightspeed209_to_layer6,layer5_rightspeed210_to_layer6,layer5_rightspeed211_to_layer6,layer5_rightspeed212_to_layer6,layer5_rightspeed213_to_layer6,layer5_rightspeed214_to_layer6,layer5_rightspeed215_to_layer6,layer5_rightspeed216_to_layer6,layer5_rightspeed217_to_layer6,layer5_rightspeed218_to_layer6,layer5_rightspeed219_to_layer6,layer5_rightspeed220_to_layer6,layer5_rightspeed221_to_layer6,layer5_rightspeed222_to_layer6,layer5_rightspeed223_to_layer6,layer5_rightspeed224_to_layer6,layer5_rightspeed225_to_layer6,layer5_rightspeed226_to_layer6,layer5_rightspeed227_to_layer6,layer5_rightspeed228_to_layer6,layer5_rightspeed229_to_layer6,layer5_rightspeed230_to_layer6,layer5_rightspeed231_to_layer6,layer5_rightspeed232_to_layer6,layer5_rightspeed233_to_layer6,layer5_rightspeed234_to_layer6,layer5_rightspeed235_to_layer6,layer5_rightspeed236_to_layer6,layer5_rightspeed237_to_layer6,layer5_rightspeed238_to_layer6,layer5_rightspeed239_to_layer6,layer5_rightspeed240_to_layer6,layer5_rightspeed241_to_layer6,layer5_rightspeed242_to_layer6,layer5_rightspeed243_to_layer6,layer5_rightspeed244_to_layer6,layer5_rightspeed245_to_layer6,layer5_rightspeed246_to_layer6,layer5_rightspeed247_to_layer6,layer5_rightspeed248_to_layer6,layer5_rightspeed249_to_layer6,layer5_rightspeed250_to_layer6,layer5_rightspeed251_to_layer6,layer5_rightspeed252_to_layer6,layer5_rightspeed253_to_layer6,layer5_rightspeed254_to_layer6,layer5_rightspeed255_to_layer6,layer5_rightspeed256_to_layer6,layer5_rightspeed257_to_layer6,layer5_rightspeed258_to_layer6,layer5_rightspeed259_to_layer6,layer5_rightspeed260_to_layer6,layer5_rightspeed261_to_layer6,layer5_rightspeed262_to_layer6,layer5_rightspeed263_to_layer6,layer5_rightspeed264_to_layer6,layer5_rightspeed265_to_layer6,layer5_rightspeed266_to_layer6,layer5_rightspeed267_to_layer6,layer5_rightspeed268_to_layer6,layer5_rightspeed269_to_layer6,layer5_rightspeed270_to_layer6,layer5_rightspeed271_to_layer6,layer5_rightspeed272_to_layer6,layer5_rightspeed273_to_layer6,layer5_rightspeed274_to_layer6,layer5_rightspeed275_to_layer6,layer5_rightspeed276_to_layer6,layer5_rightspeed277_to_layer6,layer5_rightspeed278_to_layer6,layer5_rightspeed279_to_layer6,layer5_rightspeed280_to_layer6,layer5_rightspeed281_to_layer6,layer5_rightspeed282_to_layer6,layer5_rightspeed283_to_layer6,layer5_rightspeed284_to_layer6,layer5_rightspeed285_to_layer6,layer5_rightspeed286_to_layer6,layer5_rightspeed287_to_layer6,layer5_rightspeed288_to_layer6,layer5_rightspeed289_to_layer6,layer5_rightspeed290_to_layer6,layer5_rightspeed291_to_layer6,layer5_rightspeed292_to_layer6,layer5_rightspeed293_to_layer6,layer5_rightspeed294_to_layer6,layer5_rightspeed295_to_layer6,layer5_rightspeed296_to_layer6,layer5_rightspeed297_to_layer6,layer5_rightspeed298_to_layer6,layer5_rightspeed299_to_layer6,layer5_rightspeed300_to_layer6};  
		
		E = {e4};
		pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.103))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed1_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.112))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed2_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.121))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed3_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.132))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed4_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.143))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed5_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.154))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed6_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.167))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.002))))  [e4 ->] 1 | layer5_rightspeed7_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.18))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.002))))  [e4 ->] 1 | layer5_rightspeed8_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.193))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.003))))  [e4 ->] 1 | layer5_rightspeed9_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.208))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.004))))  [e4 ->] 1 | layer5_rightspeed10_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.223))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.005))))  [e4 ->] 1 | layer5_rightspeed11_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.238))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.006))))  [e4 ->] 1 | layer5_rightspeed12_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.255))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.008))))  [e4 ->] 1 | layer5_rightspeed13_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.272))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.01))))  [e4 ->] 1 | layer5_rightspeed14_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.29))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.013))))  [e4 ->] 1 | layer5_rightspeed15_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.309))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.016))))  [e4 ->] 1 | layer5_rightspeed16_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.328))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.02))))  [e4 ->] 1 | layer5_rightspeed17_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.348))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.024))))  [e4 ->] 1 | layer5_rightspeed18_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.368))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.03))))  [e4 ->] 1 | layer5_rightspeed19_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.389))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.036))))  [e4 ->] 1 | layer5_rightspeed20_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.411))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.044))))  [e4 ->] 1 | layer5_rightspeed21_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.433))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.053))))  [e4 ->] 1 | layer5_rightspeed22_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.456))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.063))))  [e4 ->] 1 | layer5_rightspeed23_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.479))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.075))))  [e4 ->] 1 | layer5_rightspeed24_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.502))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.089))))  [e4 ->] 1 | layer5_rightspeed25_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.526))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.105))))  [e4 ->] 1 | layer5_rightspeed26_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.55))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.122))))  [e4 ->] 1 | layer5_rightspeed27_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.574))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.142))))  [e4 ->] 1 | layer5_rightspeed28_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.598))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.164))))  [e4 ->] 1 | layer5_rightspeed29_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.623))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.189))))  [e4 ->] 1 | layer5_rightspeed30_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.647))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.216))))  [e4 ->] 1 | layer5_rightspeed31_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.671))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.246))))  [e4 ->] 1 | layer5_rightspeed32_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.695))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.278))))  [e4 ->] 1 | layer5_rightspeed33_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.718))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.313))))  [e4 ->] 1 | layer5_rightspeed34_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.742))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.35))))  [e4 ->] 1 | layer5_rightspeed35_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.764))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.389))))  [e4 ->] 1 | layer5_rightspeed36_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.786))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.43))))  [e4 ->] 1 | layer5_rightspeed37_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.808))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.472))))  [e4 ->] 1 | layer5_rightspeed38_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.829))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.516))))  [e4 ->] 1 | layer5_rightspeed39_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.848))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.561))))  [e4 ->] 1 | layer5_rightspeed40_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.867))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.607))))  [e4 ->] 1 | layer5_rightspeed41_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.885))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.652))))  [e4 ->] 1 | layer5_rightspeed42_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.902))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.697))))  [e4 ->] 1 | layer5_rightspeed43_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.918))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.741))))  [e4 ->] 1 | layer5_rightspeed44_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.933))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.783))))  [e4 ->] 1 | layer5_rightspeed45_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.946))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.823))))  [e4 ->] 1 | layer5_rightspeed46_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.958))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.86))))  [e4 ->] 1 | layer5_rightspeed47_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.968))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.893))))  [e4 ->] 1 | layer5_rightspeed48_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.978))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.923))))  [e4 ->] 1 | layer5_rightspeed49_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.985))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.949))))  [e4 ->] 1 | layer5_rightspeed50_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.991))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.969))))  [e4 ->] 1 | layer5_rightspeed51_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.996))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.985))))  [e4 ->] 1 | layer5_rightspeed52_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.999))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.995))))  [e4 ->] 1 | layer5_rightspeed53_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (1.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (1.0))))  [e4 ->] 1 | layer5_rightspeed54_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (1.0))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.999))))  [e4 ->] 1 | layer5_rightspeed55_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.998))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.992))))  [e4 ->] 1 | layer5_rightspeed56_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.994))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.98))))  [e4 ->] 1 | layer5_rightspeed57_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.989))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.963))))  [e4 ->] 1 | layer5_rightspeed58_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.983))) (min((layer3_rightspeed_normal_to_layer4) (0.003))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.941))))  [e4 ->] 1 | layer5_rightspeed59_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.975))) (min((layer3_rightspeed_normal_to_layer4) (0.003))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.914))))  [e4 ->] 1 | layer5_rightspeed60_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.965))) (min((layer3_rightspeed_normal_to_layer4) (0.003))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.882))))  [e4 ->] 1 | layer5_rightspeed61_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.954))) (min((layer3_rightspeed_normal_to_layer4) (0.004))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.848))))  [e4 ->] 1 | layer5_rightspeed62_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.942))) (min((layer3_rightspeed_normal_to_layer4) (0.004))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.81))))  [e4 ->] 1 | layer5_rightspeed63_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.928))) (min((layer3_rightspeed_normal_to_layer4) (0.005))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.769))))  [e4 ->] 1 | layer5_rightspeed64_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.913))) (min((layer3_rightspeed_normal_to_layer4) (0.006))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.726))))  [e4 ->] 1 | layer5_rightspeed65_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.897))) (min((layer3_rightspeed_normal_to_layer4) (0.006))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.682))))  [e4 ->] 1 | layer5_rightspeed66_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.88))) (min((layer3_rightspeed_normal_to_layer4) (0.007))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.637))))  [e4 ->] 1 | layer5_rightspeed67_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.861))) (min((layer3_rightspeed_normal_to_layer4) (0.008))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.591))))  [e4 ->] 1 | layer5_rightspeed68_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.842))) (min((layer3_rightspeed_normal_to_layer4) (0.009))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.546))))  [e4 ->] 1 | layer5_rightspeed69_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.822))) (min((layer3_rightspeed_normal_to_layer4) (0.01))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.501))))  [e4 ->] 1 | layer5_rightspeed70_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.801))) (min((layer3_rightspeed_normal_to_layer4) (0.011))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.458))))  [e4 ->] 1 | layer5_rightspeed71_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.779))) (min((layer3_rightspeed_normal_to_layer4) (0.012))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.416))))  [e4 ->] 1 | layer5_rightspeed72_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.757))) (min((layer3_rightspeed_normal_to_layer4) (0.014))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.375))))  [e4 ->] 1 | layer5_rightspeed73_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.734))) (min((layer3_rightspeed_normal_to_layer4) (0.015))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.337))))  [e4 ->] 1 | layer5_rightspeed74_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.711))) (min((layer3_rightspeed_normal_to_layer4) (0.017))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.301))))  [e4 ->] 1 | layer5_rightspeed75_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.687))) (min((layer3_rightspeed_normal_to_layer4) (0.019))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.267))))  [e4 ->] 1 | layer5_rightspeed76_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.663))) (min((layer3_rightspeed_normal_to_layer4) (0.021))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.236))))  [e4 ->] 1 | layer5_rightspeed77_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.639))) (min((layer3_rightspeed_normal_to_layer4) (0.024))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.207))))  [e4 ->] 1 | layer5_rightspeed78_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.615))) (min((layer3_rightspeed_normal_to_layer4) (0.026))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.181))))  [e4 ->] 1 | layer5_rightspeed79_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.59))) (min((layer3_rightspeed_normal_to_layer4) (0.029))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.157))))  [e4 ->] 1 | layer5_rightspeed80_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.566))) (min((layer3_rightspeed_normal_to_layer4) (0.032))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.135))))  [e4 ->] 1 | layer5_rightspeed81_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.542))) (min((layer3_rightspeed_normal_to_layer4) (0.035))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.116))))  [e4 ->] 1 | layer5_rightspeed82_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.518))) (min((layer3_rightspeed_normal_to_layer4) (0.039))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.099))))  [e4 ->] 1 | layer5_rightspeed83_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.495))) (min((layer3_rightspeed_normal_to_layer4) (0.043))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.084))))  [e4 ->] 1 | layer5_rightspeed84_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.471))) (min((layer3_rightspeed_normal_to_layer4) (0.047))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.071))))  [e4 ->] 1 | layer5_rightspeed85_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.448))) (min((layer3_rightspeed_normal_to_layer4) (0.051))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.06))))  [e4 ->] 1 | layer5_rightspeed86_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.426))) (min((layer3_rightspeed_normal_to_layer4) (0.056))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.05))))  [e4 ->] 1 | layer5_rightspeed87_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.404))) (min((layer3_rightspeed_normal_to_layer4) (0.061))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.041))))  [e4 ->] 1 | layer5_rightspeed88_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.382))) (min((layer3_rightspeed_normal_to_layer4) (0.067))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.034))))  [e4 ->] 1 | layer5_rightspeed89_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.361))) (min((layer3_rightspeed_normal_to_layer4) (0.073))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.028))))  [e4 ->] 1 | layer5_rightspeed90_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.341))) (min((layer3_rightspeed_normal_to_layer4) (0.08))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.023))))  [e4 ->] 1 | layer5_rightspeed91_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.321))) (min((layer3_rightspeed_normal_to_layer4) (0.087))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.018))))  [e4 ->] 1 | layer5_rightspeed92_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.302))) (min((layer3_rightspeed_normal_to_layer4) (0.094))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.015))))  [e4 ->] 1 | layer5_rightspeed93_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.284))) (min((layer3_rightspeed_normal_to_layer4) (0.102))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.012))))  [e4 ->] 1 | layer5_rightspeed94_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.266))) (min((layer3_rightspeed_normal_to_layer4) (0.11))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.01))))  [e4 ->] 1 | layer5_rightspeed95_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.249))) (min((layer3_rightspeed_normal_to_layer4) (0.119))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.008))))  [e4 ->] 1 | layer5_rightspeed96_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.233))) (min((layer3_rightspeed_normal_to_layer4) (0.129))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.006))))  [e4 ->] 1 | layer5_rightspeed97_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.218))) (min((layer3_rightspeed_normal_to_layer4) (0.139))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.005))))  [e4 ->] 1 | layer5_rightspeed98_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.203))) (min((layer3_rightspeed_normal_to_layer4) (0.149))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.004))))  [e4 ->] 1 | layer5_rightspeed99_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.189))) (min((layer3_rightspeed_normal_to_layer4) (0.161))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.003))))  [e4 ->] 1 | layer5_rightspeed100_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.175))) (min((layer3_rightspeed_normal_to_layer4) (0.172))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.002))))  [e4 ->] 1 | layer5_rightspeed101_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.162))) (min((layer3_rightspeed_normal_to_layer4) (0.185))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.002))))  [e4 ->] 1 | layer5_rightspeed102_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.15))) (min((layer3_rightspeed_normal_to_layer4) (0.198))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed103_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.139))) (min((layer3_rightspeed_normal_to_layer4) (0.212))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed104_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.128))) (min((layer3_rightspeed_normal_to_layer4) (0.226))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed105_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.118))) (min((layer3_rightspeed_normal_to_layer4) (0.241))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.001))))  [e4 ->] 1 | layer5_rightspeed106_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.109))) (min((layer3_rightspeed_normal_to_layer4) (0.256))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed107_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.1))) (min((layer3_rightspeed_normal_to_layer4) (0.273))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed108_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.092))) (min((layer3_rightspeed_normal_to_layer4) (0.289))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed109_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.084))) (min((layer3_rightspeed_normal_to_layer4) (0.307))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed110_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.077))) (min((layer3_rightspeed_normal_to_layer4) (0.325))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed111_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.07))) (min((layer3_rightspeed_normal_to_layer4) (0.343))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed112_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.064))) (min((layer3_rightspeed_normal_to_layer4) (0.362))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed113_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.058))) (min((layer3_rightspeed_normal_to_layer4) (0.382))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed114_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.053))) (min((layer3_rightspeed_normal_to_layer4) (0.402))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed115_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.048))) (min((layer3_rightspeed_normal_to_layer4) (0.423))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed116_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.043))) (min((layer3_rightspeed_normal_to_layer4) (0.444))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed117_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.039))) (min((layer3_rightspeed_normal_to_layer4) (0.465))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed118_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.035))) (min((layer3_rightspeed_normal_to_layer4) (0.487))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed119_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.032))) (min((layer3_rightspeed_normal_to_layer4) (0.509))) (min((layer3_rightspeed_quick_to_layer4) (0.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed120_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.029))) (min((layer3_rightspeed_normal_to_layer4) (0.531))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed121_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.026))) (min((layer3_rightspeed_normal_to_layer4) (0.554))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed122_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.023))) (min((layer3_rightspeed_normal_to_layer4) (0.576))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed123_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.021))) (min((layer3_rightspeed_normal_to_layer4) (0.599))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed124_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.018))) (min((layer3_rightspeed_normal_to_layer4) (0.622))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed125_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.016))) (min((layer3_rightspeed_normal_to_layer4) (0.644))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed126_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.015))) (min((layer3_rightspeed_normal_to_layer4) (0.667))) (min((layer3_rightspeed_quick_to_layer4) (0.001))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed127_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.013))) (min((layer3_rightspeed_normal_to_layer4) (0.689))) (min((layer3_rightspeed_quick_to_layer4) (0.002))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed128_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.012))) (min((layer3_rightspeed_normal_to_layer4) (0.712))) (min((layer3_rightspeed_quick_to_layer4) (0.002))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed129_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.01))) (min((layer3_rightspeed_normal_to_layer4) (0.733))) (min((layer3_rightspeed_quick_to_layer4) (0.002))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed130_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.009))) (min((layer3_rightspeed_normal_to_layer4) (0.755))) (min((layer3_rightspeed_quick_to_layer4) (0.002))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed131_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.008))) (min((layer3_rightspeed_normal_to_layer4) (0.776))) (min((layer3_rightspeed_quick_to_layer4) (0.003))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed132_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.007))) (min((layer3_rightspeed_normal_to_layer4) (0.796))) (min((layer3_rightspeed_quick_to_layer4) (0.003))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed133_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.006))) (min((layer3_rightspeed_normal_to_layer4) (0.816))) (min((layer3_rightspeed_quick_to_layer4) (0.004))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed134_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.005))) (min((layer3_rightspeed_normal_to_layer4) (0.835))) (min((layer3_rightspeed_quick_to_layer4) (0.004))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed135_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.005))) (min((layer3_rightspeed_normal_to_layer4) (0.854))) (min((layer3_rightspeed_quick_to_layer4) (0.005))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed136_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.004))) (min((layer3_rightspeed_normal_to_layer4) (0.871))) (min((layer3_rightspeed_quick_to_layer4) (0.005))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed137_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.004))) (min((layer3_rightspeed_normal_to_layer4) (0.888))) (min((layer3_rightspeed_quick_to_layer4) (0.006))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed138_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.003))) (min((layer3_rightspeed_normal_to_layer4) (0.904))) (min((layer3_rightspeed_quick_to_layer4) (0.007))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed139_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.003))) (min((layer3_rightspeed_normal_to_layer4) (0.918))) (min((layer3_rightspeed_quick_to_layer4) (0.008))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed140_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.002))) (min((layer3_rightspeed_normal_to_layer4) (0.932))) (min((layer3_rightspeed_quick_to_layer4) (0.009))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed141_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.002))) (min((layer3_rightspeed_normal_to_layer4) (0.945))) (min((layer3_rightspeed_quick_to_layer4) (0.01))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed142_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.002))) (min((layer3_rightspeed_normal_to_layer4) (0.956))) (min((layer3_rightspeed_quick_to_layer4) (0.012))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed143_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.002))) (min((layer3_rightspeed_normal_to_layer4) (0.966))) (min((layer3_rightspeed_quick_to_layer4) (0.013))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed144_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (0.975))) (min((layer3_rightspeed_quick_to_layer4) (0.015))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed145_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (0.983))) (min((layer3_rightspeed_quick_to_layer4) (0.016))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed146_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (0.989))) (min((layer3_rightspeed_quick_to_layer4) (0.018))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed147_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (0.994))) (min((layer3_rightspeed_quick_to_layer4) (0.021))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed148_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (0.997))) (min((layer3_rightspeed_quick_to_layer4) (0.023))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed149_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (0.999))) (min((layer3_rightspeed_quick_to_layer4) (0.026))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed150_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.001))) (min((layer3_rightspeed_normal_to_layer4) (1.0))) (min((layer3_rightspeed_quick_to_layer4) (0.029))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed151_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.999))) (min((layer3_rightspeed_quick_to_layer4) (0.032))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed152_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.997))) (min((layer3_rightspeed_quick_to_layer4) (0.035))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed153_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.994))) (min((layer3_rightspeed_quick_to_layer4) (0.039))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed154_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.989))) (min((layer3_rightspeed_quick_to_layer4) (0.043))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed155_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.983))) (min((layer3_rightspeed_quick_to_layer4) (0.048))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed156_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.975))) (min((layer3_rightspeed_quick_to_layer4) (0.053))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed157_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.966))) (min((layer3_rightspeed_quick_to_layer4) (0.058))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed158_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.956))) (min((layer3_rightspeed_quick_to_layer4) (0.064))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed159_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.945))) (min((layer3_rightspeed_quick_to_layer4) (0.07))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed160_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.932))) (min((layer3_rightspeed_quick_to_layer4) (0.077))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed161_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.918))) (min((layer3_rightspeed_quick_to_layer4) (0.084))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed162_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.904))) (min((layer3_rightspeed_quick_to_layer4) (0.092))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed163_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.888))) (min((layer3_rightspeed_quick_to_layer4) (0.1))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed164_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.871))) (min((layer3_rightspeed_quick_to_layer4) (0.109))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed165_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.854))) (min((layer3_rightspeed_quick_to_layer4) (0.118))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed166_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.835))) (min((layer3_rightspeed_quick_to_layer4) (0.128))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed167_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.816))) (min((layer3_rightspeed_quick_to_layer4) (0.139))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed168_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.796))) (min((layer3_rightspeed_quick_to_layer4) (0.15))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed169_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.776))) (min((layer3_rightspeed_quick_to_layer4) (0.162))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed170_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.755))) (min((layer3_rightspeed_quick_to_layer4) (0.175))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed171_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.733))) (min((layer3_rightspeed_quick_to_layer4) (0.189))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed172_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.712))) (min((layer3_rightspeed_quick_to_layer4) (0.203))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed173_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.689))) (min((layer3_rightspeed_quick_to_layer4) (0.218))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed174_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.667))) (min((layer3_rightspeed_quick_to_layer4) (0.233))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed175_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.644))) (min((layer3_rightspeed_quick_to_layer4) (0.249))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed176_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.622))) (min((layer3_rightspeed_quick_to_layer4) (0.266))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed177_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.599))) (min((layer3_rightspeed_quick_to_layer4) (0.284))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed178_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.576))) (min((layer3_rightspeed_quick_to_layer4) (0.302))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed179_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.554))) (min((layer3_rightspeed_quick_to_layer4) (0.321))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed180_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.531))) (min((layer3_rightspeed_quick_to_layer4) (0.341))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed181_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.509))) (min((layer3_rightspeed_quick_to_layer4) (0.361))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed182_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.487))) (min((layer3_rightspeed_quick_to_layer4) (0.382))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed183_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.465))) (min((layer3_rightspeed_quick_to_layer4) (0.404))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed184_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.444))) (min((layer3_rightspeed_quick_to_layer4) (0.426))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed185_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.423))) (min((layer3_rightspeed_quick_to_layer4) (0.448))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed186_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.402))) (min((layer3_rightspeed_quick_to_layer4) (0.471))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed187_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.382))) (min((layer3_rightspeed_quick_to_layer4) (0.495))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed188_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.362))) (min((layer3_rightspeed_quick_to_layer4) (0.518))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed189_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.343))) (min((layer3_rightspeed_quick_to_layer4) (0.542))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed190_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.325))) (min((layer3_rightspeed_quick_to_layer4) (0.566))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed191_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.307))) (min((layer3_rightspeed_quick_to_layer4) (0.59))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed192_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.289))) (min((layer3_rightspeed_quick_to_layer4) (0.615))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed193_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.273))) (min((layer3_rightspeed_quick_to_layer4) (0.639))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed194_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.256))) (min((layer3_rightspeed_quick_to_layer4) (0.663))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed195_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.241))) (min((layer3_rightspeed_quick_to_layer4) (0.687))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed196_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.226))) (min((layer3_rightspeed_quick_to_layer4) (0.711))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed197_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.212))) (min((layer3_rightspeed_quick_to_layer4) (0.734))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed198_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.198))) (min((layer3_rightspeed_quick_to_layer4) (0.757))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed199_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.185))) (min((layer3_rightspeed_quick_to_layer4) (0.779))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed200_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.172))) (min((layer3_rightspeed_quick_to_layer4) (0.801))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed201_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.161))) (min((layer3_rightspeed_quick_to_layer4) (0.822))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed202_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.149))) (min((layer3_rightspeed_quick_to_layer4) (0.842))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed203_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.139))) (min((layer3_rightspeed_quick_to_layer4) (0.861))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed204_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.129))) (min((layer3_rightspeed_quick_to_layer4) (0.88))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed205_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.119))) (min((layer3_rightspeed_quick_to_layer4) (0.897))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed206_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.11))) (min((layer3_rightspeed_quick_to_layer4) (0.913))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed207_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.102))) (min((layer3_rightspeed_quick_to_layer4) (0.928))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed208_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.094))) (min((layer3_rightspeed_quick_to_layer4) (0.942))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed209_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.087))) (min((layer3_rightspeed_quick_to_layer4) (0.954))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed210_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.08))) (min((layer3_rightspeed_quick_to_layer4) (0.965))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed211_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.073))) (min((layer3_rightspeed_quick_to_layer4) (0.975))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed212_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.067))) (min((layer3_rightspeed_quick_to_layer4) (0.983))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed213_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.061))) (min((layer3_rightspeed_quick_to_layer4) (0.989))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed214_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.056))) (min((layer3_rightspeed_quick_to_layer4) (0.994))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed215_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.051))) (min((layer3_rightspeed_quick_to_layer4) (0.998))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed216_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.047))) (min((layer3_rightspeed_quick_to_layer4) (1.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed217_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.043))) (min((layer3_rightspeed_quick_to_layer4) (1.0))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed218_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.039))) (min((layer3_rightspeed_quick_to_layer4) (0.999))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed219_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.035))) (min((layer3_rightspeed_quick_to_layer4) (0.996))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed220_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.032))) (min((layer3_rightspeed_quick_to_layer4) (0.991))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed221_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.029))) (min((layer3_rightspeed_quick_to_layer4) (0.985))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed222_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.026))) (min((layer3_rightspeed_quick_to_layer4) (0.978))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed223_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.024))) (min((layer3_rightspeed_quick_to_layer4) (0.968))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed224_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.021))) (min((layer3_rightspeed_quick_to_layer4) (0.958))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed225_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.019))) (min((layer3_rightspeed_quick_to_layer4) (0.946))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed226_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.017))) (min((layer3_rightspeed_quick_to_layer4) (0.933))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed227_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.015))) (min((layer3_rightspeed_quick_to_layer4) (0.918))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed228_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.014))) (min((layer3_rightspeed_quick_to_layer4) (0.902))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed229_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.012))) (min((layer3_rightspeed_quick_to_layer4) (0.885))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed230_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.011))) (min((layer3_rightspeed_quick_to_layer4) (0.867))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed231_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.01))) (min((layer3_rightspeed_quick_to_layer4) (0.848))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed232_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.009))) (min((layer3_rightspeed_quick_to_layer4) (0.829))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed233_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.008))) (min((layer3_rightspeed_quick_to_layer4) (0.808))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed234_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.007))) (min((layer3_rightspeed_quick_to_layer4) (0.786))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed235_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.006))) (min((layer3_rightspeed_quick_to_layer4) (0.764))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed236_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.006))) (min((layer3_rightspeed_quick_to_layer4) (0.742))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed237_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.005))) (min((layer3_rightspeed_quick_to_layer4) (0.718))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed238_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.004))) (min((layer3_rightspeed_quick_to_layer4) (0.695))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed239_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.004))) (min((layer3_rightspeed_quick_to_layer4) (0.671))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed240_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.003))) (min((layer3_rightspeed_quick_to_layer4) (0.647))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed241_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.003))) (min((layer3_rightspeed_quick_to_layer4) (0.623))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed242_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.003))) (min((layer3_rightspeed_quick_to_layer4) (0.598))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed243_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.574))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed244_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.55))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed245_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.526))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed246_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.002))) (min((layer3_rightspeed_quick_to_layer4) (0.502))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed247_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.479))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed248_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.456))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed249_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.433))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed250_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.411))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed251_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.389))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed252_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.368))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed253_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.001))) (min((layer3_rightspeed_quick_to_layer4) (0.348))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed254_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.328))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed255_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.309))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed256_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.29))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed257_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.272))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed258_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.255))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed259_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.238))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed260_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.223))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed261_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.208))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed262_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.193))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed263_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.18))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed264_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.167))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed265_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.154))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed266_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.143))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed267_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.132))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed268_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.121))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed269_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.112))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed270_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.103))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed271_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.094))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed272_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.086))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed273_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.079))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed274_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.072))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed275_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.066))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed276_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.06))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed277_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.054))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed278_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.049))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed279_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.045))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed280_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.04))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed281_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.036))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed282_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.033))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed283_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.03))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed284_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.027))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed285_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.024))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed286_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.021))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed287_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.019))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed288_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.017))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed289_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.015))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed290_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.014))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed291_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.012))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed292_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.011))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed293_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.009))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed294_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.008))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed295_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.007))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed296_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.007))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed297_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.006))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed298_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.005))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed299_to_layer6};
          pr = {f0 + f_max( (min((layer3_rightspeed_slow_to_layer4) (0.0))) (min((layer3_rightspeed_normal_to_layer4) (0.0))) (min((layer3_rightspeed_quick_to_layer4) (0.004))) (min((layer3_rightspeed_fast_to_layer4) (0.0))))  [e4 ->] 1 | layer5_rightspeed300_to_layer6};
         
		  var0 = (0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);	
		  
          E0  = (1);
	};
	#layer6 ################
	layer6_leftspeed =  {
       var ={f0,calculate_leftspeed};
		E = {e5};
        pr = {((layer5_leftspeed1_to_layer6 * (0-100)+layer5_leftspeed2_to_layer6 * (0-97)+layer5_leftspeed3_to_layer6 * (0-94)+layer5_leftspeed4_to_layer6 * (0-91)+layer5_leftspeed5_to_layer6 * (0-88)+layer5_leftspeed6_to_layer6 * (0-85)+layer5_leftspeed7_to_layer6 * (0-82)+layer5_leftspeed8_to_layer6 * (0-79)+layer5_leftspeed9_to_layer6 * (0-76)+layer5_leftspeed10_to_layer6 * (0-73)+layer5_leftspeed11_to_layer6 * (0-70)+layer5_leftspeed12_to_layer6 * (0-67)+layer5_leftspeed13_to_layer6 * (0-64)+layer5_leftspeed14_to_layer6 * (0-61)+layer5_leftspeed15_to_layer6 * (0-58)+layer5_leftspeed16_to_layer6 * (0-55)+layer5_leftspeed17_to_layer6 * (0-52)+layer5_leftspeed18_to_layer6 * (0-49)+layer5_leftspeed19_to_layer6 * (0-46)+layer5_leftspeed20_to_layer6 * (0-43)+layer5_leftspeed21_to_layer6 * (0-40)+layer5_leftspeed22_to_layer6 * (0-37)+layer5_leftspeed23_to_layer6 * (0-34)+layer5_leftspeed24_to_layer6 * (0-31)+layer5_leftspeed25_to_layer6 * (0-28)+layer5_leftspeed26_to_layer6 * (0-25)+layer5_leftspeed27_to_layer6 * (0-22)+layer5_leftspeed28_to_layer6 * (0-19)+layer5_leftspeed29_to_layer6 * (0-16)+layer5_leftspeed30_to_layer6 * (0-13)+layer5_leftspeed31_to_layer6 * (0-10)+layer5_leftspeed32_to_layer6 * (0-7)+layer5_leftspeed33_to_layer6 * (0-4)+layer5_leftspeed34_to_layer6 * (0-1)+layer5_leftspeed35_to_layer6 * (02)+layer5_leftspeed36_to_layer6 * (05)+layer5_leftspeed37_to_layer6 * (08)+layer5_leftspeed38_to_layer6 * (011)+layer5_leftspeed39_to_layer6 * (014)+layer5_leftspeed40_to_layer6 * (017)+layer5_leftspeed41_to_layer6 * (020)+layer5_leftspeed42_to_layer6 * (023)+layer5_leftspeed43_to_layer6 * (026)+layer5_leftspeed44_to_layer6 * (029)+layer5_leftspeed45_to_layer6 * (032)+layer5_leftspeed46_to_layer6 * (035)+layer5_leftspeed47_to_layer6 * (038)+layer5_leftspeed48_to_layer6 * (041)+layer5_leftspeed49_to_layer6 * (044)+layer5_leftspeed50_to_layer6 * (47)+layer5_leftspeed51_to_layer6 * (50)+layer5_leftspeed52_to_layer6 * (53)+layer5_leftspeed53_to_layer6 * (56)+layer5_leftspeed54_to_layer6 * (59)+layer5_leftspeed55_to_layer6 * (62)+layer5_leftspeed56_to_layer6 * (65)+layer5_leftspeed57_to_layer6 * (68)+layer5_leftspeed58_to_layer6 * (71)+layer5_leftspeed59_to_layer6 * (74)+layer5_leftspeed60_to_layer6 * (77)+layer5_leftspeed61_to_layer6 * (80)+layer5_leftspeed62_to_layer6 * (83)+layer5_leftspeed63_to_layer6 * (86)+layer5_leftspeed64_to_layer6 * (89)+layer5_leftspeed65_to_layer6 * (92)+layer5_leftspeed66_to_layer6 * (95)+layer5_leftspeed67_to_layer6 * (98)+layer5_leftspeed68_to_layer6 * (101)+layer5_leftspeed69_to_layer6 * (104)+layer5_leftspeed70_to_layer6 * (107)+layer5_leftspeed71_to_layer6 * (110)+layer5_leftspeed72_to_layer6 * (113)+layer5_leftspeed73_to_layer6 * (116)+layer5_leftspeed74_to_layer6 * (119)+layer5_leftspeed75_to_layer6 * (122)+layer5_leftspeed76_to_layer6 * (125)+layer5_leftspeed77_to_layer6 * (128)+layer5_leftspeed78_to_layer6 * (131)+layer5_leftspeed79_to_layer6 * (134)+layer5_leftspeed80_to_layer6 * (137)+layer5_leftspeed81_to_layer6 * (140)+layer5_leftspeed82_to_layer6 * (143)+layer5_leftspeed83_to_layer6 * (146)+layer5_leftspeed84_to_layer6 * (149)+layer5_leftspeed85_to_layer6 * (152)+layer5_leftspeed86_to_layer6 * (155)+layer5_leftspeed87_to_layer6 * (158)+layer5_leftspeed88_to_layer6 * (161)+layer5_leftspeed89_to_layer6 * (164)+layer5_leftspeed90_to_layer6 * (167)+layer5_leftspeed91_to_layer6 * (170)+layer5_leftspeed92_to_layer6 * (173)+layer5_leftspeed93_to_layer6 * (176)+layer5_leftspeed94_to_layer6 * (179)+layer5_leftspeed95_to_layer6 * (182)+layer5_leftspeed96_to_layer6 * (185)+layer5_leftspeed97_to_layer6 * (188)+layer5_leftspeed98_to_layer6 * (191)+layer5_leftspeed99_to_layer6 * (194)+layer5_leftspeed100_to_layer6 * (197)+layer5_leftspeed101_to_layer6 * (200)+layer5_leftspeed102_to_layer6 * (203)+layer5_leftspeed103_to_layer6 * (206)+layer5_leftspeed104_to_layer6 * (209)+layer5_leftspeed105_to_layer6 * (212)+layer5_leftspeed106_to_layer6 * (215)+layer5_leftspeed107_to_layer6 * (218)+layer5_leftspeed108_to_layer6 * (221)+layer5_leftspeed109_to_layer6 * (224)+layer5_leftspeed110_to_layer6 * (227)+layer5_leftspeed111_to_layer6 * (230)+layer5_leftspeed112_to_layer6 * (233)+layer5_leftspeed113_to_layer6 * (236)+layer5_leftspeed114_to_layer6 * (239)+layer5_leftspeed115_to_layer6 * (242)+layer5_leftspeed116_to_layer6 * (245)+layer5_leftspeed117_to_layer6 * (248)+layer5_leftspeed118_to_layer6 * (251)+layer5_leftspeed119_to_layer6 * (254)+layer5_leftspeed120_to_layer6 * (257)+layer5_leftspeed121_to_layer6 * (260)+layer5_leftspeed122_to_layer6 * (263)+layer5_leftspeed123_to_layer6 * (266)+layer5_leftspeed124_to_layer6 * (269)+layer5_leftspeed125_to_layer6 * (272)+layer5_leftspeed126_to_layer6 * (275)+layer5_leftspeed127_to_layer6 * (278)+layer5_leftspeed128_to_layer6 * (281)+layer5_leftspeed129_to_layer6 * (284)+layer5_leftspeed130_to_layer6 * (287)+layer5_leftspeed131_to_layer6 * (290)+layer5_leftspeed132_to_layer6 * (293)+layer5_leftspeed133_to_layer6 * (296)+layer5_leftspeed134_to_layer6 * (299)+layer5_leftspeed135_to_layer6 * (302)+layer5_leftspeed136_to_layer6 * (305)+layer5_leftspeed137_to_layer6 * (308)+layer5_leftspeed138_to_layer6 * (311)+layer5_leftspeed139_to_layer6 * (314)+layer5_leftspeed140_to_layer6 * (317)+layer5_leftspeed141_to_layer6 * (320)+layer5_leftspeed142_to_layer6 * (323)+layer5_leftspeed143_to_layer6 * (326)+layer5_leftspeed144_to_layer6 * (329)+layer5_leftspeed145_to_layer6 * (332)+layer5_leftspeed146_to_layer6 * (335)+layer5_leftspeed147_to_layer6 * (338)+layer5_leftspeed148_to_layer6 * (341)+layer5_leftspeed149_to_layer6 * (344)+layer5_leftspeed150_to_layer6 * (347)+layer5_leftspeed151_to_layer6 * (350)+layer5_leftspeed152_to_layer6 * (353)+layer5_leftspeed153_to_layer6 * (356)+layer5_leftspeed154_to_layer6 * (359)+layer5_leftspeed155_to_layer6 * (362)+layer5_leftspeed156_to_layer6 * (365)+layer5_leftspeed157_to_layer6 * (368)+layer5_leftspeed158_to_layer6 * (371)+layer5_leftspeed159_to_layer6 * (374)+layer5_leftspeed160_to_layer6 * (377)+layer5_leftspeed161_to_layer6 * (380)+layer5_leftspeed162_to_layer6 * (383)+layer5_leftspeed163_to_layer6 * (386)+layer5_leftspeed164_to_layer6 * (389)+layer5_leftspeed165_to_layer6 * (392)+layer5_leftspeed166_to_layer6 * (395)+layer5_leftspeed167_to_layer6 * (398)+layer5_leftspeed168_to_layer6 * (401)+layer5_leftspeed169_to_layer6 * (404)+layer5_leftspeed170_to_layer6 * (407)+layer5_leftspeed171_to_layer6 * (410)+layer5_leftspeed172_to_layer6 * (413)+layer5_leftspeed173_to_layer6 * (416)+layer5_leftspeed174_to_layer6 * (419)+layer5_leftspeed175_to_layer6 * (422)+layer5_leftspeed176_to_layer6 * (425)+layer5_leftspeed177_to_layer6 * (428)+layer5_leftspeed178_to_layer6 * (431)+layer5_leftspeed179_to_layer6 * (434)+layer5_leftspeed180_to_layer6 * (437)+layer5_leftspeed181_to_layer6 * (440)+layer5_leftspeed182_to_layer6 * (443)+layer5_leftspeed183_to_layer6 * (446)+layer5_leftspeed184_to_layer6 * (449)+layer5_leftspeed185_to_layer6 * (452)+layer5_leftspeed186_to_layer6 * (455)+layer5_leftspeed187_to_layer6 * (458)+layer5_leftspeed188_to_layer6 * (461)+layer5_leftspeed189_to_layer6 * (464)+layer5_leftspeed190_to_layer6 * (467)+layer5_leftspeed191_to_layer6 * (470)+layer5_leftspeed192_to_layer6 * (473)+layer5_leftspeed193_to_layer6 * (476)+layer5_leftspeed194_to_layer6 * (479)+layer5_leftspeed195_to_layer6 * (482)+layer5_leftspeed196_to_layer6 * (485)+layer5_leftspeed197_to_layer6 * (488)+layer5_leftspeed198_to_layer6 * (491)+layer5_leftspeed199_to_layer6 * (494)+layer5_leftspeed200_to_layer6 * (497)+layer5_leftspeed201_to_layer6 * (500)+layer5_leftspeed202_to_layer6 * (503)+layer5_leftspeed203_to_layer6 * (506)+layer5_leftspeed204_to_layer6 * (509)+layer5_leftspeed205_to_layer6 * (512)+layer5_leftspeed206_to_layer6 * (515)+layer5_leftspeed207_to_layer6 * (518)+layer5_leftspeed208_to_layer6 * (521)+layer5_leftspeed209_to_layer6 * (524)+layer5_leftspeed210_to_layer6 * (527)+layer5_leftspeed211_to_layer6 * (530)+layer5_leftspeed212_to_layer6 * (533)+layer5_leftspeed213_to_layer6 * (536)+layer5_leftspeed214_to_layer6 * (539)+layer5_leftspeed215_to_layer6 * (542)+layer5_leftspeed216_to_layer6 * (545)+layer5_leftspeed217_to_layer6 * (548)+layer5_leftspeed218_to_layer6 * (551)+layer5_leftspeed219_to_layer6 * (554)+layer5_leftspeed220_to_layer6 * (557)+layer5_leftspeed221_to_layer6 * (560)+layer5_leftspeed222_to_layer6 * (563)+layer5_leftspeed223_to_layer6 * (566)+layer5_leftspeed224_to_layer6 * (569)+layer5_leftspeed225_to_layer6 * (572)+layer5_leftspeed226_to_layer6 * (575)+layer5_leftspeed227_to_layer6 * (578)+layer5_leftspeed228_to_layer6 * (581)+layer5_leftspeed229_to_layer6 * (584)+layer5_leftspeed230_to_layer6 * (587)+layer5_leftspeed231_to_layer6 * (590)+layer5_leftspeed232_to_layer6 * (593)+layer5_leftspeed233_to_layer6 * (596)+layer5_leftspeed234_to_layer6 * (599)+layer5_leftspeed235_to_layer6 * (602)+layer5_leftspeed236_to_layer6 * (605)+layer5_leftspeed237_to_layer6 * (608)+layer5_leftspeed238_to_layer6 * (611)+layer5_leftspeed239_to_layer6 * (614)+layer5_leftspeed240_to_layer6 * (617)+layer5_leftspeed241_to_layer6 * (620)+layer5_leftspeed242_to_layer6 * (623)+layer5_leftspeed243_to_layer6 * (626)+layer5_leftspeed244_to_layer6 * (629)+layer5_leftspeed245_to_layer6 * (632)+layer5_leftspeed246_to_layer6 * (635)+layer5_leftspeed247_to_layer6 * (638)+layer5_leftspeed248_to_layer6 * (641)+layer5_leftspeed249_to_layer6 * (644)+layer5_leftspeed250_to_layer6 * (647)+layer5_leftspeed251_to_layer6 * (650)+layer5_leftspeed252_to_layer6 * (653)+layer5_leftspeed253_to_layer6 * (656)+layer5_leftspeed254_to_layer6 * (659)+layer5_leftspeed255_to_layer6 * (662)+layer5_leftspeed256_to_layer6 * (665)+layer5_leftspeed257_to_layer6 * (668)+layer5_leftspeed258_to_layer6 * (671)+layer5_leftspeed259_to_layer6 * (674)+layer5_leftspeed260_to_layer6 * (677)+layer5_leftspeed261_to_layer6 * (680)+layer5_leftspeed262_to_layer6 * (683)+layer5_leftspeed263_to_layer6 * (686)+layer5_leftspeed264_to_layer6 * (689)+layer5_leftspeed265_to_layer6 * (692)+layer5_leftspeed266_to_layer6 * (695)+layer5_leftspeed267_to_layer6 * (698)+layer5_leftspeed268_to_layer6 * (701)+layer5_leftspeed269_to_layer6 * (704)+layer5_leftspeed270_to_layer6 * (707)+layer5_leftspeed271_to_layer6 * (710)+layer5_leftspeed272_to_layer6 * (713)+layer5_leftspeed273_to_layer6 * (716)+layer5_leftspeed274_to_layer6 * (719)+layer5_leftspeed275_to_layer6 * (722)+layer5_leftspeed276_to_layer6 * (725)+layer5_leftspeed277_to_layer6 * (728)+layer5_leftspeed278_to_layer6 * (731)+layer5_leftspeed279_to_layer6 * (734)+layer5_leftspeed280_to_layer6 * (737)+layer5_leftspeed281_to_layer6 * (740)+layer5_leftspeed282_to_layer6 * (743)+layer5_leftspeed283_to_layer6 * (746)+layer5_leftspeed284_to_layer6 * (749)+layer5_leftspeed285_to_layer6 * (752)+layer5_leftspeed286_to_layer6 * (755)+layer5_leftspeed287_to_layer6 * (758)+layer5_leftspeed288_to_layer6 * (761)+layer5_leftspeed289_to_layer6 * (764)+layer5_leftspeed290_to_layer6 * (767)+layer5_leftspeed291_to_layer6 * (770)+layer5_leftspeed292_to_layer6 * (773)+layer5_leftspeed293_to_layer6 * (776)+layer5_leftspeed294_to_layer6 * (779)+layer5_leftspeed295_to_layer6 * (782)+layer5_leftspeed296_to_layer6 * (785)+layer5_leftspeed297_to_layer6 * (788)+layer5_leftspeed298_to_layer6 * (791)+layer5_leftspeed299_to_layer6 * (794)+layer5_leftspeed300_to_layer6 * (797))/(layer5_leftspeed1_to_layer6 + layer5_leftspeed2_to_layer6 + layer5_leftspeed3_to_layer6 + layer5_leftspeed4_to_layer6 + layer5_leftspeed5_to_layer6 + layer5_leftspeed6_to_layer6 + layer5_leftspeed7_to_layer6 + layer5_leftspeed8_to_layer6 + layer5_leftspeed9_to_layer6 + layer5_leftspeed10_to_layer6 + layer5_leftspeed11_to_layer6 + layer5_leftspeed12_to_layer6 + layer5_leftspeed13_to_layer6 + layer5_leftspeed14_to_layer6 + layer5_leftspeed15_to_layer6 + layer5_leftspeed16_to_layer6 + layer5_leftspeed17_to_layer6 + layer5_leftspeed18_to_layer6 + layer5_leftspeed19_to_layer6 + layer5_leftspeed20_to_layer6 + layer5_leftspeed21_to_layer6 + layer5_leftspeed22_to_layer6 + layer5_leftspeed23_to_layer6 + layer5_leftspeed24_to_layer6 + layer5_leftspeed25_to_layer6 + layer5_leftspeed26_to_layer6 + layer5_leftspeed27_to_layer6 + layer5_leftspeed28_to_layer6 + layer5_leftspeed29_to_layer6 + layer5_leftspeed30_to_layer6 + layer5_leftspeed31_to_layer6 + layer5_leftspeed32_to_layer6 + layer5_leftspeed33_to_layer6 + layer5_leftspeed34_to_layer6 + layer5_leftspeed35_to_layer6 + layer5_leftspeed36_to_layer6 + layer5_leftspeed37_to_layer6 + layer5_leftspeed38_to_layer6 + layer5_leftspeed39_to_layer6 + layer5_leftspeed40_to_layer6 + layer5_leftspeed41_to_layer6 + layer5_leftspeed42_to_layer6 + layer5_leftspeed43_to_layer6 + layer5_leftspeed44_to_layer6 + layer5_leftspeed45_to_layer6 + layer5_leftspeed46_to_layer6 + layer5_leftspeed47_to_layer6 + layer5_leftspeed48_to_layer6 + layer5_leftspeed49_to_layer6 + layer5_leftspeed50_to_layer6 + layer5_leftspeed51_to_layer6 + layer5_leftspeed52_to_layer6 + layer5_leftspeed53_to_layer6 + layer5_leftspeed54_to_layer6 + layer5_leftspeed55_to_layer6 + layer5_leftspeed56_to_layer6 + layer5_leftspeed57_to_layer6 + layer5_leftspeed58_to_layer6 + layer5_leftspeed59_to_layer6 + layer5_leftspeed60_to_layer6 + layer5_leftspeed61_to_layer6 + layer5_leftspeed62_to_layer6 + layer5_leftspeed63_to_layer6 + layer5_leftspeed64_to_layer6 + layer5_leftspeed65_to_layer6 + layer5_leftspeed66_to_layer6 + layer5_leftspeed67_to_layer6 + layer5_leftspeed68_to_layer6 + layer5_leftspeed69_to_layer6 + layer5_leftspeed70_to_layer6 + layer5_leftspeed71_to_layer6 + layer5_leftspeed72_to_layer6 + layer5_leftspeed73_to_layer6 + layer5_leftspeed74_to_layer6 + layer5_leftspeed75_to_layer6 + layer5_leftspeed76_to_layer6 + layer5_leftspeed77_to_layer6 + layer5_leftspeed78_to_layer6 + layer5_leftspeed79_to_layer6 + layer5_leftspeed80_to_layer6 + layer5_leftspeed81_to_layer6 + layer5_leftspeed82_to_layer6 + layer5_leftspeed83_to_layer6 + layer5_leftspeed84_to_layer6 + layer5_leftspeed85_to_layer6 + layer5_leftspeed86_to_layer6 + layer5_leftspeed87_to_layer6 + layer5_leftspeed88_to_layer6 + layer5_leftspeed89_to_layer6 + layer5_leftspeed90_to_layer6 + layer5_leftspeed91_to_layer6 + layer5_leftspeed92_to_layer6 + layer5_leftspeed93_to_layer6 + layer5_leftspeed94_to_layer6 + layer5_leftspeed95_to_layer6 + layer5_leftspeed96_to_layer6 + layer5_leftspeed97_to_layer6 + layer5_leftspeed98_to_layer6 + layer5_leftspeed99_to_layer6 + layer5_leftspeed100_to_layer6 + layer5_leftspeed101_to_layer6 + layer5_leftspeed102_to_layer6 + layer5_leftspeed103_to_layer6 + layer5_leftspeed104_to_layer6 + layer5_leftspeed105_to_layer6 + layer5_leftspeed106_to_layer6 + layer5_leftspeed107_to_layer6 + layer5_leftspeed108_to_layer6 + layer5_leftspeed109_to_layer6 + layer5_leftspeed110_to_layer6 + layer5_leftspeed111_to_layer6 + layer5_leftspeed112_to_layer6 + layer5_leftspeed113_to_layer6 + layer5_leftspeed114_to_layer6 + layer5_leftspeed115_to_layer6 + layer5_leftspeed116_to_layer6 + layer5_leftspeed117_to_layer6 + layer5_leftspeed118_to_layer6 + layer5_leftspeed119_to_layer6 + layer5_leftspeed120_to_layer6 + layer5_leftspeed121_to_layer6 + layer5_leftspeed122_to_layer6 + layer5_leftspeed123_to_layer6 + layer5_leftspeed124_to_layer6 + layer5_leftspeed125_to_layer6 + layer5_leftspeed126_to_layer6 + layer5_leftspeed127_to_layer6 + layer5_leftspeed128_to_layer6 + layer5_leftspeed129_to_layer6 + layer5_leftspeed130_to_layer6 + layer5_leftspeed131_to_layer6 + layer5_leftspeed132_to_layer6 + layer5_leftspeed133_to_layer6 + layer5_leftspeed134_to_layer6 + layer5_leftspeed135_to_layer6 + layer5_leftspeed136_to_layer6 + layer5_leftspeed137_to_layer6 + layer5_leftspeed138_to_layer6 + layer5_leftspeed139_to_layer6 + layer5_leftspeed140_to_layer6 + layer5_leftspeed141_to_layer6 + layer5_leftspeed142_to_layer6 + layer5_leftspeed143_to_layer6 + layer5_leftspeed144_to_layer6 + layer5_leftspeed145_to_layer6 + layer5_leftspeed146_to_layer6 + layer5_leftspeed147_to_layer6 + layer5_leftspeed148_to_layer6 + layer5_leftspeed149_to_layer6 + layer5_leftspeed150_to_layer6 + layer5_leftspeed151_to_layer6 + layer5_leftspeed152_to_layer6 + layer5_leftspeed153_to_layer6 + layer5_leftspeed154_to_layer6 + layer5_leftspeed155_to_layer6 + layer5_leftspeed156_to_layer6 + layer5_leftspeed157_to_layer6 + layer5_leftspeed158_to_layer6 + layer5_leftspeed159_to_layer6 + layer5_leftspeed160_to_layer6 + layer5_leftspeed161_to_layer6 + layer5_leftspeed162_to_layer6 + layer5_leftspeed163_to_layer6 + layer5_leftspeed164_to_layer6 + layer5_leftspeed165_to_layer6 + layer5_leftspeed166_to_layer6 + layer5_leftspeed167_to_layer6 + layer5_leftspeed168_to_layer6 + layer5_leftspeed169_to_layer6 + layer5_leftspeed170_to_layer6 + layer5_leftspeed171_to_layer6 + layer5_leftspeed172_to_layer6 + layer5_leftspeed173_to_layer6 + layer5_leftspeed174_to_layer6 + layer5_leftspeed175_to_layer6 + layer5_leftspeed176_to_layer6 + layer5_leftspeed177_to_layer6 + layer5_leftspeed178_to_layer6 + layer5_leftspeed179_to_layer6 + layer5_leftspeed180_to_layer6 + layer5_leftspeed181_to_layer6 + layer5_leftspeed182_to_layer6 + layer5_leftspeed183_to_layer6 + layer5_leftspeed184_to_layer6 + layer5_leftspeed185_to_layer6 + layer5_leftspeed186_to_layer6 + layer5_leftspeed187_to_layer6 + layer5_leftspeed188_to_layer6 + layer5_leftspeed189_to_layer6 + layer5_leftspeed190_to_layer6 + layer5_leftspeed191_to_layer6 + layer5_leftspeed192_to_layer6 + layer5_leftspeed193_to_layer6 + layer5_leftspeed194_to_layer6 + layer5_leftspeed195_to_layer6 + layer5_leftspeed196_to_layer6 + layer5_leftspeed197_to_layer6 + layer5_leftspeed198_to_layer6 + layer5_leftspeed199_to_layer6 + layer5_leftspeed200_to_layer6 + layer5_leftspeed201_to_layer6 + layer5_leftspeed202_to_layer6 + layer5_leftspeed203_to_layer6 + layer5_leftspeed204_to_layer6 + layer5_leftspeed205_to_layer6 + layer5_leftspeed206_to_layer6 + layer5_leftspeed207_to_layer6 + layer5_leftspeed208_to_layer6 + layer5_leftspeed209_to_layer6 + layer5_leftspeed210_to_layer6 + layer5_leftspeed211_to_layer6 + layer5_leftspeed212_to_layer6 + layer5_leftspeed213_to_layer6 + layer5_leftspeed214_to_layer6 + layer5_leftspeed215_to_layer6 + layer5_leftspeed216_to_layer6 + layer5_leftspeed217_to_layer6 + layer5_leftspeed218_to_layer6 + layer5_leftspeed219_to_layer6 + layer5_leftspeed220_to_layer6 + layer5_leftspeed221_to_layer6 + layer5_leftspeed222_to_layer6 + layer5_leftspeed223_to_layer6 + layer5_leftspeed224_to_layer6 + layer5_leftspeed225_to_layer6 + layer5_leftspeed226_to_layer6 + layer5_leftspeed227_to_layer6 + layer5_leftspeed228_to_layer6 + layer5_leftspeed229_to_layer6 + layer5_leftspeed230_to_layer6 + layer5_leftspeed231_to_layer6 + layer5_leftspeed232_to_layer6 + layer5_leftspeed233_to_layer6 + layer5_leftspeed234_to_layer6 + layer5_leftspeed235_to_layer6 + layer5_leftspeed236_to_layer6 + layer5_leftspeed237_to_layer6 + layer5_leftspeed238_to_layer6 + layer5_leftspeed239_to_layer6 + layer5_leftspeed240_to_layer6 + layer5_leftspeed241_to_layer6 + layer5_leftspeed242_to_layer6 + layer5_leftspeed243_to_layer6 + layer5_leftspeed244_to_layer6 + layer5_leftspeed245_to_layer6 + layer5_leftspeed246_to_layer6 + layer5_leftspeed247_to_layer6 + layer5_leftspeed248_to_layer6 + layer5_leftspeed249_to_layer6 + layer5_leftspeed250_to_layer6 + layer5_leftspeed251_to_layer6 + layer5_leftspeed252_to_layer6 + layer5_leftspeed253_to_layer6 + layer5_leftspeed254_to_layer6 + layer5_leftspeed255_to_layer6 + layer5_leftspeed256_to_layer6 + layer5_leftspeed257_to_layer6 + layer5_leftspeed258_to_layer6 + layer5_leftspeed259_to_layer6 + layer5_leftspeed260_to_layer6 + layer5_leftspeed261_to_layer6 + layer5_leftspeed262_to_layer6 + layer5_leftspeed263_to_layer6 + layer5_leftspeed264_to_layer6 + layer5_leftspeed265_to_layer6 + layer5_leftspeed266_to_layer6 + layer5_leftspeed267_to_layer6 + layer5_leftspeed268_to_layer6 + layer5_leftspeed269_to_layer6 + layer5_leftspeed270_to_layer6 + layer5_leftspeed271_to_layer6 + layer5_leftspeed272_to_layer6 + layer5_leftspeed273_to_layer6 + layer5_leftspeed274_to_layer6 + layer5_leftspeed275_to_layer6 + layer5_leftspeed276_to_layer6 + layer5_leftspeed277_to_layer6 + layer5_leftspeed278_to_layer6 + layer5_leftspeed279_to_layer6 + layer5_leftspeed280_to_layer6 + layer5_leftspeed281_to_layer6 + layer5_leftspeed282_to_layer6 + layer5_leftspeed283_to_layer6 + layer5_leftspeed284_to_layer6 + layer5_leftspeed285_to_layer6 + layer5_leftspeed286_to_layer6 + layer5_leftspeed287_to_layer6 + layer5_leftspeed288_to_layer6 + layer5_leftspeed289_to_layer6 + layer5_leftspeed290_to_layer6 + layer5_leftspeed291_to_layer6 + layer5_leftspeed292_to_layer6 + layer5_leftspeed293_to_layer6 + layer5_leftspeed294_to_layer6 + layer5_leftspeed295_to_layer6 + layer5_leftspeed296_to_layer6 + layer5_leftspeed297_to_layer6 + layer5_leftspeed298_to_layer6 + layer5_leftspeed299_to_layer6 + layer5_leftspeed300_to_layer6 +0.01)) [e5 -> ] 1|calculate_leftspeed};
		E0  = (1);
		var0 ={0,0};
    };
	layer6_rightspeed =  {
	    E = {e5};
		var ={f0,calculate_rightspeed};
		pr = {((layer5_rightspeed1_to_layer6 * (0-100)+layer5_rightspeed2_to_layer6 * (0-97)+layer5_rightspeed3_to_layer6 * (0-94)+layer5_rightspeed4_to_layer6 * (0-91)+layer5_rightspeed5_to_layer6 * (0-88)+layer5_rightspeed6_to_layer6 * (0-85)+layer5_rightspeed7_to_layer6 * (0-82)+layer5_rightspeed8_to_layer6 * (0-79)+layer5_rightspeed9_to_layer6 * (0-76)+layer5_rightspeed10_to_layer6 * (0-73)+layer5_rightspeed11_to_layer6 * (0-70)+layer5_rightspeed12_to_layer6 * (0-67)+layer5_rightspeed13_to_layer6 * (0-64)+layer5_rightspeed14_to_layer6 * (0-61)+layer5_rightspeed15_to_layer6 * (0-58)+layer5_rightspeed16_to_layer6 * (0-55)+layer5_rightspeed17_to_layer6 * (0-52)+layer5_rightspeed18_to_layer6 * (0-49)+layer5_rightspeed19_to_layer6 * (0-46)+layer5_rightspeed20_to_layer6 * (0-43)+layer5_rightspeed21_to_layer6 * (0-40)+layer5_rightspeed22_to_layer6 * (0-37)+layer5_rightspeed23_to_layer6 * (0-34)+layer5_rightspeed24_to_layer6 * (0-31)+layer5_rightspeed25_to_layer6 * (0-28)+layer5_rightspeed26_to_layer6 * (0-25)+layer5_rightspeed27_to_layer6 * (0-22)+layer5_rightspeed28_to_layer6 * (0-19)+layer5_rightspeed29_to_layer6 * (0-16)+layer5_rightspeed30_to_layer6 * (0-13)+layer5_rightspeed31_to_layer6 * (0-10)+layer5_rightspeed32_to_layer6 * (0-7)+layer5_rightspeed33_to_layer6 * (0-4)+layer5_rightspeed34_to_layer6 * (0-1)+layer5_rightspeed35_to_layer6 * (02)+layer5_rightspeed36_to_layer6 * (05)+layer5_rightspeed37_to_layer6 * (08)+layer5_rightspeed38_to_layer6 * (011)+layer5_rightspeed39_to_layer6 * (014)+layer5_rightspeed40_to_layer6 * (017)+layer5_rightspeed41_to_layer6 * (020)+layer5_rightspeed42_to_layer6 * (023)+layer5_rightspeed43_to_layer6 * (026)+layer5_rightspeed44_to_layer6 * (029)+layer5_rightspeed45_to_layer6 * (032)+layer5_rightspeed46_to_layer6 * (035)+layer5_rightspeed47_to_layer6 * (038)+layer5_rightspeed48_to_layer6 * (041)+layer5_rightspeed49_to_layer6 * (044)+layer5_rightspeed50_to_layer6 * (47)+layer5_rightspeed51_to_layer6 * (50)+layer5_rightspeed52_to_layer6 * (53)+layer5_rightspeed53_to_layer6 * (56)+layer5_rightspeed54_to_layer6 * (59)+layer5_rightspeed55_to_layer6 * (62)+layer5_rightspeed56_to_layer6 * (65)+layer5_rightspeed57_to_layer6 * (68)+layer5_rightspeed58_to_layer6 * (71)+layer5_rightspeed59_to_layer6 * (74)+layer5_rightspeed60_to_layer6 * (77)+layer5_rightspeed61_to_layer6 * (80)+layer5_rightspeed62_to_layer6 * (83)+layer5_rightspeed63_to_layer6 * (86)+layer5_rightspeed64_to_layer6 * (89)+layer5_rightspeed65_to_layer6 * (92)+layer5_rightspeed66_to_layer6 * (95)+layer5_rightspeed67_to_layer6 * (98)+layer5_rightspeed68_to_layer6 * (101)+layer5_rightspeed69_to_layer6 * (104)+layer5_rightspeed70_to_layer6 * (107)+layer5_rightspeed71_to_layer6 * (110)+layer5_rightspeed72_to_layer6 * (113)+layer5_rightspeed73_to_layer6 * (116)+layer5_rightspeed74_to_layer6 * (119)+layer5_rightspeed75_to_layer6 * (122)+layer5_rightspeed76_to_layer6 * (125)+layer5_rightspeed77_to_layer6 * (128)+layer5_rightspeed78_to_layer6 * (131)+layer5_rightspeed79_to_layer6 * (134)+layer5_rightspeed80_to_layer6 * (137)+layer5_rightspeed81_to_layer6 * (140)+layer5_rightspeed82_to_layer6 * (143)+layer5_rightspeed83_to_layer6 * (146)+layer5_rightspeed84_to_layer6 * (149)+layer5_rightspeed85_to_layer6 * (152)+layer5_rightspeed86_to_layer6 * (155)+layer5_rightspeed87_to_layer6 * (158)+layer5_rightspeed88_to_layer6 * (161)+layer5_rightspeed89_to_layer6 * (164)+layer5_rightspeed90_to_layer6 * (167)+layer5_rightspeed91_to_layer6 * (170)+layer5_rightspeed92_to_layer6 * (173)+layer5_rightspeed93_to_layer6 * (176)+layer5_rightspeed94_to_layer6 * (179)+layer5_rightspeed95_to_layer6 * (182)+layer5_rightspeed96_to_layer6 * (185)+layer5_rightspeed97_to_layer6 * (188)+layer5_rightspeed98_to_layer6 * (191)+layer5_rightspeed99_to_layer6 * (194)+layer5_rightspeed100_to_layer6 * (197)+layer5_rightspeed101_to_layer6 * (200)+layer5_rightspeed102_to_layer6 * (203)+layer5_rightspeed103_to_layer6 * (206)+layer5_rightspeed104_to_layer6 * (209)+layer5_rightspeed105_to_layer6 * (212)+layer5_rightspeed106_to_layer6 * (215)+layer5_rightspeed107_to_layer6 * (218)+layer5_rightspeed108_to_layer6 * (221)+layer5_rightspeed109_to_layer6 * (224)+layer5_rightspeed110_to_layer6 * (227)+layer5_rightspeed111_to_layer6 * (230)+layer5_rightspeed112_to_layer6 * (233)+layer5_rightspeed113_to_layer6 * (236)+layer5_rightspeed114_to_layer6 * (239)+layer5_rightspeed115_to_layer6 * (242)+layer5_rightspeed116_to_layer6 * (245)+layer5_rightspeed117_to_layer6 * (248)+layer5_rightspeed118_to_layer6 * (251)+layer5_rightspeed119_to_layer6 * (254)+layer5_rightspeed120_to_layer6 * (257)+layer5_rightspeed121_to_layer6 * (260)+layer5_rightspeed122_to_layer6 * (263)+layer5_rightspeed123_to_layer6 * (266)+layer5_rightspeed124_to_layer6 * (269)+layer5_rightspeed125_to_layer6 * (272)+layer5_rightspeed126_to_layer6 * (275)+layer5_rightspeed127_to_layer6 * (278)+layer5_rightspeed128_to_layer6 * (281)+layer5_rightspeed129_to_layer6 * (284)+layer5_rightspeed130_to_layer6 * (287)+layer5_rightspeed131_to_layer6 * (290)+layer5_rightspeed132_to_layer6 * (293)+layer5_rightspeed133_to_layer6 * (296)+layer5_rightspeed134_to_layer6 * (299)+layer5_rightspeed135_to_layer6 * (302)+layer5_rightspeed136_to_layer6 * (305)+layer5_rightspeed137_to_layer6 * (308)+layer5_rightspeed138_to_layer6 * (311)+layer5_rightspeed139_to_layer6 * (314)+layer5_rightspeed140_to_layer6 * (317)+layer5_rightspeed141_to_layer6 * (320)+layer5_rightspeed142_to_layer6 * (323)+layer5_rightspeed143_to_layer6 * (326)+layer5_rightspeed144_to_layer6 * (329)+layer5_rightspeed145_to_layer6 * (332)+layer5_rightspeed146_to_layer6 * (335)+layer5_rightspeed147_to_layer6 * (338)+layer5_rightspeed148_to_layer6 * (341)+layer5_rightspeed149_to_layer6 * (344)+layer5_rightspeed150_to_layer6 * (347)+layer5_rightspeed151_to_layer6 * (350)+layer5_rightspeed152_to_layer6 * (353)+layer5_rightspeed153_to_layer6 * (356)+layer5_rightspeed154_to_layer6 * (359)+layer5_rightspeed155_to_layer6 * (362)+layer5_rightspeed156_to_layer6 * (365)+layer5_rightspeed157_to_layer6 * (368)+layer5_rightspeed158_to_layer6 * (371)+layer5_rightspeed159_to_layer6 * (374)+layer5_rightspeed160_to_layer6 * (377)+layer5_rightspeed161_to_layer6 * (380)+layer5_rightspeed162_to_layer6 * (383)+layer5_rightspeed163_to_layer6 * (386)+layer5_rightspeed164_to_layer6 * (389)+layer5_rightspeed165_to_layer6 * (392)+layer5_rightspeed166_to_layer6 * (395)+layer5_rightspeed167_to_layer6 * (398)+layer5_rightspeed168_to_layer6 * (401)+layer5_rightspeed169_to_layer6 * (404)+layer5_rightspeed170_to_layer6 * (407)+layer5_rightspeed171_to_layer6 * (410)+layer5_rightspeed172_to_layer6 * (413)+layer5_rightspeed173_to_layer6 * (416)+layer5_rightspeed174_to_layer6 * (419)+layer5_rightspeed175_to_layer6 * (422)+layer5_rightspeed176_to_layer6 * (425)+layer5_rightspeed177_to_layer6 * (428)+layer5_rightspeed178_to_layer6 * (431)+layer5_rightspeed179_to_layer6 * (434)+layer5_rightspeed180_to_layer6 * (437)+layer5_rightspeed181_to_layer6 * (440)+layer5_rightspeed182_to_layer6 * (443)+layer5_rightspeed183_to_layer6 * (446)+layer5_rightspeed184_to_layer6 * (449)+layer5_rightspeed185_to_layer6 * (452)+layer5_rightspeed186_to_layer6 * (455)+layer5_rightspeed187_to_layer6 * (458)+layer5_rightspeed188_to_layer6 * (461)+layer5_rightspeed189_to_layer6 * (464)+layer5_rightspeed190_to_layer6 * (467)+layer5_rightspeed191_to_layer6 * (470)+layer5_rightspeed192_to_layer6 * (473)+layer5_rightspeed193_to_layer6 * (476)+layer5_rightspeed194_to_layer6 * (479)+layer5_rightspeed195_to_layer6 * (482)+layer5_rightspeed196_to_layer6 * (485)+layer5_rightspeed197_to_layer6 * (488)+layer5_rightspeed198_to_layer6 * (491)+layer5_rightspeed199_to_layer6 * (494)+layer5_rightspeed200_to_layer6 * (497)+layer5_rightspeed201_to_layer6 * (500)+layer5_rightspeed202_to_layer6 * (503)+layer5_rightspeed203_to_layer6 * (506)+layer5_rightspeed204_to_layer6 * (509)+layer5_rightspeed205_to_layer6 * (512)+layer5_rightspeed206_to_layer6 * (515)+layer5_rightspeed207_to_layer6 * (518)+layer5_rightspeed208_to_layer6 * (521)+layer5_rightspeed209_to_layer6 * (524)+layer5_rightspeed210_to_layer6 * (527)+layer5_rightspeed211_to_layer6 * (530)+layer5_rightspeed212_to_layer6 * (533)+layer5_rightspeed213_to_layer6 * (536)+layer5_rightspeed214_to_layer6 * (539)+layer5_rightspeed215_to_layer6 * (542)+layer5_rightspeed216_to_layer6 * (545)+layer5_rightspeed217_to_layer6 * (548)+layer5_rightspeed218_to_layer6 * (551)+layer5_rightspeed219_to_layer6 * (554)+layer5_rightspeed220_to_layer6 * (557)+layer5_rightspeed221_to_layer6 * (560)+layer5_rightspeed222_to_layer6 * (563)+layer5_rightspeed223_to_layer6 * (566)+layer5_rightspeed224_to_layer6 * (569)+layer5_rightspeed225_to_layer6 * (572)+layer5_rightspeed226_to_layer6 * (575)+layer5_rightspeed227_to_layer6 * (578)+layer5_rightspeed228_to_layer6 * (581)+layer5_rightspeed229_to_layer6 * (584)+layer5_rightspeed230_to_layer6 * (587)+layer5_rightspeed231_to_layer6 * (590)+layer5_rightspeed232_to_layer6 * (593)+layer5_rightspeed233_to_layer6 * (596)+layer5_rightspeed234_to_layer6 * (599)+layer5_rightspeed235_to_layer6 * (602)+layer5_rightspeed236_to_layer6 * (605)+layer5_rightspeed237_to_layer6 * (608)+layer5_rightspeed238_to_layer6 * (611)+layer5_rightspeed239_to_layer6 * (614)+layer5_rightspeed240_to_layer6 * (617)+layer5_rightspeed241_to_layer6 * (620)+layer5_rightspeed242_to_layer6 * (623)+layer5_rightspeed243_to_layer6 * (626)+layer5_rightspeed244_to_layer6 * (629)+layer5_rightspeed245_to_layer6 * (632)+layer5_rightspeed246_to_layer6 * (635)+layer5_rightspeed247_to_layer6 * (638)+layer5_rightspeed248_to_layer6 * (641)+layer5_rightspeed249_to_layer6 * (644)+layer5_rightspeed250_to_layer6 * (647)+layer5_rightspeed251_to_layer6 * (650)+layer5_rightspeed252_to_layer6 * (653)+layer5_rightspeed253_to_layer6 * (656)+layer5_rightspeed254_to_layer6 * (659)+layer5_rightspeed255_to_layer6 * (662)+layer5_rightspeed256_to_layer6 * (665)+layer5_rightspeed257_to_layer6 * (668)+layer5_rightspeed258_to_layer6 * (671)+layer5_rightspeed259_to_layer6 * (674)+layer5_rightspeed260_to_layer6 * (677)+layer5_rightspeed261_to_layer6 * (680)+layer5_rightspeed262_to_layer6 * (683)+layer5_rightspeed263_to_layer6 * (686)+layer5_rightspeed264_to_layer6 * (689)+layer5_rightspeed265_to_layer6 * (692)+layer5_rightspeed266_to_layer6 * (695)+layer5_rightspeed267_to_layer6 * (698)+layer5_rightspeed268_to_layer6 * (701)+layer5_rightspeed269_to_layer6 * (704)+layer5_rightspeed270_to_layer6 * (707)+layer5_rightspeed271_to_layer6 * (710)+layer5_rightspeed272_to_layer6 * (713)+layer5_rightspeed273_to_layer6 * (716)+layer5_rightspeed274_to_layer6 * (719)+layer5_rightspeed275_to_layer6 * (722)+layer5_rightspeed276_to_layer6 * (725)+layer5_rightspeed277_to_layer6 * (728)+layer5_rightspeed278_to_layer6 * (731)+layer5_rightspeed279_to_layer6 * (734)+layer5_rightspeed280_to_layer6 * (737)+layer5_rightspeed281_to_layer6 * (740)+layer5_rightspeed282_to_layer6 * (743)+layer5_rightspeed283_to_layer6 * (746)+layer5_rightspeed284_to_layer6 * (749)+layer5_rightspeed285_to_layer6 * (752)+layer5_rightspeed286_to_layer6 * (755)+layer5_rightspeed287_to_layer6 * (758)+layer5_rightspeed288_to_layer6 * (761)+layer5_rightspeed289_to_layer6 * (764)+layer5_rightspeed290_to_layer6 * (767)+layer5_rightspeed291_to_layer6 * (770)+layer5_rightspeed292_to_layer6 * (773)+layer5_rightspeed293_to_layer6 * (776)+layer5_rightspeed294_to_layer6 * (779)+layer5_rightspeed295_to_layer6 * (782)+layer5_rightspeed296_to_layer6 * (785)+layer5_rightspeed297_to_layer6 * (788)+layer5_rightspeed298_to_layer6 * (791)+layer5_rightspeed299_to_layer6 * (794)+layer5_rightspeed300_to_layer6 * (797))/(layer5_rightspeed1_to_layer6 + layer5_rightspeed2_to_layer6 + layer5_rightspeed3_to_layer6 + layer5_rightspeed4_to_layer6 + layer5_rightspeed5_to_layer6 + layer5_rightspeed6_to_layer6 + layer5_rightspeed7_to_layer6 + layer5_rightspeed8_to_layer6 + layer5_rightspeed9_to_layer6 + layer5_rightspeed10_to_layer6 + layer5_rightspeed11_to_layer6 + layer5_rightspeed12_to_layer6 + layer5_rightspeed13_to_layer6 + layer5_rightspeed14_to_layer6 + layer5_rightspeed15_to_layer6 + layer5_rightspeed16_to_layer6 + layer5_rightspeed17_to_layer6 + layer5_rightspeed18_to_layer6 + layer5_rightspeed19_to_layer6 + layer5_rightspeed20_to_layer6 + layer5_rightspeed21_to_layer6 + layer5_rightspeed22_to_layer6 + layer5_rightspeed23_to_layer6 + layer5_rightspeed24_to_layer6 + layer5_rightspeed25_to_layer6 + layer5_rightspeed26_to_layer6 + layer5_rightspeed27_to_layer6 + layer5_rightspeed28_to_layer6 + layer5_rightspeed29_to_layer6 + layer5_rightspeed30_to_layer6 + layer5_rightspeed31_to_layer6 + layer5_rightspeed32_to_layer6 + layer5_rightspeed33_to_layer6 + layer5_rightspeed34_to_layer6 + layer5_rightspeed35_to_layer6 + layer5_rightspeed36_to_layer6 + layer5_rightspeed37_to_layer6 + layer5_rightspeed38_to_layer6 + layer5_rightspeed39_to_layer6 + layer5_rightspeed40_to_layer6 + layer5_rightspeed41_to_layer6 + layer5_rightspeed42_to_layer6 + layer5_rightspeed43_to_layer6 + layer5_rightspeed44_to_layer6 + layer5_rightspeed45_to_layer6 + layer5_rightspeed46_to_layer6 + layer5_rightspeed47_to_layer6 + layer5_rightspeed48_to_layer6 + layer5_rightspeed49_to_layer6 + layer5_rightspeed50_to_layer6 + layer5_rightspeed51_to_layer6 + layer5_rightspeed52_to_layer6 + layer5_rightspeed53_to_layer6 + layer5_rightspeed54_to_layer6 + layer5_rightspeed55_to_layer6 + layer5_rightspeed56_to_layer6 + layer5_rightspeed57_to_layer6 + layer5_rightspeed58_to_layer6 + layer5_rightspeed59_to_layer6 + layer5_rightspeed60_to_layer6 + layer5_rightspeed61_to_layer6 + layer5_rightspeed62_to_layer6 + layer5_rightspeed63_to_layer6 + layer5_rightspeed64_to_layer6 + layer5_rightspeed65_to_layer6 + layer5_rightspeed66_to_layer6 + layer5_rightspeed67_to_layer6 + layer5_rightspeed68_to_layer6 + layer5_rightspeed69_to_layer6 + layer5_rightspeed70_to_layer6 + layer5_rightspeed71_to_layer6 + layer5_rightspeed72_to_layer6 + layer5_rightspeed73_to_layer6 + layer5_rightspeed74_to_layer6 + layer5_rightspeed75_to_layer6 + layer5_rightspeed76_to_layer6 + layer5_rightspeed77_to_layer6 + layer5_rightspeed78_to_layer6 + layer5_rightspeed79_to_layer6 + layer5_rightspeed80_to_layer6 + layer5_rightspeed81_to_layer6 + layer5_rightspeed82_to_layer6 + layer5_rightspeed83_to_layer6 + layer5_rightspeed84_to_layer6 + layer5_rightspeed85_to_layer6 + layer5_rightspeed86_to_layer6 + layer5_rightspeed87_to_layer6 + layer5_rightspeed88_to_layer6 + layer5_rightspeed89_to_layer6 + layer5_rightspeed90_to_layer6 + layer5_rightspeed91_to_layer6 + layer5_rightspeed92_to_layer6 + layer5_rightspeed93_to_layer6 + layer5_rightspeed94_to_layer6 + layer5_rightspeed95_to_layer6 + layer5_rightspeed96_to_layer6 + layer5_rightspeed97_to_layer6 + layer5_rightspeed98_to_layer6 + layer5_rightspeed99_to_layer6 + layer5_rightspeed100_to_layer6 + layer5_rightspeed101_to_layer6 + layer5_rightspeed102_to_layer6 + layer5_rightspeed103_to_layer6 + layer5_rightspeed104_to_layer6 + layer5_rightspeed105_to_layer6 + layer5_rightspeed106_to_layer6 + layer5_rightspeed107_to_layer6 + layer5_rightspeed108_to_layer6 + layer5_rightspeed109_to_layer6 + layer5_rightspeed110_to_layer6 + layer5_rightspeed111_to_layer6 + layer5_rightspeed112_to_layer6 + layer5_rightspeed113_to_layer6 + layer5_rightspeed114_to_layer6 + layer5_rightspeed115_to_layer6 + layer5_rightspeed116_to_layer6 + layer5_rightspeed117_to_layer6 + layer5_rightspeed118_to_layer6 + layer5_rightspeed119_to_layer6 + layer5_rightspeed120_to_layer6 + layer5_rightspeed121_to_layer6 + layer5_rightspeed122_to_layer6 + layer5_rightspeed123_to_layer6 + layer5_rightspeed124_to_layer6 + layer5_rightspeed125_to_layer6 + layer5_rightspeed126_to_layer6 + layer5_rightspeed127_to_layer6 + layer5_rightspeed128_to_layer6 + layer5_rightspeed129_to_layer6 + layer5_rightspeed130_to_layer6 + layer5_rightspeed131_to_layer6 + layer5_rightspeed132_to_layer6 + layer5_rightspeed133_to_layer6 + layer5_rightspeed134_to_layer6 + layer5_rightspeed135_to_layer6 + layer5_rightspeed136_to_layer6 + layer5_rightspeed137_to_layer6 + layer5_rightspeed138_to_layer6 + layer5_rightspeed139_to_layer6 + layer5_rightspeed140_to_layer6 + layer5_rightspeed141_to_layer6 + layer5_rightspeed142_to_layer6 + layer5_rightspeed143_to_layer6 + layer5_rightspeed144_to_layer6 + layer5_rightspeed145_to_layer6 + layer5_rightspeed146_to_layer6 + layer5_rightspeed147_to_layer6 + layer5_rightspeed148_to_layer6 + layer5_rightspeed149_to_layer6 + layer5_rightspeed150_to_layer6 + layer5_rightspeed151_to_layer6 + layer5_rightspeed152_to_layer6 + layer5_rightspeed153_to_layer6 + layer5_rightspeed154_to_layer6 + layer5_rightspeed155_to_layer6 + layer5_rightspeed156_to_layer6 + layer5_rightspeed157_to_layer6 + layer5_rightspeed158_to_layer6 + layer5_rightspeed159_to_layer6 + layer5_rightspeed160_to_layer6 + layer5_rightspeed161_to_layer6 + layer5_rightspeed162_to_layer6 + layer5_rightspeed163_to_layer6 + layer5_rightspeed164_to_layer6 + layer5_rightspeed165_to_layer6 + layer5_rightspeed166_to_layer6 + layer5_rightspeed167_to_layer6 + layer5_rightspeed168_to_layer6 + layer5_rightspeed169_to_layer6 + layer5_rightspeed170_to_layer6 + layer5_rightspeed171_to_layer6 + layer5_rightspeed172_to_layer6 + layer5_rightspeed173_to_layer6 + layer5_rightspeed174_to_layer6 + layer5_rightspeed175_to_layer6 + layer5_rightspeed176_to_layer6 + layer5_rightspeed177_to_layer6 + layer5_rightspeed178_to_layer6 + layer5_rightspeed179_to_layer6 + layer5_rightspeed180_to_layer6 + layer5_rightspeed181_to_layer6 + layer5_rightspeed182_to_layer6 + layer5_rightspeed183_to_layer6 + layer5_rightspeed184_to_layer6 + layer5_rightspeed185_to_layer6 + layer5_rightspeed186_to_layer6 + layer5_rightspeed187_to_layer6 + layer5_rightspeed188_to_layer6 + layer5_rightspeed189_to_layer6 + layer5_rightspeed190_to_layer6 + layer5_rightspeed191_to_layer6 + layer5_rightspeed192_to_layer6 + layer5_rightspeed193_to_layer6 + layer5_rightspeed194_to_layer6 + layer5_rightspeed195_to_layer6 + layer5_rightspeed196_to_layer6 + layer5_rightspeed197_to_layer6 + layer5_rightspeed198_to_layer6 + layer5_rightspeed199_to_layer6 + layer5_rightspeed200_to_layer6 + layer5_rightspeed201_to_layer6 + layer5_rightspeed202_to_layer6 + layer5_rightspeed203_to_layer6 + layer5_rightspeed204_to_layer6 + layer5_rightspeed205_to_layer6 + layer5_rightspeed206_to_layer6 + layer5_rightspeed207_to_layer6 + layer5_rightspeed208_to_layer6 + layer5_rightspeed209_to_layer6 + layer5_rightspeed210_to_layer6 + layer5_rightspeed211_to_layer6 + layer5_rightspeed212_to_layer6 + layer5_rightspeed213_to_layer6 + layer5_rightspeed214_to_layer6 + layer5_rightspeed215_to_layer6 + layer5_rightspeed216_to_layer6 + layer5_rightspeed217_to_layer6 + layer5_rightspeed218_to_layer6 + layer5_rightspeed219_to_layer6 + layer5_rightspeed220_to_layer6 + layer5_rightspeed221_to_layer6 + layer5_rightspeed222_to_layer6 + layer5_rightspeed223_to_layer6 + layer5_rightspeed224_to_layer6 + layer5_rightspeed225_to_layer6 + layer5_rightspeed226_to_layer6 + layer5_rightspeed227_to_layer6 + layer5_rightspeed228_to_layer6 + layer5_rightspeed229_to_layer6 + layer5_rightspeed230_to_layer6 + layer5_rightspeed231_to_layer6 + layer5_rightspeed232_to_layer6 + layer5_rightspeed233_to_layer6 + layer5_rightspeed234_to_layer6 + layer5_rightspeed235_to_layer6 + layer5_rightspeed236_to_layer6 + layer5_rightspeed237_to_layer6 + layer5_rightspeed238_to_layer6 + layer5_rightspeed239_to_layer6 + layer5_rightspeed240_to_layer6 + layer5_rightspeed241_to_layer6 + layer5_rightspeed242_to_layer6 + layer5_rightspeed243_to_layer6 + layer5_rightspeed244_to_layer6 + layer5_rightspeed245_to_layer6 + layer5_rightspeed246_to_layer6 + layer5_rightspeed247_to_layer6 + layer5_rightspeed248_to_layer6 + layer5_rightspeed249_to_layer6 + layer5_rightspeed250_to_layer6 + layer5_rightspeed251_to_layer6 + layer5_rightspeed252_to_layer6 + layer5_rightspeed253_to_layer6 + layer5_rightspeed254_to_layer6 + layer5_rightspeed255_to_layer6 + layer5_rightspeed256_to_layer6 + layer5_rightspeed257_to_layer6 + layer5_rightspeed258_to_layer6 + layer5_rightspeed259_to_layer6 + layer5_rightspeed260_to_layer6 + layer5_rightspeed261_to_layer6 + layer5_rightspeed262_to_layer6 + layer5_rightspeed263_to_layer6 + layer5_rightspeed264_to_layer6 + layer5_rightspeed265_to_layer6 + layer5_rightspeed266_to_layer6 + layer5_rightspeed267_to_layer6 + layer5_rightspeed268_to_layer6 + layer5_rightspeed269_to_layer6 + layer5_rightspeed270_to_layer6 + layer5_rightspeed271_to_layer6 + layer5_rightspeed272_to_layer6 + layer5_rightspeed273_to_layer6 + layer5_rightspeed274_to_layer6 + layer5_rightspeed275_to_layer6 + layer5_rightspeed276_to_layer6 + layer5_rightspeed277_to_layer6 + layer5_rightspeed278_to_layer6 + layer5_rightspeed279_to_layer6 + layer5_rightspeed280_to_layer6 + layer5_rightspeed281_to_layer6 + layer5_rightspeed282_to_layer6 + layer5_rightspeed283_to_layer6 + layer5_rightspeed284_to_layer6 + layer5_rightspeed285_to_layer6 + layer5_rightspeed286_to_layer6 + layer5_rightspeed287_to_layer6 + layer5_rightspeed288_to_layer6 + layer5_rightspeed289_to_layer6 + layer5_rightspeed290_to_layer6 + layer5_rightspeed291_to_layer6 + layer5_rightspeed292_to_layer6 + layer5_rightspeed293_to_layer6 + layer5_rightspeed294_to_layer6 + layer5_rightspeed295_to_layer6 + layer5_rightspeed296_to_layer6 + layer5_rightspeed297_to_layer6 + layer5_rightspeed298_to_layer6 + layer5_rightspeed299_to_layer6 + layer5_rightspeed300_to_layer6 +0.01)) [e5 -> ] 1|calculate_rightspeed};
		E0  = (1);
		var0 ={0,0};
		
    };
}
}