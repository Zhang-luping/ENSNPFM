# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
from typing import Tuple, List, Optional
import queue
import threading
import time
from collections import deque


class RealTimeFuzzySystem:
    """实时流水线模糊推理系统 - 3D张量无循环优化版本"""

    def __init__(self, n_inputs=4, n_outputs=2, n_input_mfs=5, n_output_mfs=4, n_rules=84, use_gpu=True):
        self.n_inputs = n_inputs
        self.n_outputs = n_outputs
        self.n_input_mfs = n_input_mfs
        self.n_output_mfs = n_output_mfs
        self.n_rules = n_rules

        # 设备选择
        if use_gpu and torch.cuda.is_available():
            self.device = torch.device('cuda')
            print(f"使用GPU: {torch.cuda.get_device_name()}")
        else:
            self.device = torch.device('cpu')
            print("使用CPU")

        # 初始化参数
        self._init_membership_functions()
        self._init_fuzzy_rules()

        # 🚀 关键优化：预计算所有固定张量
        self._precompute_fixed_tensors()

        # 🎯 新增：预计算3D张量格式的所有数据
        self._precompute_3d_matrices()

        # 🔄 流水线队列系统 - 标准5个阶段
        self.stage_queues = {
            'fuzzification': deque(maxlen=10),  # 阶段1：模糊化
            'rule_evaluation': deque(maxlen=10),  # 阶段2：规则评估
            'clipping': deque(maxlen=10),  # 阶段3：截断
            'aggregation': deque(maxlen=10),  # 阶段4：聚合
            'defuzzification': deque(maxlen=10),  # 阶段5：解模糊
            'output': deque(maxlen=10)  # 输出缓存
        }

        # 流水线控制
        self.pipeline_running = False
        self.pipeline_threads = []

    def _init_membership_functions(self):
        """初始化隶属函数参数"""
        # 输入变量的隶属函数参数
        self.input_mf_params = torch.zeros(self.n_inputs, self.n_input_mfs, 2, device=self.device)

        centers_matrix = [
            [150, 300, 450, 650, 900],  # S4
            [100, 300, 500, 700, 900],  # S5
            [50, 250, 400, 600, 850],  # S6
            [50, 200, 300, 500, 850]  # S7
        ]

        widths_matrix = [
            [75, 125, 150, 75, 50],  # S4宽度
            [50, 125, 100, 100, 50],  # S5宽度
            [50, 100, 75, 100, 50],  # S6宽度
            [50, 100, 75, 125, 50]  # S7宽度
        ]

        self.input_mf_params[:, :, 0] = torch.tensor(centers_matrix, device=self.device)
        self.input_mf_params[:, :, 1] = torch.tensor(widths_matrix, device=self.device)

        # 输出变量的隶属函数参数
        self.output_mf_params = torch.zeros(self.n_outputs, self.n_output_mfs, 2, device=self.device)

        output_centers_matrix = [
            [10, 300, 500, 650],  # leftspeed
            [10, 300, 500, 650]  # rightspeed
        ]

        output_widths_matrix = [
            [75, 75, 75, 40],  # leftspeed宽度
            [75, 75, 75, 40]  # rightspeed宽度
        ]

        self.output_mf_params[:, :, 0] = torch.tensor(output_centers_matrix, device=self.device)
        self.output_mf_params[:, :, 1] = torch.tensor(output_widths_matrix, device=self.device)

    def _init_fuzzy_rules(self):
        """初始化84条模糊规则"""
        predefined_antecedents = [
            [4, 4, 2, 2], [4, 4, 1, 2], [4, 4, 1, 1], [4, 4, 1, 0], [4, 4, 0, 1],
            [4, 4, 0, 0], [4, 4, 2, 3], [4, 4, 3, 2], [4, 4, 3, 3], [4, 4, 3, 4],
            [4, 4, 4, 3], [4, 4, 4, 4], [4, 3, 2, 2], [4, 3, 1, 2], [4, 3, 1, 1],
            [4, 3, 1, 0], [4, 3, 0, 1], [4, 3, 0, 0], [4, 3, 2, 3], [4, 3, 3, 2],
            [4, 3, 3, 3], [4, 3, 3, 4], [4, 3, 4, 3], [4, 3, 4, 4], [4, 4, 3, 1],
            [4, 4, 4, 0], [4, 3, 4, 0], [4, 3, 3, 1], [4, 4, 3, 0], [4, 4, 3, 1],
            [4, 4, 4, 1], [4, 4, 4, 1], [2, 2, 2, 2], [2, 2, 2, 1], [2, 2, 2, 0],
            [2, 2, 1, 1], [2, 2, 1, 2], [2, 2, 1, 0], [2, 2, 2, 0], [2, 2, 3, 3],
            [2, 2, 0, 0], [2, 2, 1, 0], [2, 1, 2, 2], [2, 1, 2, 1], [2, 1, 2, 0],
            [2, 1, 1, 1], [2, 1, 1, 2], [2, 1, 1, 0], [2, 1, 2, 0], [2, 1, 3, 3],
            [2, 1, 0, 0], [2, 1, 1, 0], [3, 4, 3, 1], [3, 4, 4, 0], [3, 4, 3, 1],
            [3, 4, 0, 2], [3, 4, 2, 2], [3, 4, 1, 2], [3, 4, 1, 1], [3, 4, 1, 0],
            [3, 4, 0, 1], [3, 4, 0, 0], [3, 4, 2, 3], [3, 4, 3, 2], [3, 4, 3, 3],
            [3, 4, 3, 4], [3, 4, 4, 3], [3, 4, 4, 4], [1, 1, 2, 2], [1, 1, 2, 1],
            [1, 1, 1, 1], [1, 1, 1, 2], [1, 1, 2, 0], [1, 1, 3, 3], [1, 1, 0, 0],
            [1, 1, 1, 0], [1, 2, 2, 2], [1, 2, 2, 1], [1, 2, 1, 1], [1, 2, 1, 2],
            [1, 2, 2, 0], [1, 2, 3, 3], [1, 2, 0, 0], [1, 2, 1, 0]
        ]

        predefined_consequents = [
            [1, 1], [0, 1], [0, 1], [0, 1], [0, 2], [0, 2], [0, 1], [1, 0], [1, 0], [0, 1],
            [2, 1], [1, 0], [1, 1], [0, 1], [0, 1], [0, 1], [0, 2], [0, 2], [0, 1], [1, 0],
            [1, 1], [0, 1], [3, 0], [1, 0], [3, 1], [0, 1], [3, 1], [3, 0], [0, 1], [0, 1],
            [1, 1], [3, 0], [0, 1], [0, 2], [0, 2], [0, 3], [0, 3], [0, 3], [0, 1], [0, 3],
            [0, 3], [0, 1], [0, 1], [0, 3], [0, 3], [0, 1], [0, 3], [0, 2], [1, 1], [0, 2],
            [0, 2], [0, 1], [0, 1], [0, 1], [3, 0], [1, 0], [1, 1], [0, 1], [0, 1], [0, 1],
            [0, 2], [0, 2], [0, 1], [0, 1], [0, 1], [1, 1], [1, 1], [1, 1], [0, 3], [0, 3],
            [0, 3], [0, 2], [1, 0], [0, 3], [0, 2], [0, 3], [0, 1], [0, 3], [0, 1], [0, 3],
            [0, 3], [0, 3], [0, 2], [0, 3]
        ]

        self.rule_antecedents = torch.tensor(predefined_antecedents, device=self.device)
        self.rule_consequents = torch.tensor(predefined_consequents, device=self.device)

    def _precompute_fixed_tensors(self):
        """🚀 预计算所有固定张量"""
        print("🔄 预计算固定张量...")

        # 预计算输入隶属函数参数
        self.input_centers = self.input_mf_params[:, :, 0]  # [4, 5]
        self.input_widths = self.input_mf_params[:, :, 1]  # [4, 5]
        self.inv_widths_squared = -0.5 / (self.input_widths ** 2)  # [4, 5]

        # 预计算输出隶属函数参数
        self.output_centers = self.output_mf_params[:, :, 0]  # [2, 4]
        self.output_widths = self.output_mf_params[:, :, 1]  # [2, 4]
        self.output_inv_widths_squared = -0.5 / (self.output_widths ** 2)  # [2, 4]

        # 预计算解模糊化参数
        self.output_min = -100.0
        self.output_max = 800.0
        self.n_points = 301
        self.x_points = torch.linspace(self.output_min, self.output_max, self.n_points, device=self.device)
        self.dx = (self.output_max - self.output_min) / (self.n_points - 1)
        self.output_midpoint = (self.output_min + self.output_max) / 2
        self.min_rule_strength = 1e-6

        # 预计算规则评估的索引矩阵
        self.input_indices = torch.arange(self.n_inputs, device=self.device).unsqueeze(0).expand(self.n_rules, -1)

        print("✅ 预计算完成！")

    def _precompute_3d_matrices(self):
        """🎯 预计算3D张量格式的所有数据 - 完全消除循环"""
        print("🔄 预计算3D张量矩阵...")

        # 🚀 预计算所有输出变量的高斯函数矩阵 - 3D张量格式
        all_gaussians = []
        all_consequent_indices = []

        for output_idx in range(self.n_outputs):
            # 当前输出的所有规则后件索引: [n_rules]
            consequent_indices = self.rule_consequents[:, output_idx]  # [84]

            # 🚀 矢量化提取对应的中心值和宽度参数
            rule_centers = self.output_centers[output_idx][consequent_indices]  # [84]
            rule_inv_widths_squared = self.output_inv_widths_squared[output_idx][consequent_indices]  # [84]

            # 🎯 预计算所有高斯函数值在所有离散点上
            # self.x_points: [301], rule_centers: [84]
            # 广播计算: [301, 1] - [1, 84] = [301, 84]
            diff_squared = (self.x_points.unsqueeze(1) - rule_centers.unsqueeze(0)) ** 2

            # 🚀 预计算所有高斯函数: [301, 84] - 这是固定的！
            precomputed_gaussians = torch.exp(rule_inv_widths_squared.unsqueeze(0) * diff_squared)

            all_gaussians.append(precomputed_gaussians)
            all_consequent_indices.append(consequent_indices)

        # 🔥 关键优化：构建3D张量，避免后续所有循环
        self.all_precomputed_gaussians = torch.stack(all_gaussians, dim=0)  # [2, 301, 84]
        self.all_consequent_indices = torch.stack(all_consequent_indices, dim=0)  # [2, 84]


        # 🚀 预计算解模糊化所需的3D张量
        # x_points 扩展为适合批量计算的形状: [1, 301] -> [2, 301]
        self.x_points_3d = self.x_points.unsqueeze(0).expand(self.n_outputs, -1)  # [2, 301]

        print("✅ 3D张量矩阵预计算完成！")
        print(f"   - 3D高斯矩阵大小: [{self.n_outputs}, {self.n_points}, {self.n_rules}]")
        print(f"   - 总预计算数据量: {self.n_outputs * self.n_points * self.n_rules * 4 / 1024 / 1024:.2f} MB")

    def to_device(self, tensor):
        """确保张量在正确设备上"""
        if isinstance(tensor, torch.Tensor):
            return tensor.to(self.device)
        else:
            return torch.tensor(tensor, dtype=torch.float32, device=self.device)

    # 阶段1：模糊化
    def stage_1_fuzzification(self, inputs):
        """阶段1：模糊化 - 计算输入对所有隶属函数的隶属度"""
        inputs = self.to_device(inputs)
        diff = inputs.unsqueeze(1) - self.input_centers
        input_memberships = torch.exp(self.inv_widths_squared * (diff ** 2))
        return input_memberships

    # 阶段2：规则评估
    def stage_2_rule_evaluation(self, input_memberships):
        """阶段2：规则评估 - 计算所有规则的激活强度"""
        all_rule_memberships = input_memberships[self.input_indices, self.rule_antecedents]
        rule_strengths = torch.min(all_rule_memberships, dim=1)[0]
        return rule_strengths

    # 阶段3：截断 - 3D张量无循环版本
    def stage_3_clipping_3d(self, rule_strengths):
        """阶段3：截断 - 3D张量无循环超级优化版本"""
        # rule_strengths: [84]

        # 🔥 一行代码完成所有输出变量的截断！
        # all_precomputed_gaussians: [2, 301, 84]
        # rule_strengths: [84] -> [1, 1, 84] 广播到 [2, 301, 84]
        all_clipped_3d = torch.minimum(
            self.all_precomputed_gaussians,
            rule_strengths.unsqueeze(0).unsqueeze(0)
        )  # [2, 301, 84]

        return all_clipped_3d

    # 阶段4：聚合 - 3D张量无循环版本
    def stage_4_aggregation_3d(self, all_clipped_3d):
        """阶段4：聚合 - 3D张量无循环版本"""
        # all_clipped_3d: [2, 301, 84]

        # 🔥 一次性对所有输出变量聚合 - S-norm（沿规则维度取最大值）
        aggregated_3d = torch.max(all_clipped_3d, dim=2)[0]  # [2, 301]

        return aggregated_3d

    # 阶段5：解模糊 - 3D张量无循环版本
    def stage_5_defuzzification_3d(self, aggregated_3d):
        """阶段5：解模糊 - 3D张量无循环版本"""
        # aggregated_3d: [2, 301]

        # 🔥 一次性计算所有输出的重心
        numerator = torch.sum(aggregated_3d * self.x_points_3d * self.dx, dim=1)  # [2]
        denominator = torch.sum(aggregated_3d * self.dx, dim=1)  # [2]
        # 避免除零 - 矢量化处理
        denominator = torch.clamp(denominator, min=1e-8)
        crisp_outputs = numerator / denominator  # [2]

        # 限制输出范围
        #crisp_outputs = torch.clamp(crisp_outputs, self.output_min, self.output_max)

        return crisp_outputs

    # 🚀 超级优化的实时推理接口 - 完全无循环版本
    def real_time_inference_3d(self, sensor_data):
        """超级优化的3D张量无循环推理过程"""
        # 阶段1：模糊化
        input_memberships = self.stage_1_fuzzification(sensor_data)

        # 阶段2：规则评估
        rule_strengths = self.stage_2_rule_evaluation(input_memberships)

        # 阶段3-5：完全无循环的3D张量处理
        all_clipped_3d = self.stage_3_clipping_3d(rule_strengths)  # [2, 301, 84]
        aggregated_3d = self.stage_4_aggregation_3d(all_clipped_3d)  # [2, 301]
        outputs = self.stage_5_defuzzification_3d(aggregated_3d)  # [2]

        # 输出处理
        processed_outputs = outputs.cpu().numpy()

        return {
            'left_speed': float(processed_outputs[0]),
            'right_speed': float(processed_outputs[1]),
            'timestamp': time.time()
        }

    # 保持向后兼容的原始接口
    def real_time_inference(self, sensor_data):
        """标准接口 - 重定向到3D优化版本"""
        return self.real_time_inference_3d(sensor_data)

    # 🚀 优化的流水线系统
    def start_pipeline_3d(self):
        """启动3D张量优化的流水线处理"""
        self.pipeline_running = True

        stage_functions = [
            self._pipeline_worker_1,  # 模糊化
            self._pipeline_worker_2,  # 规则评估
            self._pipeline_worker_3_3d,  # 截断 (3D优化)
            self._pipeline_worker_4_3d,  # 聚合 (3D优化)
            self._pipeline_worker_5_3d  # 解模糊 (3D优化)
        ]

        for i, worker_func in enumerate(stage_functions):
            thread = threading.Thread(target=worker_func, name=f"Pipeline-3D-Stage-{i + 1}")
            thread.daemon = True
            thread.start()
            self.pipeline_threads.append(thread)

        print("🚀 3D张量无循环流水线系统已启动")

    def start_pipeline(self):
        """默认启动3D优化流水线"""
        self.start_pipeline_3d()

    def stop_pipeline(self):
        """停止流水线处理"""
        self.pipeline_running = False
        print("🛑 3D张量流水线系统已停止")

    def pipeline_input(self, sensor_data):
        """向流水线输入数据"""
        if len(self.stage_queues['fuzzification']) < self.stage_queues['fuzzification'].maxlen:
            self.stage_queues['fuzzification'].append({
                'data': sensor_data,
                'timestamp': time.time()
            })
            return True
        return False

    def get_pipeline_output(self):
        """从流水线获取输出"""
        if self.stage_queues['output']:
            return self.stage_queues['output'].popleft()
        return None

    # 流水线工作线程 - 前两个阶段保持不变
    def _pipeline_worker_1(self):
        """流水线工作线程1：模糊化"""
        while self.pipeline_running:
            if self.stage_queues['fuzzification']:
                item = self.stage_queues['fuzzification'].popleft()
                result = self.stage_1_fuzzification(item['data'])

                if len(self.stage_queues['rule_evaluation']) < self.stage_queues['rule_evaluation'].maxlen:
                    self.stage_queues['rule_evaluation'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_2(self):
        """流水线工作线程2：规则评估"""
        while self.pipeline_running:
            if self.stage_queues['rule_evaluation']:
                item = self.stage_queues['rule_evaluation'].popleft()
                result = self.stage_2_rule_evaluation(item['data'])

                if len(self.stage_queues['clipping']) < self.stage_queues['clipping'].maxlen:
                    self.stage_queues['clipping'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    # 🚀 3D张量优化的流水线工作线程
    def _pipeline_worker_3_3d(self):
        """流水线工作线程3：截断 (3D张量优化版本)"""
        while self.pipeline_running:
            if self.stage_queues['clipping']:
                item = self.stage_queues['clipping'].popleft()
                result = self.stage_3_clipping_3d(item['data'])

                if len(self.stage_queues['aggregation']) < self.stage_queues['aggregation'].maxlen:
                    self.stage_queues['aggregation'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_4_3d(self):
        """流水线工作线程4：聚合 (3D张量优化版本)"""
        while self.pipeline_running:
            if self.stage_queues['aggregation']:
                item = self.stage_queues['aggregation'].popleft()
                result = self.stage_4_aggregation_3d(item['data'])

                if len(self.stage_queues['defuzzification']) < self.stage_queues['defuzzification'].maxlen:
                    self.stage_queues['defuzzification'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_5_3d(self):
        """流水线工作线程5：解模糊 (3D张量优化版本)"""
        while self.pipeline_running:
            if self.stage_queues['defuzzification']:
                item = self.stage_queues['defuzzification'].popleft()
                result = self.stage_5_defuzzification_3d(item['data'])

                # 输出处理
                processed_outputs = result.cpu().numpy()
                final_result = {
                    'left_speed': float(processed_outputs[0]),
                    'right_speed': float(processed_outputs[1]),
                    'timestamp': item['timestamp']
                }

                if len(self.stage_queues['output']) < self.stage_queues['output'].maxlen:
                    self.stage_queues['output'].append(final_result)
            else:
                time.sleep(0.001)

    def benchmark_performance(self, n_iterations=1000000):
        """性能基准测试"""
        print(f"\n=== 3D张量优化性能基准测试 ({n_iterations} 次推理) ===")

        # 准备测试数据
        test_data = [1000, 616, 314, 200]

        # 预热
        for _ in range(10):
            self.real_time_inference_3d(test_data)

        # 同步GPU
        if self.device.type == 'cuda':
            torch.cuda.synchronize()

        # 开始计时
        start_time = time.time()

        for _ in range(n_iterations):
            result = self.real_time_inference_3d(test_data)

        # 同步GPU
        if self.device.type == 'cuda':
            torch.cuda.synchronize()

        end_time = time.time()

        # 计算性能指标
        total_time = end_time - start_time
        avg_time = total_time / n_iterations * 1000  # 毫秒
        throughput = n_iterations / total_time  # 推理/秒

        print(f"总时间: {total_time:.4f} 秒")
        print(f"平均推理时间: {avg_time:.4f} 毫秒")
        print(f"吞吐量: {throughput:.2f} 推理/秒")
        print(f"最后一次输出: left_speed={result['left_speed']:.2f}, right_speed={result['right_speed']:.2f}")


#使用示例
def main():
    print("=== 3D张量无循环超级优化流水线模糊推理系统 ===")

    # 创建系统
    fuzzy_system = RealTimeFuzzySystem(
        n_inputs=4, n_outputs=2, n_input_mfs=5,
        n_output_mfs=4, n_rules=84, use_gpu=True
    )

    # 单次推理测试
    print("\n=== 3D张量优化实时推理测试 ===")
    sensor_data = [1000, 616, 314, 200]
    result = fuzzy_system.real_time_inference_3d(sensor_data)

    print(f"传感器输入: {sensor_data}")
    print(f"控制输出: left_speed={result['left_speed']:.2f}, right_speed={result['right_speed']:.2f}")




if __name__ == "__main__":
    main()
