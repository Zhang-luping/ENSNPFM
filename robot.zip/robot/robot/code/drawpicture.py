# -*- coding: utf-8 -*-
from pathlib import Path

import matplotlib
import numpy as np
from matplotlib.ticker import FormatStrFormatter

# 生成图片时不需要桌面图形界面
matplotlib.use("Agg")
import matplotlib.pyplot as plt


OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

LEVELS = np.array(["L0", "L1", "L2", "L3", "L4"])
RUNS = np.arange(1, 6)

data_mae = np.array([
    [0.027184, 0.042694, 0.058767, 0.055437, 0.073120],
    [0.052455, 0.049049, 0.049035, 0.065158, 0.061948],
    [0.050292, 0.047032, 0.043487, 0.063003, 0.060748],
    [0.054260, 0.046081, 0.065137, 0.063302, 0.055781],
    [0.049739, 0.041159, 0.046873, 0.051441, 0.062221],
])

data_rmse = np.array([
    [0.042594, 0.089688, 0.135660, 0.143759, 0.172066],
    [0.061115, 0.098497, 0.124083, 0.146764, 0.164035],
    [0.057294, 0.092883, 0.115738, 0.152412, 0.164258],
    [0.066401, 0.096072, 0.133273, 0.154627, 0.160351],
    [0.057335, 0.090400, 0.119369, 0.143594, 0.178756],
])


def style_axis(ax):
    ax.set_facecolor("#F8FAFC")
    ax.grid(True, color="#CBD5E1", alpha=0.55, linewidth=0.7)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(labelsize=11)


def plot_surface(ax, data, title, z_label, cmap_name):
    x, y = np.meshgrid(np.arange(len(LEVELS)), RUNS)

    surface = ax.plot_surface(
        x, y, data,
        cmap=matplotlib.colormaps[cmap_name],
        edgecolor="white",
        linewidth=0.6,
        antialiased=True,
        alpha=0.96,
    )

    ax.set_title(title, pad=16, fontsize=15, fontweight="bold")
    ax.set_xlabel("Level", labelpad=9, fontweight="bold")
    ax.set_ylabel("Run", labelpad=9, fontweight="bold")
    ax.set_zlabel(z_label, labelpad=10, fontweight="bold")

    ax.set_xticks(np.arange(len(LEVELS)))
    ax.set_xticklabels(LEVELS)
    ax.set_yticks(RUNS)
    ax.view_init(elev=28, azim=-53)
    ax.zaxis.set_major_formatter(FormatStrFormatter("%.02f"))

    ax.figure.colorbar(surface, ax=ax, shrink=0.61, pad=0.08)


def plot_runs_and_mean(ax, data, title, y_label, color):
    x = np.arange(len(LEVELS))
    mean = data.mean(axis=0)
    std = data.std(axis=0, ddof=1)

    # 5 次重复实验的曲线
    for values in data:
        ax.plot(x, values, color=color, alpha=0.25, linewidth=1.25)
        ax.scatter(x, values, color=color, alpha=0.42, s=23, zorder=3)

    # 均值和标准差范围
    ax.fill_between(
        x, mean - std, mean + std,
        color=color, alpha=0.16, label="Mean ± 1 SD"
    )
    ax.plot(
        x, mean, color=color, marker="o", markersize=7,
        linewidth=2.7, label="Mean", zorder=4
    )

    # 标注均值
    for index, value in enumerate(mean):
        ax.annotate(
            f"{value:.3f}",
            (index, value),
            xytext=(0, 10),
            textcoords="offset points",
            ha="center",
            fontsize=9,
            color="#1E293B",
            fontweight="bold",
        )

    style_axis(ax)
    ax.set_title(title, fontsize=15, fontweight="bold", pad=12)
    ax.set_xticks(x)
    ax.set_xticklabels(LEVELS, fontweight="bold")
    ax.set_xlabel("Level", fontweight="bold")
    ax.set_ylabel(y_label, fontweight="bold")
    ax.yaxis.set_major_formatter(FormatStrFormatter("%.02f"))
    ax.legend(frameon=False, loc="upper left")


plt.rcParams.update({
    "font.family": ["Microsoft YaHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "savefig.facecolor": "white",
})

fig = plt.figure(figsize=(18, 13), facecolor="white")
fig.suptitle(
    "Performance across levels (5 repeated runs)",
    fontsize=21,
    fontweight="bold",
    y=0.97,
)

plot_surface(
    fig.add_subplot(2, 2, 1, projection="3d"),
    data_mae,
    "MAE — repeated-run surface",
    "MAE",
    "YlOrRd",
)

plot_surface(
    fig.add_subplot(2, 2, 2, projection="3d"),
    data_rmse,
    "RMSE — repeated-run surface",
    "RMSE",
    "Blues",
)

plot_runs_and_mean(
    fig.add_subplot(2, 2, 3),
    data_mae,
    "MAE by level",
    "MAE",
    "#D35400",
)

plot_runs_and_mean(
    fig.add_subplot(2, 2, 4),
    data_rmse,
    "RMSE by level",
    "RMSE",
    "#1769AA",
)

fig.subplots_adjust(
    left=0.05, right=0.96,
    bottom=0.06, top=0.91,
    wspace=0.19, hspace=0.24,
)

fig.savefig(OUTPUT_DIR / "mae_rmse_levels.png", dpi=300, bbox_inches="tight")
fig.savefig(OUTPUT_DIR / "mae_rmse_levels.pdf", bbox_inches="tight")

print("绘图完成。")