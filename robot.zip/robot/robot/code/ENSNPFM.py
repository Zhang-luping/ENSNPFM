#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ENSNPFM MobileSim experiment with reproducible Gaussian sensor noise.

Change only NOISE_LEVEL_PERCENT and EXPERIMENT_REPEAT before each run.
Each repeat uses a fixed, distinct random seed and writes it into the filename.
"""

import csv
import random
import sys
import threading
import time

# ARIA Python binding location.
ARIA_PYTHON_PATH = r"C:\robot\ARIA\python3"
if ARIA_PYTHON_PATH not in sys.path:
    sys.path.append(ARIA_PYTHON_PATH)

try:
    import AriaPy
    from AriaPy import ArSonarDevice
except ImportError as exc:
    raise SystemExit(f"错误：无法导入 AriaPy 模块：{exc}") from exc

try:
    import keyboard
except ImportError as exc:
    raise SystemExit("错误：请先安装 keyboard 模块（pip install keyboard）。") from exc

try:
    from ennp_RealTimeFuzzySystem_im import ennp_RealTimeFuzzySystem_im
except ImportError as exc:
    raise SystemExit(
        "错误：无法导入 ennp_RealTimeFuzzySystem_im，请确认该文件位于当前目录或 Python 路径中。"
    ) from exc


# ===================== 实验设置：每次只修改这两项 =====================
# 可选值：0.0、1.0、2.0、3.0、4.0、5.0，单位为百分比。
NOISE_LEVEL_PERCENT = 0.0

# 当前噪声水平下的第几次独立重复实验：1、2、3、4 或 5。
EXPERIMENT_REPEAT = 1
# ======================================================================

# 每个“噪声水平 × 重复次数”组合都有可复现的种子。
NOISE_SEEDS = {
    0.0: (10001, 10002, 10003, 10004, 10005),
    1.0: (10001, 10002, 10003, 10004, 10005),
    2.0: (10001, 10002, 10003, 10004, 10005),
    3.0: (10001, 10002, 10003, 10004, 10005),
    4.0: (10001, 10002, 10003, 10004, 10005),
    5.0: (10001, 10002, 10003, 10004, 10005),
}

if NOISE_LEVEL_PERCENT not in NOISE_SEEDS:
    raise ValueError(f"不支持的噪声水平：{NOISE_LEVEL_PERCENT}%")
if not 1 <= EXPERIMENT_REPEAT <= 5:
    raise ValueError("EXPERIMENT_REPEAT 必须为 1 至 5。")

RANDOM_SEED = NOISE_SEEDS[NOISE_LEVEL_PERCENT][EXPERIMENT_REPEAT - 1]
NOISE_PERCENT = NOISE_LEVEL_PERCENT / 100.0
RNG = random.Random(RANDOM_SEED)  # 只在程序开始时创建一次，绝不能放入循环。

running = True


def key_press_handler(event):
    """Press Q to stop one run and save its CSV file."""
    global running
    if event.name and event.name.lower() == "q":
        print("检测到 Q 键，准备停止程序…")
        running = False


def start_keyboard_listener():
    thread = threading.Thread(
        target=lambda: keyboard.on_press(key_press_handler), daemon=True
    )
    thread.start()
    return thread


def connect_robot():
    print("创建机器人对象…")
    robot = AriaPy.ArRobot()
    connection = AriaPy.ArTcpConnection()
    connection.setPort("localhost", 8101)
    robot.setDeviceConnection(connection)

    print("设置机器人连接…")
    if not robot.blockingConnect():
        raise RuntimeError("错误：无法连接到 MobileSim 仿真机器人。")
    robot.runAsync(True)
    # Keep Python references alive for the complete experiment.  ARIA retains
    # raw C++ pointers here; allowing either wrapper to be garbage-collected
    # can close the socket or leave the robot with a dangling sonar pointer.
    sonar = ArSonarDevice()
    robot.addRangeDevice(sonar)
    robot.enableMotors()
    print("机器人初始化完成")
    return robot, connection, sonar


def read_noisy_sonars(robot):
    """Apply multiplicative Gaussian noise before the original offset and cap."""
    readings = []
    for index in range(robot.getNumSonar()):
        raw_reading = round(robot.getSonarReading(index).getRange())
        noise = RNG.gauss(0.0, NOISE_PERCENT)
        noisy_reading = round(raw_reading * (1.0 + noise))
        reading = noisy_reading - 100
        if reading > 1000:
            reading = 1000
        readings.append(reading)
    return readings


def main():
    print("成功导入 AriaPy 模块")
    print(
        f"噪声配置：{NOISE_LEVEL_PERCENT:.1f}% | "
        f"第 {EXPERIMENT_REPEAT} 次 | 随机种子：{RANDOM_SEED}"
    )
    start_keyboard_listener()
    print("按 Q 键可停止程序并保存数据")

    # connection and sonar are deliberately retained until shutdown.
    robot, connection, sonar = connect_robot()
    fuzzy_system = ennp_RealTimeFuzzySystem_im(
        n_inputs=3,
        n_outputs=2,
        n_input_mfs=3,
        n_output_mfs=3,
        n_rules=7,
        use_gpu=True,
        R=200,
        rf=250,
        Ts=1,
    )

    samples = []
    last_speed = 0.0
    last_angle_speed = 0.0
    start_time = time.perf_counter()

    try:
        while running:
            cycle_start = time.perf_counter()
            sonar_readings = read_noisy_sonars(robot)
            if len(sonar_readings) < 4:
                raise RuntimeError("ENSNPFM 至少需要 4 个超声波传感器读数。")

            # Preserve the source model's sensor order.
            sensor_data = [sonar_readings[3], sonar_readings[2], sonar_readings[0]]
            result = fuzzy_system.real_time_inference_dynamic_3d(sensor_data)
            left_speed = result["left_speed"]
            right_speed = result["right_speed"]
            inference_end = time.perf_counter()

            # Preserve the original script's wheel-command order.
            robot.lock()
            try:
                robot.setVel2(right_speed, left_speed)
            finally:
                robot.unlock()

            time.sleep(0.001)
            robot.lock()
            try:
                robot_left_speed = robot.getLeftVel()
                robot_right_speed = robot.getRightVel()
                robot_trans_speed = robot.getVel()
                robot_rot_speed = robot.getRotVel()
                x_position = robot.getX()
                y_position = robot.getY()
                pose = robot.getPose()
            finally:
                robot.unlock()

            cycle_end = time.perf_counter()
            elapsed = cycle_end - cycle_start
            if elapsed > 0:
                trans_accel = (robot_trans_speed - last_speed) / elapsed
                angle_accel = (robot_rot_speed - last_angle_speed) / elapsed
            else:
                trans_accel = 0.0
                angle_accel = 0.0
            last_speed = robot_trans_speed
            last_angle_speed = robot_rot_speed

            # Keep the original 29-column CSV layout for compatibility.
            samples.append(
                sonar_readings
                + [
                    left_speed,                         # C17: model leftSpeed
                    right_speed,                        # C18: model rightSpeed
                    robot_left_speed,                   # C19: actual left-wheel speed
                    robot_right_speed,                  # C20: actual right-wheel speed
                    robot_trans_speed,                  # C21: actual linear speed
                    robot_rot_speed,                    # C22: actual rotational speed
                    trans_accel,                        # C23: linear acceleration
                    angle_accel,                        # C24: rotational acceleration
                    cycle_end - start_time,             # C25: elapsed experiment time
                    inference_end - cycle_start,        # C26: sensing + inference time
                    x_position,                         # C27: X position
                    y_position,                         # C28: Y position
                    pose,                               # C29: pose text
                ]
            )
    finally:
        robot.lock()
        try:
            robot.setVel2(0, 0)
            robot.disableMotors()
        finally:
            robot.unlock()
        robot.stopRunning()
        robot.disconnect()

        noise_name = f"{NOISE_LEVEL_PERCENT:.1f}".replace(".", "_")
        file_name = (
            f"office_{noise_name}pct_seed_{RANDOM_SEED}_"
            f"第{EXPERIMENT_REPEAT}次.csv"
        )
        with open(file_name, "w", newline="", encoding="utf-8-sig") as csv_file:
            csv.writer(csv_file).writerows(samples)
        print(f"实验数据已保存：{file_name}")


if __name__ == "__main__":
    main()
