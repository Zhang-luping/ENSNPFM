# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
from typing import Tuple, List, Optional
import queue
import threading
import time
from collections import deque
import math


class ennp_RealTimeFuzzySystem:
    """实时流水线模糊推理系统 - 动态模糊化 + 3D张量无循环优化版本"""

    def __init__(self, n_inputs=3, n_outputs=2, n_input_mfs=3, n_output_mfs=4, n_rules=8,
                 use_gpu=True, R=220, rf=300, Ts=50):
        self.n_inputs = n_inputs  # 改为3个输入：s4, s5, s7
        self.n_outputs = n_outputs
        self.n_input_mfs = n_input_mfs  # 每个输入3个模糊集
        self.n_output_mfs = n_output_mfs
        self.n_rules = n_rules  # 改为8条规则

        # 动态参数
        self.R = R
        self.rf = rf
        self.Ts = Ts
        self.cos_80 = math.cos(math.radians(80))
        self.cos_60 = math.cos(math.radians(60))

        # 设备选择
        if use_gpu and torch.cuda.is_available():
            self.device = torch.device('cuda')
            print(f"使用GPU: {torch.cuda.get_device_name()}")
        else:
            self.device = torch.device('cpu')
            print("使用CPU")

        # 历史数据存储
        self.sensor_history = {
            's4': deque(maxlen=3),
            's5': deque(maxlen=3),
            's7': deque(maxlen=3)
        }

        # 初始化参数
        self._init_output_membership_functions()
        self._init_fuzzy_rules()

        # 🚀 预计算动态参数相关的常量张量
        self._precompute_dynamic_constants()

        # 🚀 关键优化：预计算所有固定张量
        self._precompute_fixed_tensors()

        # 🎯 预计算3D张量格式的所有数据
        self._precompute_3d_matrices()

        # 🔄 流水线队列系统
        self.stage_queues = {
            'fuzzification': deque(maxlen=10),
            'rule_evaluation': deque(maxlen=10),
            'clipping': deque(maxlen=10),
            'aggregation': deque(maxlen=10),
            'defuzzification': deque(maxlen=10),
            'output': deque(maxlen=10)
        }

        # 流水线控制
        self.pipeline_running = False
        self.pipeline_threads = []

    def _precompute_dynamic_constants(self):
        """预计算动态参数相关的常量张量"""
        print("🔄 预计算动态参数常量张量...")

        # 角度因子张量
        self.angle_factors_tensor = torch.tensor([self.cos_80, self.cos_60, 1.0],
                                                 dtype=torch.float32, device=self.device)

        # 参考基准值张量
        self.ref_base_tensor = (self.R + self.rf) / self.angle_factors_tensor

        # 中心值基准张量
        self.center_bases_tensor = self.ref_base_tensor - self.R

        # 中心值偏移张量
        self.centers_offset_tensor = torch.tensor([-3, 0, 3], dtype=torch.float32, device=self.device)

        # 阈值张量
        self.Ts_tensor = torch.tensor(self.Ts, dtype=torch.float32, device=self.device)

        # 历史数据矩阵缓存
        self._history_matrix = torch.zeros(3, 3, dtype=torch.float32, device=self.device)

        print("✅ 动态参数常量预计算完成！")

    def _init_output_membership_functions(self):
        """初始化输出变量的隶属函数参数"""
        self.output_mf_params = torch.zeros(self.n_outputs, self.n_output_mfs, 2, device=self.device)

        output_centers_matrix = [
            [10, 300, 500, 650],  # leftspeed
            [10, 300, 500, 650]  # rightspeed
        ]

        output_widths_matrix = [
            [75, 75, 75, 40],  # leftspeed宽度
            [75, 75, 75, 40]  # rightspeed宽度
        ]

        self.output_mf_params[:, :, 0] = torch.tensor(output_centers_matrix, device=self.device)
        self.output_mf_params[:, :, 1] = torch.tensor(output_widths_matrix, device=self.device)

    def _init_fuzzy_rules(self):
        """初始化8条模糊规则"""
        predefined_antecedents = [
            [0, 1, 1],  # s4.near, s5.normal, s7.normal
            [0, 0, 1],  # s4.near, s5.near, s7.normal
            [1, 2, 2],  # s4.normal, s5.far, s7.far
            [1, 1, 1],  # s4.normal, s5.normal, s7.normal
            [2, 2, 2],  # s4.far, s5.far, s7.far
            #[2, 0, 0],  # s4.far, s5.near, s7.near
            [0, 0, 0],  # s4.near, s5.near, s7.near
            [1, 0, 0],  # s4.normal, s5.near, s7.near
        ]

        predefined_consequents = [
            [0, 1],  # 左转
            [0, 2],  # 左转
            [1, 0],  # 右转
            [1, 1],  # 直行
            [1, 0],  # 右转
            [0, 1],  # 左转
            [0, 1],  # 左转
            #[0, 1],  # 左转
        ]

        self.rule_antecedents = torch.tensor(predefined_antecedents, device=self.device)
        self.rule_consequents = torch.tensor(predefined_consequents, device=self.device)

    def _precompute_fixed_tensors(self):
        """🚀 预计算所有固定张量"""
        print("🔄 预计算固定张量...")

        # 预计算输出隶属函数参数
        self.output_centers = self.output_mf_params[:, :, 0]  # [2, 4]
        self.output_widths = self.output_mf_params[:, :, 1]  # [2, 4]
        self.output_inv_widths_squared = -0.5 / (self.output_widths ** 2)  # [2, 4]

        # 预计算解模糊化参数
        self.output_min = -100.0
        self.output_max = 800.0
        self.n_points = 301
        self.x_points = torch.linspace(self.output_min, self.output_max, self.n_points, device=self.device)
        self.dx = (self.output_max - self.output_min) / (self.n_points - 1)
        self.output_midpoint = (self.output_min + self.output_max) / 2
        self.min_rule_strength = 1e-6

        # 预计算规则评估的索引矩阵
        self.input_indices = torch.arange(self.n_inputs, device=self.device).unsqueeze(0).expand(self.n_rules, -1)

        print("✅ 预计算完成！")

    def _precompute_3d_matrices(self):
        """🎯 预计算3D张量格式的所有数据 - 完全消除循环"""
        print("🔄 预计算3D张量矩阵...")

        # 🚀 预计算所有输出变量的高斯函数矩阵 - 3D张量格式
        all_gaussians = []
        all_consequent_indices = []

        for output_idx in range(self.n_outputs):
            # 当前输出的所有规则后件索引: [n_rules]
            consequent_indices = self.rule_consequents[:, output_idx]  # [8]

            # 🚀 矢量化提取对应的中心值和宽度参数
            rule_centers = self.output_centers[output_idx][consequent_indices]  # [8]
            rule_inv_widths_squared = self.output_inv_widths_squared[output_idx][consequent_indices]  # [8]

            # 🎯 预计算所有高斯函数值在所有离散点上
            # self.x_points: [301], rule_centers: [8]
            # 广播计算: [301, 1] - [1, 8] = [301, 8]
            diff_squared = (self.x_points.unsqueeze(1) - rule_centers.unsqueeze(0)) ** 2

            # 🚀 预计算所有高斯函数: [301, 8] - 这是固定的！
            precomputed_gaussians = torch.exp(rule_inv_widths_squared.unsqueeze(0) * diff_squared)

            all_gaussians.append(precomputed_gaussians)
            all_consequent_indices.append(consequent_indices)

        # 🔥 关键优化：构建3D张量，避免后续所有循环
        self.all_precomputed_gaussians = torch.stack(all_gaussians, dim=0)  # [2, 301, 8]
        self.all_consequent_indices = torch.stack(all_consequent_indices, dim=0)  # [2, 8]

        # 🚀 预计算解模糊化所需的3D张量
        self.x_points_3d = self.x_points.unsqueeze(0).expand(self.n_outputs, -1)  # [2, 301]

        print("✅ 3D张量矩阵预计算完成！")
        print(f"   - 3D高斯矩阵大小: [{self.n_outputs}, {self.n_points}, {self.n_rules}]")
        print(f"   - 总预计算数据量: {self.n_outputs * self.n_points * self.n_rules * 4 / 1024 / 1024:.2f} MB")

    def update_sensor_history(self, sensor_data):
        """更新传感器历史数据"""
        s4, s5, s7 = sensor_data
        self.sensor_history['s4'].append(s4)
        self.sensor_history['s5'].append(s5)
        self.sensor_history['s7'].append(s7)

    def _build_history_matrix(self):
        """构建历史数据矩阵 - 张量化版本"""
        sensor_keys = ['s4', 's5', 's7']
        for i, key in enumerate(sensor_keys):
            history_list = list(self.sensor_history[key])
            # 用0填充不足的历史数据
            while len(history_list) < 3:
                history_list.insert(0, 0.0)
            self._history_matrix[i] = torch.tensor(history_list, dtype=torch.float32, device=self.device)

        return self._history_matrix

    def _parallel_std(self, history_matrix):
        """优化的并行标准差计算"""
        n_sensors, n_history = history_matrix.shape

        if n_history < 2:
            return torch.zeros(n_sensors, dtype=torch.float32, device=self.device)

        # 并行计算均值
        mean_vals = torch.mean(history_matrix, dim=1, keepdim=True)  # [3, 1]

        # 并行计算方差
        variance = torch.sum((history_matrix - mean_vals) ** 2, dim=1) / (n_history - 1)  # [3]

        # 并行计算标准差，并处理数值稳定性
        std_values = torch.sqrt(torch.clamp(variance, min=1e-8))  # [3]

        # 处理NaN值
        std_values = torch.where(torch.isnan(std_values),
                                 torch.zeros_like(std_values),
                                 std_values)

        return std_values

    def calculate_dynamic_parameters_tensor(self, sensor_data):
        """完全张量化的动态参数计算"""
        # 转换输入为张量
        current_values = torch.tensor(sensor_data, dtype=torch.float32, device=self.device)

        # 构建历史数据矩阵
        history_matrix = self._build_history_matrix()  # [3, 3]

        # 一次性计算所有参数
        std_values = self._parallel_std(history_matrix)  # [3]
        e_values =6 * torch.maximum(self.Ts_tensor, std_values)  # [3]

        # 并行计算参考值
        ref_values = torch.abs(current_values - self.ref_base_tensor)  # [3]

        # 并行计算方差 - 使用条件选择
        sigma_e = e_values / 6  # [3]
        sigma_ref = ref_values / 3  # [3]
        sigma_values = torch.where(e_values > ref_values, sigma_e, sigma_ref)  # [3]

        # 一次性生成所有中心值 - 使用广播
        all_centers = self.center_bases_tensor.unsqueeze(1) + \
                      sigma_values.unsqueeze(1) * self.centers_offset_tensor.unsqueeze(0)  # [3, 3]

        return all_centers, sigma_values  # 返回张量而不是字典，保持高效

    def to_device(self, tensor):
        """确保张量在正确设备上"""
        if isinstance(tensor, torch.Tensor):
            return tensor.to(self.device)
        else:
            return torch.tensor(tensor, dtype=torch.float32, device=self.device)

    # 🚀 阶段1：动态模糊化 - 完全张量化版本
    def stage_1_dynamic_fuzzification_tensor(self, inputs):
        """阶段1：动态模糊化 - 完全张量化无循环版本"""
        inputs = self.to_device(inputs)

        # 更新历史数据
        self.update_sensor_history(inputs.cpu().tolist())

        # 计算动态参数 - 完全张量化
        dynamic_centers, dynamic_sigmas = self.calculate_dynamic_parameters_tensor(inputs.cpu().tolist())

        # 🚀 完全张量化的隶属度计算
        # inputs: [3], dynamic_centers: [3, 3], dynamic_sigmas: [3]

        # 广播计算所有隶属度: [3, 1] - [3, 3] = [3, 3]
        diff = inputs.unsqueeze(1) - dynamic_centers  # [3, 3]

        # 计算高斯隶属函数: [3, 3]
        input_memberships = torch.exp(-0.5 * (diff / dynamic_sigmas.unsqueeze(1)) ** 2)

        return input_memberships, dynamic_centers, dynamic_sigmas

    # 阶段2：规则评估 - 保持原有的高效实现
    def stage_2_rule_evaluation(self, input_memberships):
        """阶段2：规则评估 - 计算所有规则的激活强度"""
        # input_memberships: [3, 3] - 3个传感器，每个3个模糊集

        # 🚀 高效的张量化规则评估
        all_rule_memberships = input_memberships[self.input_indices, self.rule_antecedents]  # [8, 3]
        rule_strengths = torch.min(all_rule_memberships, dim=1)[0]  # [8]
        return rule_strengths

    # 阶段3-5：保持原有的3D张量优化实现
    def stage_3_clipping_3d(self, rule_strengths):
        """阶段3：截断 - 3D张量无循环超级优化版本"""
        # 🔥 一行代码完成所有输出变量的截断！
        all_clipped_3d = torch.minimum(
            self.all_precomputed_gaussians,
            rule_strengths.unsqueeze(0).unsqueeze(0)
        )  # [2, 301, 8]
        return all_clipped_3d

    def stage_4_aggregation_3d(self, all_clipped_3d):
        """阶段4：聚合 - 3D张量无循环版本"""
        # 🔥 一次性对所有输出变量聚合
        aggregated_3d = torch.max(all_clipped_3d, dim=2)[0]  # [2, 301]
        return aggregated_3d

    def stage_5_defuzzification_3d(self, aggregated_3d):
        """阶段5：解模糊 - 3D张量无循环版本"""
        # 🔥 一次性计算所有输出的重心
        numerator = torch.sum(aggregated_3d * self.x_points_3d * self.dx, dim=1)  # [2]
        denominator = torch.sum(aggregated_3d * self.dx, dim=1)  # [2]
        denominator = torch.clamp(denominator, min=1e-8)
        crisp_outputs = numerator / denominator  # [2]
        return crisp_outputs

    # 🚀 超级优化的动态模糊化实时推理接口
    def real_time_inference_dynamic_3d(self, sensor_data):
        """动态模糊化 + 3D张量无循环推理过程"""
        # 阶段1：动态模糊化
        input_memberships, dynamic_centers, dynamic_sigmas = self.stage_1_dynamic_fuzzification_tensor(sensor_data)

        # 阶段2：规则评估
        rule_strengths = self.stage_2_rule_evaluation(input_memberships)

        # 阶段3-5：完全无循环的3D张量处理
        all_clipped_3d = self.stage_3_clipping_3d(rule_strengths)  # [2, 301, 8]
        aggregated_3d = self.stage_4_aggregation_3d(all_clipped_3d)  # [2, 301]
        outputs = self.stage_5_defuzzification_3d(aggregated_3d)  # [2]

        # 输出处理
        processed_outputs = outputs.cpu().numpy()

        return {
            'left_speed': float(processed_outputs[0]),
            'right_speed': float(processed_outputs[1]),
            'timestamp': time.time(),
            'dynamic_params': {
                'centers': dynamic_centers.cpu().tolist(),
                'sigmas': dynamic_sigmas.cpu().tolist()
            }
        }

    # 保持向后兼容
    def real_time_inference(self, sensor_data):
        """默认使用动态模糊化3D优化版本"""
        return self.real_time_inference_dynamic_3d(sensor_data)

    def benchmark_performance(self, n_iterations=100000):
        """性能基准测试"""
        print(f"\n=== 动态模糊化3D张量优化性能基准测试 ({n_iterations} 次推理) ===")

        # 准备测试数据
        test_data = [400, 350, 250]  # s4, s5, s7

        # 预热
        for _ in range(10):
            self.real_time_inference_dynamic_3d(test_data)

        # 同步GPU
        if self.device.type == 'cuda':
            torch.cuda.synchronize()

        # 开始计时
        start_time = time.time()

        for i in range(n_iterations):
            # 模拟传感器数据变化
            test_data_varied = [
                test_data[0] + np.sin(i * 0.01) * 50,
                test_data[1] + np.cos(i * 0.01) * 30,
                test_data[2] + np.sin(i * 0.02) * 40
            ]
            result = self.real_time_inference_dynamic_3d(test_data_varied)

        # 同步GPU
        if self.device.type == 'cuda':
            torch.cuda.synchronize()

        end_time = time.time()

        # 计算性能指标
        total_time = end_time - start_time
        avg_time = total_time / n_iterations * 1000  # 毫秒
        throughput = n_iterations / total_time  # 推理/秒

        print(f"总时间: {total_time:.4f} 秒")
        print(f"平均推理时间: {avg_time:.4f} 毫秒")
        print(f"吞吐量: {throughput:.2f} 推理/秒")
        print(f"最后一次输出: left_speed={result['left_speed']:.2f}, right_speed={result['right_speed']:.2f}")


#使用示例
# def main():
#     print("=== 动态模糊化 + 3D张量无循环超级优化流水线模糊推理系统 ===")
#
#     # 创建系统
#     fuzzy_system = ennp_RealTimeFuzzySystem(
#         n_inputs=3, n_outputs=2, n_input_mfs=3,
#         n_output_mfs=4, n_rules=8, use_gpu=False,
#         R=220, rf=300, Ts=50
#     )
#
#     # 单次推理测试
#     print("\n=== 动态模糊化3D张量优化实时推理测试 ===")
#     sensor_data = [400, 350, 250]  # s4, s5, s7
#     result = fuzzy_system.real_time_inference_dynamic_3d(sensor_data)
#
#     print(f"传感器输入: s4={sensor_data[0]}, s5={sensor_data[1]}, s7={sensor_data[2]}")
#     print(f"控制输出: left_speed={result['left_speed']:.2f}, right_speed={result['right_speed']:.2f}")
#
#     # 显示动态参数
#     if 'dynamic_params' in result:
#         print("\n动态参数:")
#         centers = result['dynamic_params']['centers']
#         sigmas = result['dynamic_params']['sigmas']
#         sensors = ['s4', 's5', 's7']
#         for i, sensor in enumerate(sensors):
#             print(f"  {sensor}: centers={[f'{c:.2f}' for c in centers[i]]}, sigma={sigmas[i]:.2f}")
#
#     # 性能测试
#     fuzzy_system.benchmark_performance(1000)
#
#
# if __name__ == "__main__":
#     main()
