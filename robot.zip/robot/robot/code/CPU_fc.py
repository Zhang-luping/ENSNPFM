# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
from typing import Tuple, List, Optional
import queue
import threading
import time
from collections import deque


class RealTimeFuzzySystem:
    """实时流水线模糊推理系统 - 预计算优化版本"""

    def __init__(self, n_inputs=4, n_outputs=2, n_input_mfs=5, n_output_mfs=4, n_rules=84, use_gpu=True):
        self.n_inputs = n_inputs
        self.n_outputs = n_outputs
        self.n_input_mfs = n_input_mfs
        self.n_output_mfs = n_output_mfs
        self.n_rules = n_rules

        # 设备选择
        if use_gpu and torch.cuda.is_available():
            self.device = torch.device('cuda')
            print(f"使用GPU: {torch.cuda.get_device_name()}")
        else:
            self.device = torch.device('cpu')
            print("使用CPU")

        # 初始化参数
        self._init_membership_functions()
        self._init_fuzzy_rules()

        # 🚀 关键优化：预计算所有固定张量
        self._precompute_fixed_tensors()

        # 🔄 流水线队列系统 - 5个阶段
        self.stage_queues = {
            'fuzzification': deque(maxlen=10),
            'rule_evaluation': deque(maxlen=10),
            'aggregation': deque(maxlen=10),
            'defuzzification': deque(maxlen=10),
            'output': deque(maxlen=10)
        }

        # 流水线控制
        self.pipeline_running = False
        self.pipeline_threads = []

    def _init_membership_functions(self):
        """初始化隶属函数参数"""
        # 输入变量的隶属函数参数
        self.input_mf_params = torch.zeros(self.n_inputs, self.n_input_mfs, 2, device=self.device)

        centers_matrix = [
            [150, 300, 450, 650, 900],  # S4
            [100, 300, 500, 700, 900],  # S5
            [50, 250, 400, 600, 850],  # S6
            [50, 200, 300, 500, 850]  # S7
        ]

        widths_matrix = [
            [75, 125, 150, 75, 50],  # S4宽度
            [50, 125, 100, 100, 50],  # S5宽度
            [50, 100, 75, 100, 50],  # S6宽度
            [50, 100, 75, 125, 50]  # S7宽度
        ]

        self.input_mf_params[:, :, 0] = torch.tensor(centers_matrix, device=self.device)
        self.input_mf_params[:, :, 1] = torch.tensor(widths_matrix, device=self.device)

        # 输出变量的隶属函数参数
        self.output_mf_params = torch.zeros(self.n_outputs, self.n_output_mfs, 2, device=self.device)

        output_centers_matrix = [
            [10, 300, 500, 650],  # leftspeed
            [10, 300, 500, 650]  # rightspeed
        ]

        output_widths_matrix = [
            [75, 100, 100, 75],  # leftspeed宽度
            [75, 100, 100, 75]  # rightspeed宽度
        ]

        self.output_mf_params[:, :, 0] = torch.tensor(output_centers_matrix, device=self.device)
        self.output_mf_params[:, :, 1] = torch.tensor(output_widths_matrix, device=self.device)

    def _init_fuzzy_rules(self):
        """初始化84条模糊规则"""
        predefined_antecedents = [
            [4, 4, 2, 2], [4, 4, 1, 2], [4, 4, 1, 1], [4, 4, 1, 0], [4, 4, 0, 1],
            [4, 4, 0, 0], [4, 4, 2, 3], [4, 4, 3, 2], [4, 4, 3, 3], [4, 4, 3, 4],
            [4, 4, 4, 3], [4, 4, 4, 4], [4, 3, 2, 2], [4, 3, 1, 2], [4, 3, 1, 1],
            [4, 3, 1, 0], [4, 3, 0, 1], [4, 3, 0, 0], [4, 3, 2, 3], [4, 3, 3, 2],
            [4, 3, 3, 3], [4, 3, 3, 4], [4, 3, 4, 3], [4, 3, 4, 4], [4, 4, 3, 1],
            [4, 4, 4, 0], [4, 3, 4, 0], [4, 3, 3, 1], [4, 4, 3, 0], [4, 4, 3, 1],
            [4, 4, 4, 1], [4, 4, 4, 1], [2, 2, 2, 2], [2, 2, 2, 1], [2, 2, 2, 0],
            [2, 2, 1, 1], [2, 2, 1, 2], [2, 2, 1, 0], [2, 2, 2, 0], [2, 2, 3, 3],
            [2, 2, 0, 0], [2, 2, 1, 0], [2, 1, 2, 2], [2, 1, 2, 1], [2, 1, 2, 0],
            [2, 1, 1, 1], [2, 1, 1, 2], [2, 1, 1, 0], [2, 1, 2, 0], [2, 1, 3, 3],
            [2, 1, 0, 0], [2, 1, 1, 0], [3, 4, 3, 1], [3, 4, 4, 0], [3, 4, 3, 1],
            [3, 4, 0, 2], [3, 4, 2, 2], [3, 4, 1, 2], [3, 4, 1, 1], [3, 4, 1, 0],
            [3, 4, 0, 1], [3, 4, 0, 0], [3, 4, 2, 3], [3, 4, 3, 2], [3, 4, 3, 3],
            [3, 4, 3, 4], [3, 4, 4, 3], [3, 4, 4, 4], [1, 1, 2, 2], [1, 1, 2, 1],
            [1, 1, 1, 1], [1, 1, 1, 2], [1, 1, 2, 0], [1, 1, 3, 3], [1, 1, 0, 0],
            [1, 1, 1, 0], [1, 2, 2, 2], [1, 2, 2, 1], [1, 2, 1, 1], [1, 2, 1, 2],
            [1, 2, 2, 0], [1, 2, 3, 3], [1, 2, 0, 0], [1, 2, 1, 0]
        ]

        predefined_consequents = [
            [1, 1], [0, 1], [0, 1], [0, 1], [0, 2], [0, 2], [0, 1], [1, 0], [1, 0], [0, 1],
            [2, 1], [1, 0], [1, 1], [0, 1], [0, 1], [0, 1], [0, 2], [0, 2], [0, 1], [1, 0],
            [1, 1], [0, 1], [3, 0], [1, 0], [3, 1], [0, 1], [3, 1], [3, 0], [0, 1], [0, 1],
            [1, 1], [3, 0], [0, 1], [0, 2], [0, 2], [0, 3], [0, 3], [0, 3], [0, 1], [0, 3],
            [0, 3], [0, 1], [0, 1], [0, 3], [0, 3], [0, 1], [0, 3], [0, 2], [1, 1], [0, 2],
            [0, 2], [0, 1], [0, 1], [0, 1], [3, 0], [1, 0], [1, 1], [0, 1], [0, 1], [0, 1],
            [0, 2], [0, 2], [0, 1], [0, 1], [0, 1], [1, 1], [1, 1], [1, 1], [0, 3], [0, 3],
            [0, 3], [0, 2], [1, 0], [0, 3], [0, 2], [0, 3], [0, 1], [0, 3], [0, 1], [0, 3],
            [0, 3], [0, 3], [0, 2], [0, 3]
        ]

        self.rule_antecedents = torch.tensor(predefined_antecedents, device=self.device)
        self.rule_consequents = torch.tensor(predefined_consequents, device=self.device)

    def _precompute_fixed_tensors(self):
        """🚀 预计算所有固定张量 - 系统初始化时执行一次"""
        print("🔄 预计算固定张量...")

        # ✅ 1. 预计算输入隶属函数参数 - 避免运行时切片
        self.input_centers = self.input_mf_params[:, :, 0]  # [4, 5] - 所有输入的中心点
        self.input_widths = self.input_mf_params[:, :, 1]  # [4, 5] - 所有输入的宽度

        # ✅ 2. 预计算高斯函数的倒数平方项 - 避免运行时除法
        self.inv_widths_squared = -0.5 / (self.input_widths ** 2)  # [4, 5]

        # ✅ 3. 预计算输出隶属函数参数
        self.output_centers = self.output_mf_params[:, :, 0]  # [2, 4]
        self.output_widths = self.output_mf_params[:, :, 1]  # [2, 4]
        self.output_inv_widths_squared = -0.5 / (self.output_widths ** 2)  # [2, 4]

        # ✅ 4. 预计算解模糊化的固定参数
        self.output_min = -100.0
        self.output_max = 800.0
        self.n_points = 100
        self.x_points = torch.linspace(self.output_min, self.output_max, self.n_points, device=self.device)
        self.dx = (self.output_max - self.output_min) / (self.n_points - 1)

        # ✅ 5. 预计算输出范围的中点 - 用于默认输出
        self.output_midpoint = (self.output_min + self.output_max) / 2

        # ✅ 6. 预计算常用阈值
        self.min_rule_strength = 1e-6  # 弱规则过滤阈值

        print("✅ 预计算完成！")
        print(f"   - 输入中心点: {self.input_centers.shape}")
        print(f"   - 输入宽度: {self.input_widths.shape}")
        print(f"   - 倒数平方项: {self.inv_widths_squared.shape}")
        print(f"   - 输出参数: {self.output_centers.shape}")
        print(f"   - 解模糊点数: {self.n_points}")

    def to_device(self, tensor):
        """确保张量在正确设备上"""
        if isinstance(tensor, torch.Tensor):
            return tensor.to(self.device)
        else:
            return torch.tensor(tensor, dtype=torch.float32, device=self.device)

    # 🚀 优化后的阶段1：模糊化
    def stage_1_fuzzification(self, inputs):
        """
        阶段1：模糊化 - 使用预计算的固定张量
        inputs: [n_inputs] 单个传感器读数
        返回: [n_inputs, n_input_mfs] 隶属度矩阵
        """
        inputs = self.to_device(inputs)

        # ✅ 完全向量化计算 - 使用预计算的张量
        diff = inputs.unsqueeze(1) - self.input_centers  # [4, 1] - [4, 5] = [4, 5]
        input_memberships = torch.exp(self.inv_widths_squared * (diff ** 2))  # [4, 5]

        return input_memberships

    # 🚀 优化后的阶段2：规则评估
    def stage_2_rule_evaluation(self, input_memberships):
        """
        阶段2：规则评估 - 使用预计算的规则索引
        input_memberships: [n_inputs, n_input_mfs]
        返回: [n_rules] 规则强度向量
        """
        rule_strengths = torch.zeros(self.n_rules, device=self.device)

        # ✅ 使用预计算的规则前件索引，避免重复索引计算
        for rule_idx in range(self.n_rules):
            # 直接使用预存储的规则前件
            antecedent_indices = self.rule_antecedents[rule_idx]  # [4]

            # 向量化获取隶属度值
            rule_membership_values = input_memberships[torch.arange(self.n_inputs), antecedent_indices]  # [4]

            # T-norm操作（最小值）
            rule_strengths[rule_idx] = torch.min(rule_membership_values)

        return rule_strengths

    # 🚀 优化后的阶段3：聚合
    def stage_3_aggregation(self, rule_strengths):
        """
        阶段3：聚合 - 使用预计算的输出参数和点集
        rule_strengths: [n_rules]
        返回: [n_outputs, n_points] 聚合后的隶属函数
        """
        aggregated_outputs = torch.zeros(self.n_outputs, self.n_points, device=self.device)

        for output_idx in range(self.n_outputs):
            # ✅ 直接使用预计算的输出参数
            output_centers = self.output_centers[output_idx]  # [4]
            output_inv_widths_squared = self.output_inv_widths_squared[output_idx]  # [4]

            aggregated_membership = torch.zeros(self.n_points, device=self.device)

            # 对每条规则进行聚合
            for rule_idx in range(self.n_rules):
                rule_strength = rule_strengths[rule_idx]

                # ✅ 使用预计算的阈值过滤弱规则
                if rule_strength < self.min_rule_strength:
                    continue

                # ✅ 直接使用预存储的规则后件
                consequent_mf = self.rule_consequents[rule_idx, output_idx]
                center = output_centers[consequent_mf]
                inv_width_squared = output_inv_widths_squared[consequent_mf]

                # ✅ 使用预计算的倒数平方项计算高斯函数
                diff_squared = (self.x_points - center) ** 2
                gaussian_values = torch.exp(inv_width_squared * diff_squared)

                # 截断到规则强度
                clipped_gaussian = torch.minimum(gaussian_values, rule_strength)

                # S-norm聚合（最大值）
                aggregated_membership = torch.maximum(aggregated_membership, clipped_gaussian)

            aggregated_outputs[output_idx] = aggregated_membership

        return aggregated_outputs, self.x_points  # 返回预计算的x_points

    # 🚀 优化后的阶段4：解模糊
    def stage_4_defuzzification(self, aggregated_data):
        """
        阶段4：解模糊 - 使用预计算的参数
        aggregated_data: (aggregated_outputs, x_points)
        返回: [n_outputs] 清晰输出值
        """
        aggregated_outputs, x_points = aggregated_data
        outputs = torch.zeros(self.n_outputs, device=self.device)

        for output_idx in range(self.n_outputs):
            aggregated_membership = aggregated_outputs[output_idx]

            # ✅ 使用预计算的dx进行重心法计算
            numerator = torch.sum(aggregated_membership * x_points * self.dx)
            denominator = torch.sum(aggregated_membership * self.dx)

            if denominator == 0:
                # ✅ 使用预计算的中点值
                outputs[output_idx] = self.output_midpoint
            else:
                outputs[output_idx] = numerator / denominator

            # ✅ 使用预计算的范围限制
            outputs[output_idx] = torch.clamp(outputs[output_idx], self.output_min, self.output_max)

        return outputs

    # 阶段5保持不变
    def stage_5_output_processing(self, outputs):
        """
        阶段5：输出处理 - 格式化和后处理
        outputs: [n_outputs]
        返回: 处理后的输出
        """
        processed_outputs = outputs.cpu().numpy()

        return {
            'left_speed': float(processed_outputs[0]),
            'right_speed': float(processed_outputs[1]),
            'timestamp': time.time()
        }

    # 🚀 实时推理接口 - 使用优化后的阶段
    def real_time_inference(self, sensor_data):
        """
        实时推理 - 单次完整推理过程（优化版本）
        sensor_data: [S4, S5, S6, S7] 传感器数据
        返回: {'left_speed': float, 'right_speed': float, 'timestamp': float}
        """
        # 阶段1：优化的模糊化
        input_memberships = self.stage_1_fuzzification(sensor_data)

        # 阶段2：优化的规则评估
        rule_strengths = self.stage_2_rule_evaluation(input_memberships)

        # 阶段3：优化的聚合
        aggregated_data = self.stage_3_aggregation(rule_strengths)

        # 阶段4：优化的解模糊
        outputs = self.stage_4_defuzzification(aggregated_data)

        # 阶段5：输出处理
        result = self.stage_5_output_processing(outputs)

        return result

    # 流水线相关方法保持不变...
    def start_pipeline(self):
        """启动流水线处理"""
        self.pipeline_running = True

        stage_functions = [
            self._pipeline_worker_1,
            self._pipeline_worker_2,
            self._pipeline_worker_3,
            self._pipeline_worker_4,
            self._pipeline_worker_5
        ]

        for i, worker_func in enumerate(stage_functions):
            thread = threading.Thread(target=worker_func, name=f"Pipeline-Stage-{i + 1}")
            thread.daemon = True
            thread.start()
            self.pipeline_threads.append(thread)

        print("🚀 优化流水线系统已启动，5个阶段并行运行")

    def stop_pipeline(self):
        """停止流水线处理"""
        self.pipeline_running = False
        print("🛑 流水线系统已停止")

    def pipeline_input(self, sensor_data):
        """向流水线输入数据"""
        if len(self.stage_queues['fuzzification']) < self.stage_queues['fuzzification'].maxlen:
            self.stage_queues['fuzzification'].append({
                'data': sensor_data,
                'timestamp': time.time()
            })
            return True
        return False

    def get_pipeline_output(self):
        """从流水线获取输出"""
        if self.stage_queues['output']:
            return self.stage_queues['output'].popleft()
        return None

    # 流水线工作线程 - 使用优化后的阶段函数
    def _pipeline_worker_1(self):
        """流水线工作线程1：优化的模糊化"""
        while self.pipeline_running:
            if self.stage_queues['fuzzification']:
                item = self.stage_queues['fuzzification'].popleft()
                result = self.stage_1_fuzzification(item['data'])

                if len(self.stage_queues['rule_evaluation']) < self.stage_queues['rule_evaluation'].maxlen:
                    self.stage_queues['rule_evaluation'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_2(self):
        """流水线工作线程2：优化的规则评估"""
        while self.pipeline_running:
            if self.stage_queues['rule_evaluation']:
                item = self.stage_queues['rule_evaluation'].popleft()
                result = self.stage_2_rule_evaluation(item['data'])

                if len(self.stage_queues['aggregation']) < self.stage_queues['aggregation'].maxlen:
                    self.stage_queues['aggregation'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_3(self):
        """流水线工作线程3：优化的聚合"""
        while self.pipeline_running:
            if self.stage_queues['aggregation']:
                item = self.stage_queues['aggregation'].popleft()
                result = self.stage_3_aggregation(item['data'])

                if len(self.stage_queues['defuzzification']) < self.stage_queues['defuzzification'].maxlen:
                    self.stage_queues['defuzzification'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_4(self):
        """流水线工作线程4：优化的解模糊"""
        while self.pipeline_running:
            if self.stage_queues['defuzzification']:
                item = self.stage_queues['defuzzification'].popleft()
                result = self.stage_4_defuzzification(item['data'])

                if len(self.stage_queues['output']) < self.stage_queues['output'].maxlen:
                    self.stage_queues['output'].append({
                        'data': result,
                        'timestamp': item['timestamp']
                    })
            else:
                time.sleep(0.001)

    def _pipeline_worker_5(self):
        """流水线工作线程5：输出处理"""
        while self.pipeline_running:
            if self.stage_queues['output']:
                item = self.stage_queues['output'].popleft()
                result = self.stage_5_output_processing(item['data'])
                result['timestamp'] = item['timestamp']
            else:
                time.sleep(0.001)


# 使用示例
def main():
    print("=== 优化版实时流水线模糊推理系统 ===")

    # 创建系统
    fuzzy_system = RealTimeFuzzySystem(
        n_inputs=4, n_outputs=2, n_input_mfs=5,
        n_output_mfs=4, n_rules=84, use_gpu=True
    )

    # 单次推理测试
    print("\n=== 单次实时推理测试 ===")
    sensor_data = [500, 400, 300, 200]
    result = fuzzy_system.real_time_inference(sensor_data)
    print(f"传感器输入: {sensor_data}")
    print(f"控制输出: left_speed={result['left_speed']:.2f}, right_speed={result['right_speed']:.2f}")


if __name__ == "__main__":
    main()
